<?php
$estado_session = session_status();

if($estado_session == PHP_SESSION_NONE)
{
    session_start();
}
else{}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
          <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>¡Bienvenido a COPLAIC!</title>
    
    <!--HOJAS DE ESTILO Y FUENTES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/custom.css" rel="stylesheet" />
    <link href="assets/css/estilo.css" rel="stylesheet" />
    
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    
    <!--js-->
    
    <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
         <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>

    
    <style>
        
    #div-login{
        width: 50%;
        margin-left: 25%;
    }
    
     /*Theme Buttons*/

    .btn-theme {
      color: #fff;
      background-color: #0099ff;
      border-color: #48bcb4;
    }
    .btn-theme:hover,
    .btn-theme:focus,
    .btn-theme:active,
    .btn-theme.active,
    .open .dropdown-toggle.btn-theme {
      color: #fff;
      background-color: #0099ff;
      border-color: #0099ff;
    }
    
    .btn-block{
        padding-top: 4px;
        padding-bottom: 4px;
        width: 99%;
    }
    
    @media (min-width: 1024px) and (max-width: 1400px) {
        #div-login{
            width: 40%;
            margin-left: 30%;
        }
    }
    @media (min-width: 700px) and (max-width: 1024px) {
        #div-login{
            width: 50%;
            margin-left: 25%;
        }
    }
    @media (min-width: 500px) and (max-width: 700px) {
        #div-login{
            width: 60%;
            margin-left: 20%;
        }
    }
    @media (min-width: 350px) and (max-width: 500px) {
        #div-login{
            width: 80%;
            margin-left: 10%;
        }
    }
    @media (min-width: 150px) and (max-width: 350px) {
        #div-login{
            width: 95%;
            margin-left: 2.5%;
        }
    }
    </style>
    
  </head>

  <body style="background: url(assets/img/background.png) no-repeat;">
      <div id="login-page">
        <div class="container">
            <div class="panel-body">
                <center>
                    <div style="width: 60%;">
                <?php
                        if( isset( $_SESSION['resp'] ) )
                        {
                            if( $_SESSION['resp'] == "C_< 8" )
                            { 
                        ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    La Clave ingresada no es válida. (Debe contener entre 8 y 16 caracteres)
                                </div>
                        <?php
                        
                            unset( $_SESSION['resp'] );
                        
                            }
                            else if( $_SESSION['resp'] == "N_< 8" )
                            { 
                                
                        ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    El nombre de usuario ingresado no es válido. (Debe contener entre 8 y 16 caracteres)
                                </div>
                        <?php
                                unset( $_SESSION['resp'] );
                            } 
                            else if( $_SESSION['resp'] == "Inc" )
                            { 
                                
                        ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    Los datos ingresados son incorrectos, verifique el nombre de usuario y/o la clave
                                </div>
                        <?php
                                unset( $_SESSION['resp'] );
                            }
                            else if( $_SESSION['resp'] == "Disab" )
                            {
                        ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    Su cuenta se encuentra deshabilitada, comuniquese con el Administrador del sistema para solicitar su reactivación.
                                </div>
                        <?php
                            }
                        }
                    ?>
                <!---->
                    </div>
                </center>
                
                   
                <div class="" id="div-login">
                    <div class="">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <center>
                                    <strong style="color: #0099ff;"><h3>Inicie Sesión</h3></strong>
                                </center> 
                            </div>
                            <div class="panel-body">
                                <form role="form" action="controlador/C_Sesion.php" method="post">
                                    <div class=" form-group input-group input-group-lg">
                                        <span class="input-group-addon">&nbsp;<i class="fa fa-user"></i></span>
                                        <input type="text" name="nombre_usuario" maxlength="16" autocomplete="off" style="text-transform: uppercase;" class="form-control" placeholder="Nombre de usuario" />
                                    </div>
                                    <div class=" form-group input-group input-group-lg">
                                        <span class="input-group-addon"><i class="fa fa-key"></i></span>
                                        <input type="password" name="clave" maxlength="16" class="form-control" placeholder="Clave de acceso" />
                                    </div>
                                    
                                    <br>
                                    <center>
                                        <div class="">
                                            <button class="btn btn-primary btn-lg" id="btn_ingresar" type="submit">
                                                <strong>Ingresar</strong>
                                            </button>
                                        </div><!-- /showback -->
                                    </center>
                                </form>
                                <hr>
                    <div class="registration">
                        <!--<label class="checkbox">
                            <span class="pull-right">
                                <a data-toggle="modal" style="color: #0099ff;" href="login.html#myModal"> ¿Recuperar Usuario?</a>
                                &nbsp;&nbsp;
                                <a data-toggle="modal" style="color: #0099ff;" href="login.html#myModal"> ¿Recuperar Clave?</a>
                                <br>
                            </span>
                        </label>-->
                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            
            <!--<form class="form-login" method="post" action="controlador/C_Sesion.php">
                <h2 class="form-login-heading">
                    <img src="assets/img/iconos/user.png" style="height: 30px; margin-top: -8px;">
                    Inicia Sesión
                </h2>
                <div class="login-wrap">
                    <br>
                    <input type="text" name="nombre_usuario" autocomplete="off" class="form-control" placeholder="Nombre de usuario" autofocus>
                    <br>
                    <input type="password" name="clave" class="form-control" placeholder="Clave">
                    <br>
                    
                    <br>
                    
                </div>
                </form>-->
                <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h4 class="modal-title">Recuperar Clave</h4>
                            </div>
                            <div class="modal-body">
                                <p></p>
                                <input type="text" name="email" placeholder="Email" autocomplete="off" class="form-control placeholder-no-fix">

                            </div>
                            <div class="modal-footer">
                                <button data-dismiss="modal" class="btn btn-default" type="button">Cancel</button>
                                <button class="btn btn-theme" type="button">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
     
            
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <!--<script type="text/javascript" src="assets/js/jquery.backstretch.min.js"></script>
    <!--<script>
                     //(direccion donde esta la img , velocidad para que aparezca la img)
        $.backstretch("assets/img/foto_perfil/perfil-01.png", {speed: 1000}); //para mostrar fondo del index con animacion
    </script>-->
    
</body>
</html>