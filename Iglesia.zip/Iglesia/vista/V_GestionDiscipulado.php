<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>TECSIA | Discipulado</title>
    
    <!--HOJAS DE ESTILO Y FUENTES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/css/custom.css" rel="stylesheet" />
    <link href="../assets/css/estilo.css" rel="stylesheet" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link href="../assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    
    <script type="text/javascript">
        
        function Buscar( id_discipulado )
        {
            $.ajax({
                async:false, 
                cache:false,
                dataType:"html", 
                type: 'POST',   
                url: "../controlador/C_GestionDiscipulado.php",
                data: {
                        id_discipulado: id_discipulado,
                        buscar_discipulado: "JDHSJUHDWJDHSJHSJDS" 
                },
                success:  function(respuesta){

                    contenido = $.trim(respuesta); 

                    if(contenido !== "[]")
                    { 
                        // json vacio....
                        var json_discipulado = $.parseJSON(contenido);
                        //alert(json_estado);
                        $("#id_discipulado").val( json_discipulado.id_discipulado );
//                        $("#codigo_cne_estado").val( json_estado.codigo_cne_estado );
                        $("#nombre_discipulado").val( json_discipulado.descripcion );
                        
                        $("#btn_registrar").attr("disabled","disabled");
                        $("#btn_modificar").removeAttr("disabled");
                        $("#btn_eliminar").removeAttr("disabled");
                        $("#btn_cancelar").removeAttr("disabled");
                        
//                        $("#sugerencias-codigos").fadeOut(10);
                        $("#sugerencias-nombres").fadeOut(10);
                    }
                    else
                    {
//                        $("#sugerencias-codigos").fadeOut(10);
                        $("#sugerencias-nombres").fadeOut(10);
                    }

                },
                beforeSend:function(){
                    //alert('envie la data');
                },
                error:function(objXMLHttpRequest){}
            });
        }
//        
//        function Notificacion( tipo, msj )
//        {
//            //alert( tipo+ ' '+msj );
//            if( tipo == 0 )
//            {
//                $("#texto-error").text(msj);
//                $("#mensaje-error").fadeIn(20);
//                $("#mensaje-success").fadeOut(10);
//                $("#mensaje-info").fadeOut(10);
//            }
//            else if( tipo == 1 )
//            {
//                $("#texto-success").text(msj);
//                $("#mensaje-success").fadeIn(20);
//                $("#mensaje-error").fadeOut(10);
//                $("#mensaje-info").fadeOut(10);
//                $("#to-top").pushStack();
//            }
//            else if( tipo == 2 )
//            {
//                $("#texto-info").text(msj);
//                $("#mensaje-info").fadeIn(20);
//                $("#mensaje-success").fadeOut(10);
//                $("#mensaje-error").fadeOut(10);
//            }
//        }
//        
        /*FUNCION PARA ACTUALIZAR DATOS DE UN ESTADO*/
        function RegistrarDiscipulado( )
        {
            var descripcion = $("#nombre_discipulado").val();
         
            else if( $("#nombre_discipulado").val() == "" )
            {
                Notificacion(0, "Debe ingresar la descripcion del Discipulado.");
            }
            else
            {
                $.ajax({
                    async:false, 
                    cache:false,
                    dataType:"html", 
                    type: 'POST',   
                    url: "../controlador/C_GestionDiscipulado.php",
                    data: {
                            
                            nombre_discipulado: $("#nombre_discipulado").val(),
                            registrar_discipulado: "registrar_discipulado" 
                    },
                    success:  function(respuesta){

                        if(respuesta == 1)
                        { 
                            var msj = "Discipulado "+ descripcion +" fue registrado.";
                            
                            $("#id_discipulado").val("");
                            $("#nombre_discipulado").val("");

                            $("#btn_modificar").attr("disabled","disabled");
                            $("#btn_eliminar").attr("disabled","disabled");
                            $("#btn_cancelar").attr("disabled","disabled");

                            $("#sugerencias-nombres").fadeOut(10);
                            Notificacion(1, msj);

                        }
                        else
                        {
                            var msj = respuesta;
                            Notificacion(0, msj); 
                        }


                    },
                    beforeSend:function(){},
                    error:function(objXMLHttpRequest){}
                }); //cierra el ajax
            }
        }
//        
//        
        /*FUNCION PARA ACTUALIZAR DATOS DE UN ESTADO*/
        function ModificarDiscipulado( )
        {
            
            if( $("#nombre_discipulado").val() == "" )
            {
                Notificacion(0, "Debe ingresar la Descripcion del Discipulado.");
            }
            else
            {
                $.ajax({
                    async:false, 
                    cache:false,
                    dataType:"html", 
                    type: 'POST',   
                    url: "../controlador/C_GestionDiscipulado.php",
                    data: {
                            id_discipulado: $("#id_discipulado").val(),
                            descripcion: $("#nombre_discipulado").val(),
                            modificar_discipulado: "modificar_discipulado" 
                    },
                    success:  function(respuesta){
                        
                        if(respuesta == 1)
                        { 
                            Notificacion(2, "Los datos del Discipulado han sido actualizados.");
                            $("#id_discipulado").val( "" );
                            $("#nombre_discipulado").val( "" );

                            $("#btn_registrar").removeAttr("disabled");
                            $("#btn_modificar").attr("disabled","disabled");
                            $("#btn_eliminar").attr("disabled","disabled");
                            $("#btn_cancelar").attr("disabled","disabled");
                            
                       
                            $("#sugerencias-nombres").fadeOut(10);
                        }
                        else
                        {
                            var msj = respuesta;
                            Notificacion(0, msj);
                        }

                    },
                    beforeSend:function(){},
                    error:function(objXMLHttpRequest){}
                });
            }
        }
        
        /*FUNCION PARA ELIMINAR O INHABILITAR UN ESTADO*/
        function EliminarDiscipulado( )
        {
            $.ajax({
                async:false, 
                cache:false,
                dataType:"html", 
                type: 'POST',   
                url: "../controlador/C_GestionDiscipulado.php",
                data: {
                        id_discipulado: $("#id_discipulado").val(),
                        eliminar_discipulado: "eliminar_discipulado" 
                },
                success:  function(respuesta){
                    
                    if(respuesta == 1)
                    { 
                        Notificacion(2, "El Discipulado ha sido eliminada");
                        $("#id_discipulado").val( "" );
                        $("#nombre_discipulado").val( "" );
                        
                        $("#btn_registrar").removeAttr("disabled");
                        $("#btn_modificar").attr("disabled","disabled");
                        $("#btn_eliminar").attr("disabled","disabled");
                        $("#btn_cancelar").attr("disabled","disabled");
                        
                        $("#sugerencias-nombres").fadeOut(10);
                    }
                    else
                    {
                        
                        Notificacion(0, "Problemas con la base de datos");
                    
                        $("#sugerencias-nombres").fadeOut(10);
                    }

                },
                beforeSend:function(){},
                error:function(objXMLHttpRequest){}
            });
        }
        
        /*FUNCION PARA BUSCAR SUGERENCIAS MIENTRAS SE ESCRIBE EN LOS CAMPOS*/
        function BuscarSugerencias()
        {
            
            $.ajax({
                async:false, 
                cache:false,
                dataType:"html", 
                type: 'POST',   
                url: "../controlador/C_GestionDiscipulado.php",
                data: {
                        
                        descripcion: $("#nombre_discipulado").val(),
                        autocompletar: "autocompletar" 
                },
                success:  function(respuesta){
                    
                    if(respuesta != "")
                    {
                        $("#sugerencias-nombres").html( respuesta );
                        $("#sugerencias-nombres").fadeIn(700);                        
                    }
                    else
                    {
                        $("#sugerencias-nombres").html('<li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>');
                        $("#sugerencias-nombres").fadeIn(700);
                    }

                },
                beforeSend:function(){},
                error:function(objXMLHttpRequest){}
            });
        }
        
//        function Cancelar()
//        {
//            $("#id_estado").val( "" );
//            $("#codigo_cne_estado").val( "" );
//            $("#nombre_estado").val( "" );
//
//            $("#btn_registrar").removeAttr("disabled");
//            $("#btn_modificar").attr("disabled","disabled");
//            $("#btn_eliminar").attr("disabled","disabled");
//            $("#btn_cancelar").attr("disabled","disabled");
//            
//            $("#sugerencias-codigos").fadeOut(10);
//            $("#sugerencias-nombres").fadeOut(10);
//            
//            $("#mensaje-error").fadeOut(10);
//            $("#mensaje-success").fadeOut(10);
//            $("#mensaje-info").fadeOut(10);
//        }
//    
//    
//        /*FUNCION PARA ELIMINAR O INHABILITAR UN ESTADO*/
//        function ListarEstados( )
//        {
//            $.ajax({
//                async:false, 
//                cache:false,
//                dataType:"html", 
//                type: 'POST',   
//                url: "../controlador/C_GestionEstado.php",
//                data: {
//                        
//                        listar_estados: "stado" 
//                },
//                success:  function(respuesta){
//                    
//                    if(respuesta !== "")
//                    { 
//                        $("#div-tabla-estados").html( respuesta );
//                    }
//                    else
//                    {
//                        $("#div-tabla-estados").html( respuesta );
//                    }
//
//                },
//                beforeSend:function(){},
//                error:function(objXMLHttpRequest){}
//            });
//        }
    </script>
    
    
</head>
<body>
    <?php include("CabeceraMenu.php"); ?>
        <div id="page-wrapper" >
            <div id="mensaje-success" style="display: none;">
                <div id="msj" class="alert alert-success alert-dismissable">
                    <button type="button" onclick="$('#mensaje-success').fadeOut(5);" class="close" data-dismiss="men" aria-hidden="true">&times;</button>
                    <strong id="texto-success"></strong>
                </div>
            </div>
            <div id="mensaje-error" style="display: none;">
                <div id="msj" class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" onclick="$('#mensaje-error').fadeOut(5);" data-dismiss="" aria-hidden="true">&times;</button>
                    <strong id="texto-error"></strong>
                </div>
            </div>
            <div id="mensaje-info" style="display: none;">
                <div id="msj" class="alert alert-info alert-dismissable">
                    <button type="button" class="close" onclick="$('#mensaje-info').fadeOut(5);" data-dismiss="" aria-hidden="true">&times;</button>
                    <strong id="texto-info"></strong>
                </div>
            </div>
            <div id="page-inner">
             
             <div class="row">
                    <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Gestión de Interrogante 
                            </div>
                            <div class="panel-body">
                                <form class="form-horizontal style-form" method="post">
                                    <input type="hidden" id="id_interrogante">
                                    <div class="form-group">
                                        <label class="col-12 col-12 control-label">
                                            <strong><a id="asterisco-obligatorio">*</a> Interrogante</strong>
                                        </label>
                                        <div class="col-12">
                                            <input type="text" id="nombre_interrogante" style="text-transform: uppercase;" onkeyup="BuscarSugerencias()" placeholder="Ingresa la Interrogante" class="form-control">
                                            <ul class="autocompletar" id="sugerencias-nombres"></ul>
                                            <p id="leyenda-campos">*Descripcion que desee darle a la Interrogante</p>
                                        </div>
                                    </div>
                                    <br>
                                    <center>
                                        <div class="">
                                            <button type="button" onclick="RegistrarInterrogante()" id="btn_registrar" class="btn btn-success">Registrar</button>
                                            <button type="button" disabled="" onclick="ModificarInterrogante()" id="btn_modificar" class="btn btn-primary">Modificar</button>
                                            <button type="button" disabled="" data-toggle="modal" data-target="#confirmar" id="btn_eliminar" class="btn btn-danger">Eliminar</button>
                                            <button type="button" disabled="" id="btn_cancelar" onclick="Cancelar()" class="btn btn-default">Cancelar</button>
                                        </div><!-- /showback -->
                                    </center>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Interrogante 
                            </div>
                            <div class="panel-body">
                                <div class="table-responsive" id="div-tabla-interrogante">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

</div>
             <!--CONTENIDO A MOSTRAR EN VENTANA MODAL CUANDO PRESIONE ICONO DE AYUDA-->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                      <h4 class="modal-title" id="myModalLabel">Módulo de Gestión de Interrogante</h4>
                    </div>
                    <div class="modal-body">
                        Mediante este modulo se pueden gestionar todos los estados que se necesiten para alimentar el sistema, 
                        aplican dos campos que son el código asignado por el CNE para el estado a gestionar y el nombre del estado, 
                        son campos obligatorios, de manera que no pueden estar vacios al realizar un registro, o una modificación.                       
                    </div>
                    <div class="modal-footer">
                      <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      <button type="button" class="btn btn-primary">Save changes</button>-->
                    </div>
                </div>
            </div>
        </div>
        
      <div class="modal fade" id="confirmar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                      <h4 class="modal-title" id="myModalLabel">¡Mensaje de Advertencia!</h4>
                    </div>
                    <div class="modal-body">
                        ¿Desea eliminar esta Interrogante?
                        Una vez eliminado no podra recuperar sus datos.
                    </div>
                    <div class="modal-footer">
                        <button type="button"data-dismiss="modal" class="btn btn-danger" onclick="EliminarInterrogante()">Eliminar</button>
                      <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                    </div>
                </div>
            </div>
        </div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="../assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="../assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="../assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                ListarInterrogante();
            });
    </script>
         <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
    
   
</body>
</html>
