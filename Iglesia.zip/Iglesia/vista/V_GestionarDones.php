<?php
$estado_session = session_status();

if($estado_session == PHP_SESSION_NONE)
{
    session_start();
}
else{}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>TECSIA | Dones</title>
    
    <!--HOJAS DE ESTILO Y FUENTES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/css/custom.css" rel="stylesheet" />
    <link href="../assets/css/estilo.css" rel="stylesheet" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link href="../assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    
    <script type="text/javascript">
        function Let(e){
       key = e.keyCode || e.which;
       tecla = String.fromCharCode(key).toLowerCase();
       letras = " abcdefghijklmnñopqrstuvwxyz  ABCDEFGHIJKLMNÑOPQRSTUVWXYZ";
       especiales = "8-37-39-46-64";

       tecla_especial = false
       for(var i in especiales){
            if(key == especiales[i]){
                tecla_especial = true;
                break;
            }
        }

        if(letras.indexOf(tecla)==-1 && !tecla_especial){
            return false;
        }
        else  
        {tecla=(document.all) ? e.keyCode : e.which; 
        if(tecla==32) return true; }
    }
        
        function Buscar( id_dones )
        {
            $.ajax({
                async:false, 
                cache:false,
                dataType:"html", 
                type: 'POST',   
                url: "../controlador/C_GestionDones.php",
                data: {
                        id_dones: id_dones,
                        buscar_dones: true 
                },
                success:  function(respuesta){

                    //alert( respuesta );
                    contenido = $.trim(respuesta); 

                    if(contenido !== "[]")
                    { 
                        // json vacio....
                        var json_dones = $.parseJSON(contenido);
                        //alert(json_dones);
                        $("#id_dones").val( json_dones.id_dones );
                        $("#nombre").val( json_dones.nombre );
                        
                        $("#btn_registrar").attr("disabled","disabled");
                        $("#btn_modificar").removeAttr("disabled");
                        $("#btn_eliminar").removeAttr("disabled");
                        $("#btn_cancelar").removeAttr("disabled");
                        
                        $("#sugerencias-nombres").fadeOut(10);
                    }
                    else
                    {
                        $("#sugerencias-nombres").fadeOut(10);
                    }

                },
                beforeSend:function(){
                    //alert('envie la data');
                },
                error:function(objXMLHttpRequest){}
            });
        }
        
        function Notificacion( tipo, msj )
        {
            //alert( tipo+ ' '+msj );
            if( tipo == 0 )
            {
                $("#texto-error").text(msj);
                $("#mensaje-error").fadeIn(20);
                $("#mensaje-success").fadeOut(10);
                $("#mensaje-info").fadeOut(10);

                setTimeout(function() {
                    $("#mensaje-error").fadeOut(1500);
                },10000);
            }
            else if( tipo == 1 )
            {
                $("#texto-success").text(msj);
                $("#mensaje-success").fadeIn(20);
                $("#mensaje-error").fadeOut(10);
                $("#mensaje-info").fadeOut(10);

                setTimeout(function() {
                    $("#mensaje-success").fadeOut(1500);
                },10000);
            }
            else if( tipo == 2 )
            {
                $("#texto-info").text(msj);
                $("#mensaje-info").fadeIn(20);
                $("#mensaje-success").fadeOut(10);
                $("#mensaje-error").fadeOut(10);

                setTimeout(function() {
                    $("#mensaje-info").fadeOut(1500);
                },10000);
            }
        }
        
        /*FUNCION PARA ACTUALIZAR DATOS DE UN DONES*/
        function RegistrarDones( )
        {
            var nombre = $("#nombre").val();
            if( $("#nombre").val() == "" )
            {
                Notificacion(0, "Debe ingresar el la Descripción del Dones.");
            }
            else
            {
                $.ajax({
                    async:false, 
                    cache:false,
                    dataType:"html", 
                    type: 'POST',   
                    url: "../controlador/C_GestionDones.php",
                    data: {
                            nombre: $("#nombre").val(),
                            registrar_dones: true 
                    },
                    success:  function(respuesta){

                        if(respuesta == 1)
                        { 
                            var msj = "Dones "+ nombre +" fue registrado.";
                            
                            $("#id_dones").val("");
                            $("#nombre").val("");

                            $("#btn_modificar").attr("disabled","disabled");
                            $("#btn_eliminar").attr("disabled","disabled");
                            $("#btn_cancelar").attr("disabled","disabled");

                            $("#sugerencias-nombres").fadeOut(10);
                            Notificacion(1, msj);

                            ListarDones();
                        }
                        else
                        {
                            var msj = respuesta;
                            Notificacion(0, msj); 
                        }


                    },
                    beforeSend:function(){},
                    error:function(objXMLHttpRequest){}
                }); //cierra el ajax
            }
        }
        
        
        /*FUNCION PARA ACTUALIZAR DATOS DE UN DONES*/
        function ModificarDones( )
        {
            if( $("#nombre").val() == "" )
            {
                Notificacion(0, "Debe ingresar la Descripción del Dones.");
            }
            else
            {
                $.ajax({
                    async:false, 
                    cache:false,
                    dataType:"html", 
                    type: 'POST',   
                    url: "../controlador/C_GestionDones.php",
                    data: {
                            id_dones: $("#id_dones").val(),
                            nombre: $("#nombre").val(),
                            modificar_dones: true 
                    },
                    success:  function(respuesta){

                        if(respuesta == 1)
                        { 
                            Notificacion(2, "Los datos del Dones han sido actualizados.");
                            $("#id_dones").val( "" );
                            $("#nombre").val( "" );

                            $("#btn_registrar").removeAttr("disabled");
                            $("#btn_modificar").attr("disabled","disabled");
                            $("#btn_eliminar").attr("disabled","disabled");
                            $("#btn_cancelar").attr("disabled","disabled");
                            
                            $("#sugerencias-nombres").fadeOut(10);

                            ListarDones();
                        }
                        else
                        {
                            var msj = respuesta;
                            Notificacion(0, msj);
                        }

                    },
                    beforeSend:function(){},
                    error:function(objXMLHttpRequest){}
                });
            }
        }
        
        /*FUNCION PARA ELIMINAR O INHABILITAR UN MISNISTERIO*/
        function EliminarDones( )
        {
            $.ajax({
                async:false, 
                cache:false,
                dataType:"html", 
                type: 'POST',   
                url: "../controlador/C_GestionDones.php",
                data: {
                        id_dones: $("#id_dones").val(),
                        eliminar_dones: true 
                },
                success:  function(respuesta){
                    
                    if(respuesta == 1)
                    { 
                        Notificacion(2, "El Dones ha sido eliminado");
                        $("#id_dones").val( "" );
                        $("#nombre").val( "" );
                        
                        $("#btn_registrar").removeAttr("disabled");
                        $("#btn_modificar").attr("disabled","disabled");
                        $("#btn_eliminar").attr("disabled","disabled");
                        $("#btn_cancelar").attr("disabled","disabled");
                        
                        $("#sugerencias-nombres").fadeOut(10);

                        ListarDones();
                    }
                    else
                    {
                        
                        Notificacion(0, "Problemas con la base de datos");
                        $("#sugerencias-nombres").fadeOut(10);
                    }

                },
                beforeSend:function(){},
                error:function(objXMLHttpRequest){}
            });
        }
        
        /*FUNCION PARA BUSCAR SUGERENCIAS MIENTRAS SE ESCRIBE EN LOS CAMPOS*/
        function BuscarSugerencias( camp )
        {
            var campo = "";
            campo = "NOMBRE";
            $("#sugerencias-codigos").fadeOut(100);
            $("#filtrado").val( $("#nombre").val() );
            //$("#catalogo")[0].contentWindow.location.href="CatalogoDescripcions.php?nombre="+$("#nombre").val()+"?codigo=";
            
            $.ajax({
                async:false, 
                cache:false,
                dataType:"html", 
                type: 'POST',   
                url: "../controlador/C_GestionDones.php",
                data: {
                        campo: campo,
                        nombre: $("#nombre").val(),
                        autocompletar: true 
                },
                success:  function(respuesta){

                    if(respuesta != "")
                    { 
                        if( campo == "NOMBRE" )
                        {
                            $("#sugerencias-nombres").html( respuesta );
                            $("#sugerencias-nombres").fadeIn(700);
                        }                        
                    }
                    else
                    {
                          if( campo == "NOMBRE" )
                        {
                            $("#sugerencias-nombres").html('<li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>');
                            $("#sugerencias-nombres").fadeIn(700);
                        }
                    }

                },
                beforeSend:function(){},
                error:function(objXMLHttpRequest){}
            });
        }
        
        function Cancelar()
        {
            $("#id_dones").val( "" );
            $("#nombre").val( "" );

            $("#btn_registrar").removeAttr("disabled");
            $("#btn_modificar").attr("disabled","disabled");
            $("#btn_eliminar").attr("disabled","disabled");
            $("#btn_cancelar").attr("disabled","disabled");
            
            $("#sugerencias-nombres").fadeOut(10);
            
            $("#mensaje-error").fadeOut(10);
            $("#mensaje-success").fadeOut(10);
            $("#mensaje-info").fadeOut(10);
        }
    
    
        /*FUNCION PARA ELIMINAR O INHABILITAR UN DONES*/
        function ListarDones( )
        {
            $.ajax({
                async:false, 
                cache:false,
                dataType:"html", 
                type: 'POST',   
                url: "../controlador/C_GestionDones.php",
                data: {
                        
                        listar_dones: true 
                },
                success:  function(respuesta){
                    
                    if(respuesta !== "")
                    { 
                        $("#div-tabla-dones").html( respuesta );
                    }
                    else
                    {
                        $("#div-tabla-dones").html( respuesta );
                    }

                },
                beforeSend:function(){},
                error:function(objXMLHttpRequest){}
            });
        }
    </script>
    
    
</head>
<body>
    <?php include("CabeceraMenu.php"); ?>
        <div id="page-wrapper" >
            <div id="mensaje-success" style="display: none;">
                <div id="msj" class="alert alert-success alert-dismissable">
                    <button type="button" onclick="$('#mensaje-success').fadeOut(5);" class="close" data-dismiss="men" aria-hidden="true">&times;</button>
                    <strong id="texto-success"></strong>
                </div>
            </div>
            <div id="mensaje-error" style="display: none;">
                <div id="msj" class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" onclick="$('#mensaje-error').fadeOut(5);" data-dismiss="" aria-hidden="true">&times;</button>
                    <strong id="texto-error"></strong>
                </div>
            </div>
            <div id="mensaje-info" style="display: none;">
                <div id="msj" class="alert alert-info alert-dismissable">
                    <button type="button" class="close" onclick="$('#mensaje-info').fadeOut(5);" data-dismiss="" aria-hidden="true">&times;</button>
                    <strong id="texto-info"></strong>
                </div>
            </div>
            <div id="page-inner">
             
             <div class="row">
                    <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Gestión de Dones 
                            </div>
                            <div class="panel-body">
                                <form class="form-horizontal style-form" method="post">
                                    <input type="hidden" id="id_dones">
                                    <div class="form-group">
                                        <label class="col-12 col-12 control-label">
                                            <strong><a id="asterisco-obligatorio">*</a> Nombre del Dones</strong>
                                        </label>
                                        <div class="col-12">
                                            <input type="text" id="nombre" onkeypress="return Let(event)" style="text-transform: uppercase;" onkeyup="BuscarSugerencias(1)" placeholder="Ingresa la Descripción del Dones" class="form-control">
                                            <ul class="autocompletar" id="sugerencias-nombres"></ul>
                                            <p id="leyenda-campos">*Nombre del Dones</p>
                                        </div>
                                    </div>
                                    <br>
                                    <center>
                                        <div class="">
                                            <button type="button" onclick="RegistrarDones()" id="btn_registrar" class="btn btn-success">Registrar</button>
                                            <button type="button" disabled="" onclick="ModificarDones()" id="btn_modificar" class="btn btn-primary">Modificar</button>
                                            <button type="button" disabled="" data-toggle="modal" data-target="#confirmar" id="btn_eliminar" class="btn btn-danger">Eliminar</button>
                                            <button type="button" disabled="" id="btn_cancelar" onclick="Cancelar()" class="btn btn-default">Cancelar</button>
                                        </div><!-- /showback -->
                                    </center>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Dones Registrados 
                            </div>
                            <div class="panel-body">
                                <div class="table-responsive" id="div-tabla-dones">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

</div>
             <!--CONTENIDO A MOSTRAR EN VENTANA MODAL CUANDO PRESIONE ICONO DE AYUDA-->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                      <h4 class="modal-title" id="myModalLabel">Módulo de Gestión de Dones</h4>
                    </div>
                    <div class="modal-body">
                        Mediante este modulo se pueden gestionar todos los dones que se necesiten para alimentar el sistema, 
                        aplica un campo que es nombre del dones, 
                        es un campos obligatorios, de manera que no pueden estar vacios al realizar un registro, o una modificación.                       
                    </div>
                    <div class="modal-footer">
                      <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      <button type="button" class="btn btn-primary">Save changes</button>-->
                    </div>
                </div>
            </div>
        </div>
        
      <div class="modal fade" id="confirmar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                      <h4 class="modal-title" id="myModalLabel">¡Mensaje de Advertencia!</h4>
                    </div>
                    <div class="modal-body">
                        ¿Desea eliminar este Dones?
                        Una vez eliminado no podra recuperar sus datos.
                    </div>
                    <div class="modal-footer">
                        <button type="button"data-dismiss="modal" class="btn btn-danger" onclick="EliminarDones()">Eliminar</button>
                      <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                    </div>
                </div>
            </div>
        </div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="../assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="../assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="../assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                ListarDones();
            });
    </script>
         <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
    
   
</body>
</html>
