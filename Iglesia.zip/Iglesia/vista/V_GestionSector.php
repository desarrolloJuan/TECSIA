<?php
$estado_session = session_status();

if($estado_session == PHP_SESSION_NONE)
{
    session_start();
}
else{}

$_SESSION['msj'] = "";
include("../modelo/Estado.php");
include("../modelo/Municipio.php");
include("../modelo/Parroquia.php");
$estado = new Estado();
$municipio = new Municipio();
$parroquia = new Parroquia();
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>TECSIA | Sector</title>
    
    <!--HOJAS DE ESTILO Y FUENTES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/css/custom.css" rel="stylesheet" />
    <link href="../assets/css/estilo.css" rel="stylesheet" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link href="../assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    
    <script type="text/javascript">
        
        function soloNum(e){
       key = e.keyCode || e.which;
       tecla = String.fromCharCode(key).toLowerCase();
       letras = " 0123456789";
       especiales = "8-37-39-46";

       tecla_especial = false
       for(var i in especiales){
            if(key == especiales[i]){
                tecla_especial = true;
                break;
            }
        }

        if(letras.indexOf(tecla)==-1 && !tecla_especial){
            return false;
        }
        else  
        {tecla=(document.all) ? e.keyCode : e.which; 
        if(tecla==32) return false; }
    }
        
        function Let(e){
       key = e.keyCode || e.which;
       tecla = String.fromCharCode(key).toLowerCase();
       letras = " abcdefghijklmnñopqrstuvwxyz  ABCDEFGHIJKLMNÑOPQRSTUVWXYZ";
       especiales = "8-37-39-46-64";

       tecla_especial = false
       for(var i in especiales){
            if(key == especiales[i]){
                tecla_especial = true;
                break;
            }
        }

        if(letras.indexOf(tecla)==-1 && !tecla_especial){
            return false;
        }
        else  
        {tecla=(document.all) ? e.keyCode : e.which; 
        if(tecla==32) return true; }
    }
    
        function ValidarCampos(){
            var respuesta = 0;
            if($("#id_parroquia").val() == 0){
                Notificacion(0, "Debe seleccionar una parroquia.");
                $('body, html').animate({
                    scrollTop: '0px' 
                }, 300);
                respuesta = 0;
            }else if($("#nombre_sector").val() == 0){
                Notificacion(0, "Debe seleccionar el nombre de la parroquia.");
                $('body, html').animate({
                    scrollTop: '0px' 
                }, 300);
                respuesta = 0;
            }else{
                respuesta = 1;
            }
            
            return respuesta;
             
        }
        
        function Buscar( id_sector )
        {
            //alert();
            $.ajax({
                async:false, 
                cache:false,
                dataType:"html", 
                type: 'POST',   
                url: "../controlador/C_GestionSector.php",
                data: {
                        id_sector: id_sector,
                        buscar_sector: "JDHSJUHDWJDHSJHSJDS" 
                },
                success:  function(respuesta){

//                    alert( respuesta );
                    contenido = $.trim(respuesta); 

                    if(contenido !== "[]")
                    { 
                        var json_sector = $.parseJSON(contenido);
                        //alert(json_estado);
                        $("#id_sector").val( json_sector.id_sector );
                        $("#nombre_sector").val( json_sector.nombre_sector );
                        $("#id_estado").val( json_sector.id_estado );
                        $("#id_estado").change();
                        $("#id_municipio").val( json_sector.id_municipio );
                        $("#id_municipio").change();
                        $("#id_parroquia").val( json_sector.id_parroquia );
                        $("#id_parroquia").change();
                        //CargarMunicipios( json_parroquia.id_estado );
                        
                        $("#id_municipio").val( json_sector.id_municipio );
                        
                        $("#btn_registrar").attr("disabled","disabled");
                        $("#btn_modificar").removeAttr("disabled");
                        $("#btn_eliminar").removeAttr("disabled");
                        $("#btn_cancelar").removeAttr("disabled");
                        
                        
                        $("#sugerencias-nombres").fadeOut(10);
                        
                        ListarSectores( );
                    }
                    else
                    {
                        $("#sugerencias-nombres").fadeOut(10);
                    }

                },
                beforeSend:function(){
                    //alert('envie la data');
                },
                error:function(objXMLHttpRequest){}
            });
        }        
        
        
        
        function Notificacion( tipo, msj )
        {
            //alert( tipo+ ' '+msj );
            if( tipo == 0 )
            {
                $("#texto-error").text(msj);
                $("#mensaje-error").fadeIn(20);
                $("#mensaje-success").fadeOut(10);
                $("#mensaje-info").fadeOut(10);
            }
            else if( tipo == 1 )
            {
                $("#texto-success").text(msj);
                $("#mensaje-success").fadeIn(20);
                $("#mensaje-error").fadeOut(10);
                $("#mensaje-info").fadeOut(10);
                $("#to-top").pushStack();
            }
            else if( tipo == 2 )
            {
                $("#texto-info").text(msj);
                $("#mensaje-info").fadeIn(20);
                $("#mensaje-success").fadeOut(10);
                $("#mensaje-error").fadeOut(10);
            }
        }

        /*Funcion para cargar select de municipio*/
        function  CargarMunicipios( id_estado ){
            
            $.ajax({
                async:false, 
                cache:false,
                dataType:"html", 
                type: 'POST',   
                url: "../controlador/C_GestionMunicipio.php",
                data: {
                       id_estado: id_estado, 
                       cargar_municipio: "cargar_municipio" 
                },
                success:  function(respuesta){
                                        
                    if(respuesta !== "")
                    {                        
                        $("#id_municipio").html( respuesta );
                        ListarSectores( );
                    }
                    else
                    {
                        $("#id_municipio").html( respuesta );
                    }

                },
                beforeSend:function(){},
                error:function(objXMLHttpRequest){}
            });
            
        }
        
        /*Funcion para cargar select de parroquias*/
        function  CargarParroquias( id_municipio ){
            
            $.ajax({
                async:false, 
                cache:false,
                dataType:"html", 
                type: 'POST',   
                url: "../controlador/C_GestionParroquia.php",
                data: {
                       id_municipio: id_municipio, 
                       cargar_parroquia: "cargar_parroquia" 
                },
                success:  function(respuesta){
                                        
                    if(respuesta !== "")
                    {                        
                        $("#id_parroquia").html( respuesta );
                        ListarSectores( );
                    }
                    else
                    {
                        $("#id_parroquia").html( respuesta );
                    }

                },
                beforeSend:function(){},
                error:function(objXMLHttpRequest){}
            });
            
        }
        
        function OcultarListas()
        {
            $("#sugerencias-nombres").fadeOut(10);
            $("#sugerencias-nombres").empty();
        }
//        
//        /*FUNCION PARA ACTUALIZAR DATOS DE UN ESTADO*/
        function RegistrarSector( )
        {
            var resp = ValidarCampos();
            //alert(resp);
            if(resp == 1)
            {
                $.ajax({
                    async:false, 
                    cache:false,
                    dataType:"html", 
                    type: 'POST',   
                    url: "../controlador/C_GestionSector.php",
                    data: {
                            nombre_sector: $("#nombre_sector").val(),
                            id_parroquia: $("#id_parroquia").val(),
                            registrar_sector: "registrar_sector" 
                    },
                    success:  function(respuesta){

                        if(respuesta == 1)
                        { 
                            var msj = "Sector "+ nombre +" fue registrado.";
                            
                            $("#id_sector").val("");
                            $("#nombre_sector").val("");
                            $("#id_parroquia").val("0");

                            $("#btn_modificar").attr("disabled","disabled");
                            $("#btn_eliminar").attr("disabled","disabled");
                            $("#btn_cancelar").attr("disabled","disabled");

//                            $("#sugerencias-codigos").fadeOut(10);
                            $("#sugerencias-nombres").fadeOut(10);
                            Notificacion(1, msj);
                            ListarSectores( );

                        }
                        else
                        {
                            
                            var msj = respuesta;
                            Notificacion(0, msj); 
                        }


                    },
                    beforeSend:function(){},
                    error:function(objXMLHttpRequest){}
                }); //cierra el ajax
            }
            else{
                
            }
        }
//        
//        
//        /*FUNCION PARA ACTUALIZAR DATOS DE UN ESTADO*/
        function ModificarSector( )
        {
            var resp = ValidarCampos();

            if(resp == 1)
            {
                $.ajax({
                    async:false, 
                    cache:false,
                    dataType:"html", 
                    type: 'POST',   
                    url: "../controlador/C_GestionSector.php",
                    data: {
                            id_sector: $("#id_sector").val(),
                            nombre_sector: $("#nombre_sector").val(),
                            id_parroquia: $("#id_parroquia").val(),
                            modificar_sector: "modificar_sector" 
                    },
                    success:  function(respuesta){
                        
                        

                        if(respuesta == 1)
                        { 
                            Notificacion(2, "Los datos del sector fueron actualizados.");
                            $("#id_sector").val( "" );
                            //$("#codigo_cne_parroquia").val( "" );
                            $("#nombre_sector").val( "" );
                            $("#id_estado").val("");
                            $("#id_municipio").val("");
                            $("#id_parroquia").val("");
                            
                            $("#btn_registrar").removeAttr("disabled");
                            $("#btn_modificar").attr("disabled","disabled");
                            $("#btn_eliminar").attr("disabled","disabled");
                            $("#btn_cancelar").attr("disabled","disabled");
                            
                            $("#sugerencias-codigos").fadeOut(10);
                            $("#sugerencias-nombres").fadeOut(10);
                            
                            ListarSectores( );
                        }
                        else
                        {
                            
                            var msj = respuesta;
                            Notificacion(0, msj);
                        }

                    },
                    beforeSend:function(){},
                    error:function(objXMLHttpRequest){}
                });
            }else{
                
            }
        }
//        
//        /*FUNCION PARA ELIMINAR O INHABILITAR UN ESTADO*/
        function EliminarSector( )
        {
            $.ajax({
                async:false, 
                cache:false,
                dataType:"html", 
                type: 'POST',   
                url: "../controlador/C_GestionSector.php",
                data: {
                        id_sector: $("#id_sector").val(),
                        eliminar_sector: "eliminar_sector"
                },
                success:  function(respuesta){
                    
                    if(respuesta == 1)
                    { 
                        Notificacion(2, "El sector ha sido eliminado");
                        $("#id_sector").val( "" );
                        $("#nombre_sector").val( "" );
                        
                        $("#btn_registrar").removeAttr("disabled");
                        $("#btn_modificar").attr("disabled","disabled");
                        $("#btn_eliminar").attr("disabled","disabled");
                        $("#btn_cancelar").attr("disabled","disabled");
                        
                        $("#sugerencias-codigos").fadeOut(10);
                        $("#sugerencias-nombres").fadeOut(10);
                        
                        ListarSectores( );
                    }
                    else
                    {
                        
                        Notificacion(0, "Problemas con la base de datos");
                        $("#sugerencias-codigos").fadeOut(10);
                        $("#sugerencias-nombres").fadeOut(10);
                        alert(respuesta);
                    }

                },
                beforeSend:function(){},
                error:function(objXMLHttpRequest){}
            });
        }
//        
        /*FUNCION PARA BUSCAR SUGERENCIAS MIENTRAS SE ESCRIBE EN LOS CAMPOS*/
        function BuscarSugerencias()
        {            
            $.ajax({
                async:false, 
                cache:false,
                dataType:"html", 
                type: 'POST',   
                url: "../controlador/C_GestionSector.php",
                data: {

                        id_parroquia: $("#id_parroquia").val(),
                        nombre_sector: $("#nombre_sector").val(),
                        autocompletar: "autocompletar" 
                },
                success:  function(respuesta){

                    if(respuesta != "")
                    { 
                        $("#sugerencias-nombres").empty();
                        $("#sugerencias-nombres").html( respuesta );
                        $("#sugerencias-nombres").fadeIn(700);
                        ListarSectores( );
                    }
                    else
                    {
                        $("#sugerencias-nombres").empty();
                        $("#sugerencias-nombres").html('<li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>');
                        $("#sugerencias-nombres").fadeIn(700);
                    }

                },
                beforeSend:function(){},
                error:function(objXMLHttpRequest){}
            });
        }
        
        function Cancelar()
        {
            $("#id_estado").val( 0 );
            $("#id_municipio").val( 0 );
            $("#id_parroquia").val( 0 );
            $("#nombre_sector").val( "" );

            $("#btn_registrar").removeAttr("disabled");
            $("#btn_modificar").attr("disabled","disabled");
            $("#btn_eliminar").attr("disabled","disabled");
            $("#btn_cancelar").attr("disabled","disabled");
            
            $("#sugerencias-codigos").fadeOut(10);
            $("#sugerencias-nombres").fadeOut(10);
            
            $("#mensaje-error").fadeOut(10);
            $("#mensaje-success").fadeOut(10);
            $("#mensaje-info").fadeOut(10);
        }
//    
//    
//        /*FUNCION PARA ELIMINAR O INHABILITAR UN ESTADO*/
        function ListarSectores( )
        {
            $.ajax({
                async:false, 
                cache:false,
                dataType:"html", 
                type: 'POST',   
                url: "../controlador/C_GestionSector.php",
                data: {
                        
                        listar_sector: "sector" 
                },
                success:  function(respuesta){
                    
                    if(respuesta !== "")
                    { 
                        $("#div-tabla-sectores").html( respuesta );
                    }
                    else
                    {
                        $("#div-tabla-sectores").html( respuesta );
                    }

                },
                beforeSend:function(){},
                error:function(objXMLHttpRequest){}
            });
        }
    </script>
    
    
</head>
<body>
    <?php include("CabeceraMenu.php"); ?>
        <div id="page-wrapper" >
            <div id="mensaje-success" style="display: none;">
                <div id="msj" class="alert alert-success alert-dismissable">
                    <button type="button" onclick="$('#mensaje-success').fadeOut(5);" class="close" data-dismiss="men" aria-hidden="true">&times;</button>
                    <strong id="texto-success"></strong>
                </div>
            </div>
            <div id="mensaje-error" style="display: none;">
                <div id="msj" class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" onclick="$('#mensaje-error').fadeOut(5);" data-dismiss="" aria-hidden="true">&times;</button>
                    <strong id="texto-error"></strong>
                </div>
            </div>
            <div id="mensaje-info" style="display: none;">
                <div id="msj" class="alert alert-info alert-dismissable">
                    <button type="button" class="close" onclick="$('#mensaje-info').fadeOut(5);" data-dismiss="" aria-hidden="true">&times;</button>
                    <strong id="texto-info"></strong>
                </div>
            </div>
            <div id="page-inner">
             
             <div class="row">
                    <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Gestión de Sector 
                            </div>
                            <div class="panel-body">
                                <form class="form-horizontal style-form" method="post">
                                    <input type="hidden" id="id_sector">
                                    <div class="form-group">
                                        <label class="col-12 col-12 control-label">
                                            <strong><a id="asterisco-obligatorio">*</a> Selecciona el Estado Registrado:</strong>

                                        </label>
                                        <div class="col-sm-12">
                                        &nbsp;
                                        <select class="form-control" id="id_estado" onchange="CargarMunicipios( $(this).val() );">
                                            <option value="0">SELECCIONA EL ESTADO</option>
                                            
                                            <?php
                                                $estado->CargarEstados();
                                            ?>
                                            
                                        </select>
                                        <!--<p id="leyenda-campos">*Selecciona el estado al cual asignará el municipio</p>-->
                                        
                                        </div>
                                    </div>    
                                    <div class="form-group">
                                        <label class="col-12 col-12 control-label">
                                            <strong><a id="asterisco-obligatorio">*</a> Selecciona el Municipio Asociado al Estado Seleccionado:</strong>

                                        </label>
                                        <div class="col-sm-12">
                                        &nbsp;
                                        <select class="form-control" id="id_municipio" onchange="CargarParroquias( $(this).val() );">
                                            <option value="0">SELECCIONA EL MUNICIPIO</option>
                                        </select>
                                        <!--<p id="leyenda-campos">*Selecciona el estado al cual asignará el municipio</p>-->
                                        
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-12 col-12 control-label">
                                            <strong><a id="asterisco-obligatorio">*</a> Seleccione La Parroquia Asociado al Municipio Seleccionado:</strong>

                                        </label>
                                        <div class="col-sm-12">
                                        &nbsp;
                                        <select class="form-control" id="id_parroquia" onchange="OcultarListas()">
                                            <option value="0">SELECCIONA LA PARROQUIA</option>
                                        </select>
                                        <!--<p id="leyenda-campos">*Selecciona el estado al cual asignará el municipio</p>-->
                                        
                                        </div>
                                    </div>
                                        
                                    <div class="form-group">
                                        <label class="col-12 col-12 control-label">
                                            <strong><a id="asterisco-obligatorio">*</a> Nombre del Sector</strong>
                                        </label>
                                        <div class="col-12">
                                            <input type="text" id="nombre_sector" onkeypress="return Let(event)" style="text-transform: uppercase;" onkeyup="BuscarSugerencias()" placeholder="Ingresa el nombre del sector" class="form-control">
                                            <ul class="autocompletar" id="sugerencias-nombres"></ul>
                                            <p id="leyenda-campos">*Nombre del sector (Ej. Sectores aledaños a las capitales de municipios)</p>
                                        </div>
                                    </div>
                                    
                                    <br>
                                    <center>
                                        <div class="">
                                            <button type="button" onclick="RegistrarSector()" id="btn_registrar" class="btn btn-success">Registrar</button>
                                            <button type="button" disabled="" onclick="ModificarSector()" id="btn_modificar" class="btn btn-primary">Modificar</button>
                                            <button type="button" disabled="" data-toggle="modal" data-target="#confirmar" id="btn_eliminar" class="btn btn-danger">Eliminar</button>
                                            <button type="button" disabled="" id="btn_cancelar" onclick="Cancelar()" class="btn btn-default">Cancelar</button>
                                        </div><!-- /showback -->
                                    </center>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Sectores Registrados
                                <a href="../reportes/ReporteLocalizacion.php">
                                    <img src="../assets/img/pdf5.png" style="width: 30px; height: 30px; float: right; margin-top: -6px;">
                                </a>
                            </div>
                            <div class="panel-body">
                                <div class="table-responsive" id="div-tabla-sectores">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

</div>
             <!--CONTENIDO A MOSTRAR EN VENTANA MODAL CUANDO PRESIONE ICONO DE AYUDA-->
               
      <div class="modal fade" id="confirmar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                      <h4 class="modal-title" id="myModalLabel">¡Mensaje de Advertencia!</h4>
                    </div>
                    <div class="modal-body">
                        ¿Desea eliminar este sector?
                        Una vez eliminado no podra recuperar sus datos.
                    </div>
                    <div class="modal-footer">
                        <button type="button"data-dismiss="modal" class="btn btn-danger" onclick="EliminarSector()">Eliminar</button>
                      <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                    </div>
                </div>
            </div>
        </div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="../assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="../assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="../assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                ListarSectores();
            });
    </script>
         <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
    
   
</body>
</html>