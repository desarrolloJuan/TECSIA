
<div id="wrapper">
    <header id="head">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html"><strong>T E C S I A</strong></a> 
            </div>
        <div style="color: #0088df; /*padding: 15px 50px 5px 50px;*/ float: right; font-size: 16px;">  
            <div class="top-menu">
                <ul class="nav pull-right top-menu" style="margin-right: 20px;">
                    <div class="btn-group">
                        <button type="button" style="background: transparent; color: white;" class="btn btn-theme04 dropdown-toggle" data-toggle="dropdown">
                            <img class="btn btn-default btn-circle" src="../assets/img/<?php echo $_SESSION['foto_perfil']; ?>">
                            <strong>
                                <?php
                                    $nom = explode(" ", $_SESSION['nombres']);
                                    echo $nom[0];
                                ?>
                            </strong>
                            <!--<i style="font-size: 15px; width: 15px; height: 15px; padding: 3px;" class="fa fa-user"></i>-->
                            <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Mi Cuenta</a></li>
                          <li><a href="../controlador/C_Sesion.php?cerrar=1">Cerrar Sesión</a></li>
                        </ul>
                    </div>
            	</ul>
            </div>
    </div>
        </nav>
    </header>
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <!--<li class="text-center">
                        <img src="../assets/img/find_user.png" class="user-image img-responsive"/>
                    </li>-->		
                    <li>
                        <a  href="Inicio.php"><i class="fa fa-home fa-2x"></i> Inicio</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-cog fa-2x"></i> Administrar<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="V_GestionInterrogante.php">Interrogante</a>
                            </li>
                            <li>
                                <a href="V_GestionarDones.php">Dones</a>
                            </li>
                            <li>
                                <a href="V_GestionDiscipulado.php">Discipulado</a>
                            </li>
                            <li>
                                <a href="V_GestionCodigoTelefonico.php">Código Telefónico</a>
                            </li>
                            <li>
                                <a href="V_GestionarEstadoCivil.php">Estado Civil</a>
                            </li>
                            <li>
                                <a href="V_GestionProfesionOcupacion.php">Profesión / Ocupación</a>
                            </li>
                            <!---->
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-map-marker fa-2x"></i>Localización<span class="fa arrow"></span></a>
                        <ul class="nav nav-third-level">
                            <li>
                                <a href="V_GestionEstado.php">Estado</a>
                            </li>
                            <li>
                                <a href="V_GestionMunicipio.php">Municipio</a>
                            </li>
                            <li>
                                <a href="V_GestionParroquia.php">Parroquia</a>
                            </li>
                            <li>
                                <a href="V_GestionSector.php">Sector</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-book fa-2x"></i> Iglesia<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="V_GestionIglesia.php">Gestionar Iglesia</a>
                            </li>
                            <li>
                                <a href="V_GestionPastor.php">Pastor</a>
                            </li>
                            <li>
                                <a href="V_GestionMiembro.php">Miembro</a>
                            </li>
                            <li>
                                <a href="V_GestionNuevoCreyente.php">Nuevo Creyente</a>
                            </li>
                            <li>
                                <a href="V_GestionarDepartamento.php">Departamento</a>
                            </li>
                            <li>
                                <a href="V_GestionarMinisterio.php">Ministerio</a>
                            </li>
                            <li>
                                <a href="V_GestionDiscipulado.php">Discipulado</a>
                            </li>
                        </ul>
                    </li>
                    <li id="ACTIVIDAD">
                        <a  href="V_GestionUsuarios.php"><i class="fa fa-calendar fa-2x"></i> Actividad <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li id="GESTIONAR_ACTIVIDAD">
                                <a href="">Gestionar Actividad</a>
                            </li>
                            <li id="GESTIONAR_PERFIL">
                                <a href="">Calendario de Actividades</a>
                            </li>
                        </ul>
                    </li>
                    <li id="USUARIO">
                        <a  href="V_GestionUsuarios.php"><i class="fa fa-user fa-2x"></i> Usuario <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li id="GESTIONAR_USUARIO">
                                <a href="V_GestionUsuarios.php">Gestionar Usuario</a>
                            </li>
                            <li id="GESTIONAR_PERFIL">
                                <a href="V_GestionPerfil.php">Gestionar Perfil</a>
                            </li>
                            <li id="GESTIONAR_PREGUNTAS_SEGURIDAD">
                                <a href="V_GestionPreguntasDeSeguridad.php">Gestionar Preguntas de Seguridad</a>
                            </li>
                        </ul>
                    </li>
                    <li id="MANTENIMIENTO">
                        <a><i class="fa fa-wrench fa-2x"></i> Mantenimiento <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li id="BITACORA">
                                <a href="">Bitácora de Usuarios</a>
                            </li>
                            <li id="RESPALDAR-BD">
                                <a href="">Respaldar Base de Datos</a>
                            </li>
                            <li id="RESTAURAR-BD">
                                <a href="">Restaurar Base de Datos</a>
                            </li>
                        </ul>
                    </li>
                </ul>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        
        