<?php

function crea_fichero($cadena){
    $flujo = fopen('BaseDeDatos.xml', 'w');//creamos el fichero.
    fputs($flujo, $cadena);//copiamos el contenido de cadena al fichero
    fclose($flujo);//cerramos el flujo
}


$opc = array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8");
$dsn = "mysql:host=localhost;dbname=iglesia";//datos conexion bbdd
$usuario = 'root';
$contrasena = 'root';

$dwes = new PDO($dsn, $usuario, $contrasena, $opc);//conexion

/* 
 * Preparamos la consulta para obtener las tablas.
 */
$sql="SHOW TABLES";

if (isset($dwes)){
    $resultado = $dwes->query($sql);//obtenemos las tablas de la base de datos
    $xml="<?xml version=\"1.0\"?>\n";//variable que contendra el codigo xml
    $xml .= "<informacion>\n";

    while($row = $resultado->fetch()){

        $sql2="SELECT * FROM ".$row[0];//consulta las tablas dinamicamente
        echo $sql2;
        echo '<br/>';
        $xml .= "\t<".$row[0].">\n";//tabla de la base de datos
        $result= $dwes->query($sql2);//obtenemos todos los campos de la  tabla

        while($fila = $result->fetch(PDO::FETCH_ASSOC)){

            $xml .= "\t\t<registro>\n";//por cada registro de la tabla

            foreach ($fila as $k => $v) {//recorremos las claves y los valores de cada registro
                echo "$k => $v.\n";
                echo "<br/>";

                $xml .= "\t\t\t<".$k.">".$v."</".$k.">\n";//los almacenamos en el xml
            }
            $xml .= "\t\t</registro>\n";//cerramos el registro
        }
        $xml .= "\t</".$row[0].">\n";//cerramos la tabla
    }
    $xml .="</informacion>";//cerramos el fichero xml
    //echo $xml;

    crea_fichero($xml);
}

?>

