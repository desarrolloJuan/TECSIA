<?php
$estado_session = session_status();

if($estado_session == PHP_SESSION_NONE)
{
    session_start();
}
else{}

include_once("../modelo/PreguntaSeguridad.php");
$preguntas = new PreguntaSeguridad();

?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>TECSIA | Usuario</title>
    
    <!--HOJAS DE ESTILO Y FUENTES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/css/custom.css" rel="stylesheet" />
    <link href="../assets/css/estilo.css" rel="stylesheet" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link href="../assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />    
    
    <style>
        
        .disponible {
    color: green;
    font-weight: bold;
    font-size: 12px;
    position: relative;
}
        
       .no-disponible {
    color: red;
    font-weight: bold;
    font-size: 12px;
    position: relative;
}
        
    </style>
    
</head>
    <body id="body">
    <?php include("CabeceraMenu.php"); ?>
        <div id="page-wrapper" >
            <div id="mensaje-success" style="display: none;">
                <div id="msj" class="alert alert-success alert-dismissable">
                    <button type="button" onclick="$('#mensaje-success').fadeOut(5);" class="close" data-dismiss="men" aria-hidden="true">&times;</button>
                    <strong id="texto-success"></strong>
                </div>
            </div>
            <div id="mensaje-error" style="display: none;">
                <div id="msj" class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" onclick="$('#mensaje-error').fadeOut(5);" data-dismiss="" aria-hidden="true">&times;</button>
                    <strong id="texto-error"></strong>
                </div>
            </div>
            <div id="mensaje-info" style="display: none;">
                <div id="msj" class="alert alert-info alert-dismissable">
                    <button type="button" class="close" onclick="$('#mensaje-info').fadeOut(5);" data-dismiss="" aria-hidden="true">&times;</button>
                    <strong id="texto-info"></strong>
                </div>
            </div>
            <div id="page-inner">
             
             <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Gestión de Usuario <i data-toggle="modal" data-target="#listado_usuarios" style="float: right; color: #0088ff; cursor: pointer;" title="Ver catalogo de registros" class="fa fa-table fa-2x"></i>
                            </div>
                            <div class="panel-body">
                                <form class="form-horizontal style-form" method="post">
                                    <input type="hidden" id="id_usuario">
                                
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">
                                        <label class="col-md-12 col-sm-12 control-label">
                                            <center>Foto de Perfil</center>
                                            <br>
                                            <center>
                                                <output id="foto_cargada"><img src="../assets/img/find_user.png" style="width: 170px; height: 200px;"></output>
                                                <!---->
                                            </center>
                                            <br>
                                                <input type="file" style="border: solid 1px #0088ff; width: 100%;" id="foto_perfil">
                                                    <div id="barra">
                                                    
                                                    </div>
                                                <script>
                                                    function MostrarFoto( evt ) 
                                                    {
                                                        var files = evt.target.files; // FileList object

                                                        // Obtenemos la imagen del campo "file".
                                                        for (var i = 0, f; f = files[i]; i++) {
                                                          //Solo admitimos imágenes.
                                                          if ( !f.type.match('image.*') ) {
                                                                continue;
                                                          }

                                                          var reader = new FileReader();

                                                          reader.onload = ( function(theFile) {
                                                                return function(e) {
                                                                  // Insertamos la imagen
                                                                /*var i = 0;
                                                                while( i <= 100 )
                                                                { 
                                                                    document.getElementById("barra").innerHTML = ['<div class="progress progress-striped"><div id="barra-progreso" class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="',i,'" aria-valuemin="0" aria-valuemax="100" style="width: ',i,'%;"><span class="sr-only"></span></div></div>'].join('');
                                                                    
                                                                    i++
                                                                    alert(i);
                                                                }*/
                                                                  
                                                                document.getElementById("foto_cargada").innerHTML = ['<img style="width: 170px; height: 200px;" src="', e.target.result,'" title="', escape(theFile.name), '"/>'].join('');
                                                                };
                                                          })(f);

                                                          reader.readAsDataURL(f);
                                                        }
                                                    }

                                                    document.getElementById('foto_perfil').addEventListener('change', MostrarFoto, false);
                                                </script>
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="col-md-8 col-sm-8">
                                    <div class="col-md-7 col-sm-7">
                                            <strong><a id="asterisco-obligatorio">*</a> Cédula:</strong>
                                            <input type="text" id="cedula" maxlength="8" onkeyup="BuscarSugerencias()" placeholder="Ingresa la cédula del usuario" class="form-control">
                                            <ul class="autocompletar" id="sugerencias-cedulas"></ul>
                                            <p id="leyenda-campos">*Cédula del usuario a gestionar</p>
                                            
                                    </div>
                                    <div class="col-md-11 col-sm-11">
                                        <strong><a id="asterisco-obligatorio">*</a> Nombre de Usuario:</strong>
                                        <input type="text" id="nombre_usuario" style="text-transform: uppercase;" maxlength="16" autocomplete="off" onkeyup="BuscarDisponibilidad()" placeholder="Ingresa el nombre de usuario" class="form-control">
                                        <span class="disponible" style="display: none;" id="mensaje-disponibilidad">Error</span>
                                        <p id="leyenda-campos">*Usuario que usará para ingresar al sistema. (Entre 8 y 16 caracteres)</p>
                                    </div>
                                    <div class="col-md-11 col-sm-11">
                                        <strong><a id="asterisco-obligatorio">*</a> Clave:</strong>
                                        <div class="input-group">
                                            <input type="password" id="clave" maxlength="16" autocomplete="off" placeholder="Ingrese la clave" class="form-control" />
                                            <span class="form-group input-group-btn">
                                                <button id="btn_ver_clave" onmousedown="VerClave()" onmouseout="OcultarClave()" class="btn btn-default" title="Ver clave" type="button">
                                                    <i class="fa fa-eye"></i>
                                                </button>
                                            </span>
                                        </div>
                                        <p id="leyenda-campos">*Clave que usuará para ingresar al sistema. (Entre 8 y 16 caracteres)</p>
                                    </div>
                                </div>
                                        <br>
                                <div class="col-md-11 col-sm-11">
                                    <div class="form-group">
                                        <label class="col-md-5 col-sm-5 control-label">
                                            <strong><a id="asterisco-obligatorio">*</a> Pregunta de Seguridad:</strong>
                                        </label>
                                        <div class="col-md-7 col-sm-7">
                                            <select id="id_pregunta" class="form-control">
                                                <?php
                                                    $preguntas->CargarPreguntas();
                                                ?>
                                            </select>
                                            <p id="leyenda-campos">*Pregunta que le será de ayuda en caso de olvidar los datos de la cuenta</p>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="col-md-5 col-sm-5 control-label">
                                            <strong><a id="asterisco-obligatorio">*</a> Respuesta de Seguridad:</strong>
                                        </label>
                                        <div class="col-md-7 col-sm-7">
                                            <textarea style="resize: none;" class="form-control" maxlength="200" placeholder="Ingresa la respuesta" id="respuesta"></textarea>
                                            <p id="leyenda-campos">*Respuesta que le será de ayuda en caso de olvidar los datos de la cuenta</p>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-5 col-sm-5 control-label">
                                            <strong><a id="asterisco-obligatorio">*</a> Estado del Usuario:</strong>
                                        </label>
                                        <div class="col-md-6 col-sm-6">
                                            <select id="status_usuario" class="form-control">
                                                <option value="">SELECCIONE EL ESTADO</option>
                                                <option value="1">ACTIVO</option>
                                                <option value="0">INACTIVO</option>
                                            </select>
                                            <p id="leyenda-campos">*Estado ó status de la cuenta de usuario</p>
                                        </div>
                                    </div>
                                </div>
                                        <br>
                                    <center>
                                        <div class="col-md-12 col-sm-12">
                                            <button type="button" onclick="RegistrarUsuario()" id="btn_registrar" class="btn btn-success">Registrar</button>
                                            <button type="button" disabled="" onclick="ModificarEstado()" id="btn_modificar" class="btn btn-primary">Modificar</button>
                                            <button type="button" disabled="" data-toggle="modal" data-target="#confirmar" id="btn_eliminar" class="btn btn-danger">Eliminar</button>
                                            <button type="button" id="btn_cancelar" onclick="Cancelar()" class="btn btn-default">Cancelar</button>
                                            <input type="button" value="ver" data-toggle="modal" data-target="#ventana-datos-personales">
                                        </div><!-- /showback -->
                                    </center>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

</div>
        
        <div class="modal fade" id="ventana-datos-personales" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
            <div class="modal-dialog" style="width: 90%;">
                <div class="modal-content">
                    <div class="modal-header">
                        <button id="cerrar-dialog-persona" type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                      <h4 class="modal-title" id="myModalLabel">Datos Personales</h4>
                    </div>
                    <div class="modal-body">
                        
                        <form class="form-horizontal style-form" method="post">
                                <div class="col-md-12 col-sm-12">
                                    <div class="col-md-6 col-sm-6">
                                            <strong><a id="asterisco-obligatorio">*</a> Cédula:</strong>
                                            <input type="text" id="cedula2" disabled="" maxlength="8" class="form-control">
                                            <p id="leyenda-campos">*Cédula del usuario a gestionar</p>
                                            
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12">
                                    <div class="col-md-6 col-sm-6">
                                        <strong><a id="asterisco-obligatorio">*</a> Nombres:</strong>
                                        <input type="text" id="nombres" style="text-transform: uppercase;" maxlength="50" placeholder="Ingrese sus nombres" class="form-control">
                                        <p id="leyenda-campos">*Usuario que usará para ingresar al sistema. (Entre 8 y 16 caracteres)</p>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <strong><a id="asterisco-obligatorio">*</a> Apellidos:</strong>
                                        <input type="text" id="apellidos" style="text-transform: uppercase;" maxlength="50" placeholder="Ingrese sus apellidos" class="form-control">
                                        <p id="leyenda-campos">*Usuario que usará para ingresar al sistema. (Entre 8 y 16 caracteres)</p>
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12">
                                    <div class="col-md-6 col-sm-6">
                                        <strong><a id="asterisco-obligatorio">*</a> Sexo:</strong>
                                        <select id="sexo" class="form-control">
                                            <option value="">SELECCIONE EL SEXO</option>
                                            <option value="F">FEMENINO</option>
                                            <option value="M">MASCULINO</option>
                                        </select>
                                        <p id="leyenda-campos">*Debe seleccionar su sexo correspondiente</p>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <strong><a id="asterisco-obligatorio">*</a> Fecha de Nacimiento:</strong>
                                        <input type="text" id="apellidos" style="text-transform: uppercase;" maxlength="50" placeholder="Ingrese sus apellidos" class="form-control">
                                        <p id="leyenda-campos">*Seleccione del calendario su fecha de nacimiento</p>
                                    </div>
                                </div>
                            
                            <hr class="br">
                            
                                <div class="col-md-12 col-sm-12">
                                    <div class="col-md-6 col-sm-6">
                                        <strong><a id="asterisco-obligatorio">*</a> Estado:</strong>
                                        <select id="sexo" class="form-control">
                                            <option value="">SELECCIONE EL ESTADO</option>
                                        </select>
                                        <p id="leyenda-campos">*Debe seleccionar su sexo correspondiente</p>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <strong><a id="asterisco-obligatorio">*</a> Estado:</strong>
                                        <select id="sexo" class="form-control">
                                            <option value="">SELECCIONE EL ESTADO</option>
                                        </select>
                                        <p id="leyenda-campos">*Debe seleccionar su sexo correspondiente</p>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <strong><a id="asterisco-obligatorio">*</a> Estado:</strong>
                                        <select id="sexo" class="form-control">
                                            <option value="">SELECCIONE EL ESTADO</option>
                                        </select>
                                        <p id="leyenda-campos">*Debe seleccionar su sexo correspondiente</p>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <strong><a id="asterisco-obligatorio">*</a> Estado:</strong>
                                        <select id="sexo" class="form-control">
                                            <option value="">SELECCIONE EL ESTADO</option>
                                        </select>
                                        <p id="leyenda-campos">*Debe seleccionar su sexo correspondiente</p>
                                    </div>
                                </div>
                                    
                                    
                                    

                                    <center>
                                        <div class="col-md-12 col-sm-12">
                                            <button type="button" onclick="RegistrarUsuario()" id="btn_registrar" class="btn btn-success">Registrar</button>
                                            <button type="button" disabled="" onclick="ModificarEstado()" id="btn_modificar" class="btn btn-primary">Modificar</button>
                                            <button type="button" disabled="" data-toggle="modal" data-target="#confirmar" id="btn_eliminar" class="btn btn-danger">Eliminar</button>
                                            <button type="button" id="btn_cancelar" onclick="Cancelar()" class="btn btn-default">Cancelar</button>
                                        </div><!-- /showback -->
                                    </center>
                                </form>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button"data-dismiss="modal" class="btn btn-danger" onclick="RegistrarPersona()">Registrar</button>
                      <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                    </div>
                </div>
            </div>
        </div>
    
      <div class="modal fade" id="confirmar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                      <h4 class="modal-title" id="myModalLabel">¡Mensaje de Advertencia!</h4>
                    </div>
                    <div class="modal-body">
                        ¿Desea eliminar este estado?
                        Una vez eliminado no podra recuperar sus datos.
                    </div>
                    <div class="modal-footer">
                        <button type="button"data-dismiss="modal" class="btn btn-danger" onclick="EliminarEstado()">Eliminar</button>
                      <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="modal fade" id="listado_usuarios" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog" style="width: 90%;">
                <div class="modal-content">
                    <div class="modal-header">
                        <button id="ocultar-tabla-usuarios" type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                      <h4 class="modal-title" id="myModalLabel">Usuarios Registrados</h4>
                    </div>
                    <div class="modal-body" id="div-tabla-usuarios">
                        <div class="col-md-12 col-sm-12">

                        </div>
                        
                        
                    </div>
                </div>
            </div>
        </div>
             
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="../assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="../assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="../assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                ListarUsuario();
            });
    </script>
         <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
    <script src="../assets/js/JqueryModulos/GestionUsuario.js"></script>
   
</body>
</html>


