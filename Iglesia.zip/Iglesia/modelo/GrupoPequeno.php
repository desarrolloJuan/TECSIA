<?php

include_once("conexionBD.php");

class Grupo_Pequeno {
    
    private $_IdGrupo;
    private $_NombreGrupo;
    private $_StatusGrupo;
    private $conn;
    
    
    public function get_IdGrupo() {
        return $this->_IdGrupo;
    }

    public function get_NombreGrupo() {
        return $this->_NombreGrupo;
    }

    public function get_StatusGrupo() {
        return $this->_StatusGrupo;
    }

    public function set_IdGrupo($_IdGrupo) {
        $this->_IdGrupo = $_IdGrupo;
    }

    public function set_NombreGrupo($_NombreGrupo) {
        $this->_NombreGrupo = $_NombreGrupo;
    }

    public function set_StatusGrupo($_StatusGrupo) {
        $this->_StatusGrupo = $_StatusGrupo;
    }
  
    //CONSTRUCTOR DE LA CLASE
    function __construct() {
        
    }
    
    //funcion para buscar los datos de un estado especifico
    public function BuscarDatosGrupo_Pequeno()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $datos = array();
        
        //TIRA SQL PARA CAPTURAR DATOS DEL ESTADO
        $sql = 'SELECT nombre_grupo, status_grupo FROM grupo_pequeno WHERE id_grupo = "'.$this->get_IdGrupo().'"';
       
        //MANDO EJECUTAR EL QUERY
        $buscar = $conn->ejecutarQuery($sql);
        
        //VERIFICO QUE HAYAN RESULTADOS
        if( mysql_num_rows($buscar) > 0 )
        {
            //RECORRO EL REGISTRO, O LA FILA
            while( $row = mysql_fetch_array($buscar) )
            {
                $datos['id_grupo'][0] = $this->get_IdGrupo();
                $datos['nombre_grupo'][0] = $row['nombre_grupo'];//CAPTURO NOMBRE DEL ESTADO
                $datos['status_grupo'][0] = $row['status_grupo'];//CAPTURO STATUS DEL ESTADO
            }
        }
        else
        {
            //igualo el array a vacio, esto en caso de encontrar resultados
            $datos['id_grupo'][0] = ""; 
            $datos['nombre_grupo'][0] = "";
            $datos['status_grupo'][0] = "";
        }
        
        echo json_encode( $datos ); //CONVIERTO EL ARRAY EN JSON PARA USARLO EN EL AJAX
        //ESTE SE RECIBE EN AJAX EN respuesta
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function RegistrarGrupo_Pequeno()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //consulto para verficar que no exista el estado que se desea registrar
        $verficar = $conn->ejecutarQuery("SELECT id_grupo FROM grupo_pequeno WHERE nombre_grupo = '".$this->get_NombreGrupo()."' AND status_grupo = '1'");
        //verifico que el estado no haya sido inactivado
        $verificar_inactividad = $conn->ejecutarQuery("SELECT id_grupo FROM grupo_pequeno WHERE nombre_grupo = '".$this->get_NombreGrupo()."'  AND status_grupo = '0'");
        
        if(mysql_num_rows($verficar) > 0 ) //en caso de encontrar un nombre de estado igual al ingresado por el usuario
        {
            //devuelvo este msj que se mostrará al usuario
            $resp = "Ya existe el grupo que desea registrar, verifique el nombre del grupo, e intente nuevamente";
        }
         else if(mysql_num_rows($verificar_inactividad) > 0 ) 
        {
            //si estaba inactivo se procede a cambiar el status mediante un update
            while( $row = mysql_fetch_array($verificar_inactividad) )
            {
                $sql = "UPDATE grupo_pequeno SET status_grupo = '1' WHERE id_grupo = '".$row['id_grupo']."' ";

                //MANDO EJECUTAR EL QUERY
                $registrar = $conn->ejecutarQuery($sql);

                //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
                if( $registrar > 0 )
                {
                    //esta variable se retorna como respuesta que recibira el ajax
                    $resp = 1;
                }
                else
                {
                    //si hubo algun problema con la base de datos se devolvera este msj
                    $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
                }
            }
        }
        else //en caso que no se encuentren coincidencias, es decir no exista el estado, se procede a realizar la insercion
        {
            //TIRA SQL PARA registrar DATOS DEL ESTADO
            $sql = "INSERT INTO grupo_pequeno(nombre_grupo, status_grupo) VALUES('".$this->get_NombreGrupo()."', '1')";

            //MANDO EJECUTAR EL QUERY
            $registrar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
            if( $registrar > 0 )
            {
                //si la insercion fue realizada de manera correcta
                $resp = 1;
            }
            else
            {
                //si hubo un problema durante la insercion
                $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
            }
        }
        
        echo $resp;
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function ModificarGrupo_Pequeno()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        //echo "SELECT id_estado FROM estado WHERE nombre_estado = '".$this->get_NombreEstado()."' OR codigo_cne_estado = '".$this->get_CodigoCneEstado()."'";
        //consulto para verficar que no existan algo repetido
        $verficar = $conn->ejecutarQuery("SELECT id_grupo FROM grupo_pequeno WHERE nombre_grupo = '".$this->get_NombreGrupo()."' AND status_grupo = '1'");
        //echo mysql_num_rows($verficar);
        if( mysql_num_rows($verficar) > 0 )
        {
            $resp = "Ya existe un Grupo con este nombre, verifique el nombre del grupo e intente nuevamente.";
        }
        else
        {        
            $sql = "UPDATE grupo_pequeno SET  nombre_grupo = '".$this->get_NombreGrupo()."', status_grupo = '1' WHERE id_grupo = '".$this->get_IdGrupo()."'";

            //MANDO EJECUTAR EL QUERY
            $modificar = $conn->ejecutarQuery($sql) or die (mysql_error());

            //VERIFICO QUE SE HAYA REALIZADO la modificacion
            if( $modificar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = "Problemas con la base de datos, intente nuevamente, si el problema persiste comuniquese con el administrador del sistema";
            }
                
        }
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    
    public function EliminarGrupo_Pequeno()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        $SQL_verificar = "SELECT id_grupo FROM grupo_pequeno WHERE id_grupo = '".$this->get_IdGrupo()."'";
        
        $verificar = $conn->ejecutarQuery($SQL_verificar);
        
        
        if(mysql_num_rows($verificar) > 0 )
        {
            //en caso de que este relacionado, hacemos una actualizacion y pasa a inactivo.. eliminacion logica
            
        $sql = "UPDATE grupo_pequeno SET status_grupo = '0' WHERE id_grupo = '".$this->get_IdGrupo()."'";

            //MANDO EJECUTAR EL QUERY
        $eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el update
        if( $eliminar > 0 )
        {
           $resp = 1;
            }
        else
         {
         $resp = 0;
           }
            }
        else
        {
            //en caso de no estar relacionado aplicamos eliminacion fisica
            //TIRA SQL PARA eliminar DATOS DEL ESTADO
            $sql = "DELETE FROM grupo_pequeno WHERE id_grupo = '".$this->get_IdGrupo()."'";

            //MANDO EJECUTAR EL QUERY
            $eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el borrado
            if( $eliminar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    /*FUNCION PARA BUSCAR SUGERENCIAS DE CODIGO Y NOMBRE DEL ESTADO*/
    public function SugerenciasDeGrupo_Pequeno($nombre_grupo)
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $sql = 'SELECT id_grupo, nombre_grupo FROM grupo_pequeno WHERE nombre_grupo LIKE "%'.$nombre_grupo.'%" AND status_grupo = 1';
        /*EJECUTO EL QUERY*/
        $buscar = $conn->ejecutarQuery( $sql );

        if( mysql_num_rows($buscar) > 0 )
        {
            while($row = mysql_fetch_array($buscar))
            {
                
                echo' 
                    <li onclick="Buscar('.$row['id_grupo'].')">'.$row['nombre_grupo'].'</li>
                 ';
                
            }
        }
        else
        {
            echo' 
                    <li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>
                 ';
        }
        
        
        $conn->cerrar();
    }
    
    /*funcion para cargar el catalogo*/
    public function ListaGrupo_Pequeno()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT id_grupo, nombre_grupo FROM grupo_pequeno WHERE status_grupo = '1' ORDER BY nombre_grupo ASC";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
        if( mysql_num_rows( $buscar ) > 0 )
        {
            echo ' 
                    <table class="table table-striped table-bordered table-hover" id="tabla_grupo">
                        <thead>
                            <tr>
                                <th width="60%">Nombre Grupo</th>
                                <th width="15%">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tabla_grupo">

              ';
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <tr onclick="Buscar('.$row['id_grupo'].')"> 
                            <td width="60%">'.$row['nombre_grupo'].' </td>
                            <td width="15%"> a</td>   
                        </tr>
                    ';
            }
            echo '  
                    </tbody>
                </table>
                
                <script>
                        $("#tabla_grupos").dataTable();
                    
                </script>
              ';
        }
        else
        {
            echo'
                    <tr> 
                        <td colspan="3">NO HAY GRUPOS REGISTRADOS</td>
                    </tr>                   
                ';
        }
    }
}