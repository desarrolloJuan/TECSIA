<?php

include_once("conexionBD.php");

class Municipio {
    
    private $_IdMunicipio;
    private $_CodigoCneMunicipio;
    private $_NombreMunicipio;
    private $_StatusMunicipio;
    private $_IdEstado;
    
    function get_IdMunicipio() {
        return $this->_IdMunicipio;
    }

    function get_CodigoCneMunicipio() {
        return $this->_CodigoCneMunicipio;
    }

    function get_NombreMunicipio() {
        return $this->_NombreMunicipio;
    }

    function get_StatusMunicipio() {
        return $this->_StatusMunicipio;
    }

    function get_IdEstado() {
        return $this->_IdEstado;
    }

    function set_IdMunicipio($_IdMunicipio) {
        $this->_IdMunicipio = $_IdMunicipio;
    }

    function set_CodigoCneMunicipio($_CodigoCneMunicipio) {
        $this->_CodigoCneMunicipio = $_CodigoCneMunicipio;
    }

    function set_NombreMunicipio($_NombreMunicipio) {
        $this->_NombreMunicipio = $_NombreMunicipio;
    }

    function set_StatusMunicipio($_StatusMunicipio) {
        $this->_StatusMunicipio = $_StatusMunicipio;
    }

    function set_IdEstado($_IdEstado) {
        $this->_IdEstado = $_IdEstado;
    }
    
    function __construct() {
        
    }
    
    
    //funcion para buscar los datos de un municipio especifico
    public function BuscarDatosMunicipio()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $datos = array();
        
        //TIRA SQL PARA CAPTURAR DATOS DEL MUNICIPIO
        $sql = 'SELECT codigo_cne_municipio, nombre_municipio, status_municipio, id_estado FROM municipio WHERE id_municipio = "'.$this->get_IdMunicipio().'"';
        
        //MANDO EJECUTAR EL QUERY
        $buscar = $conn->ejecutarQuery($sql);
        
        //VERIFICO QUE HAYAN RESULTADOS
        if( mysql_num_rows($buscar) > 0 )
        {
            //RECORRO EL REGISTRO, O LA FILA
            while( $row = mysql_fetch_array($buscar) )
            {
                $datos['id_municipio'][0] = $this->get_IdMunicipio(); 
                $datos['codigo_cne_municipio'][0] = $row['codigo_cne_municipio']; //CAPTURO CODIGO DEL MUNICIPIO
                $datos['nombre_municipio'][0] = $row['nombre_municipio'];//CAPTURO NOMBRE DEL MUNICIPIO
                $datos['status_municipio'][0] = $row['status_municipio'];//CAPTURO STATUS DEL MUNICIPIO
                $datos['id_estado'][0] = $row['id_estado'];//CAPTURO STATUS DEL MUNICIPIO
            }
        }
        else
        {
            //igualo el array a vacio, esto en caso de encontrar resultados
            $datos['id_municipio'][0] = ""; 
            $datos['codigo_cne_municipio'][0] = "";
            $datos['nombre_municipio'][0] = "";
            $datos['status_municipio'][0] = "";
            $datos['id_estado'][0] = "";
        }
        
        echo json_encode( $datos ); //CONVIERTO EL ARRAY EN JSON PARA USARLO EN EL AJAX
        //ESTE SE RECIBE EN AJAX EN respuesta
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function RegistrarMunicipio(  )
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //consulto para verficar que no exista el municipio que se desea registrar
        $verficar = $conn->ejecutarQuery("SELECT id_municipio FROM municipio WHERE nombre_municipio = '".$this->get_NombreMunicipio()."' AND id_estado = '".$this->get_IdEstado()."' AND status_municipio = '1'");
        $verificar_codigo_cne = $conn->ejecutarQuery("SELECT id_municipio FROM municipio WHERE codigo_cne_municipio = '".$this->get_CodigoCneMunicipio()."' AND status_municipio = '1'");
        //verifico que el MUNICIPIO no haya sido inactivado
        $verificar_inactividad = $conn->ejecutarQuery("SELECT id_municipio FROM municipio WHERE codigo_cne_municipio = '".$this->get_CodigoCneMunicipio()."' AND nombre_municipio = '".$this->get_NombreMunicipio()."' AND id_estado = '".$this->get_IdEstado()."' AND status_municipio = '0'");
        
        if(mysql_num_rows($verficar) > 0 ) //en caso de encontrar un nombre de MUNICIPIO igual al ingresado por el usuario
        {
            //devuelvo este msj que se mostrará al usuario
            $resp = "Ya existe el estado que desea registrar, verifique el nombre del estado, e intente nuevamente";
        }
        else if( mysql_num_rows($verificar_codigo_cne) > 0 )//en caso de encontrar un codigo de MUNICIPIO igual al ingresado por el usuario
        {
            //devuelvo este msj que se mostrará al usuario
            $resp = "Ya existe un estado con este código, verifique el código ingresado, e intente nuevamente";
        }
        else if(mysql_num_rows($verificar_inactividad) > 0 ) 
        {
            //si estaba inactivo se procede a cambiar el status mediante un update
            while( $row = mysql_fetch_array($verificar_inactividad) )
            {
                $sql = "UPDATE municipio SET status_municipio = '1' WHERE id_municipio = '".$row['id_municipio']."' ";

                //MANDO EJECUTAR EL QUERY
                $registrar = $conn->ejecutarQuery($sql);

                //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
                if( $registrar > 0 )
                {
                    //esta variable se retorna como respuesta que recibira el ajax
                    $resp = 1;
                }
                else
                {
                    //si hubo algun problema con la base de datos se devolvera este msj
                    $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
                    
                }
            }
        }
        else //en caso que no se encuentren coincidencias, es decir no exista EL MUNICIPIO, se procede a realizar la insercion
        {
            //TIRA SQL PARA registrar DATOS DEL MUNICIPIO
            
            $sql = "INSERT INTO municipio(codigo_cne_municipio, nombre_municipio, status_municipio, id_estado) VALUES('".$this->get_CodigoCneMunicipio()."', '".$this->get_NombreMunicipio()."', '1', '".$this->get_IdEstado()."')";

            //MANDO EJECUTAR EL QUERY
            $registrar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
            if( $registrar > 0 )
            {
                //si la insercion fue realizada de manera correcta
                $resp = 1;
                
            }
            else
            {
                //si hubo un problema durante la insercion
                $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
                
            }
        }
        
        echo $resp;
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function ModificarMunicipio()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
       
        //consulto para verficar que no existan algo repetido
        $verficar = $conn->ejecutarQuery("SELECT id_municipio FROM municipio WHERE nombre_municipio = '".$this->get_NombreMunicipio()."' OR codigo_cne_municipio = '".$this->get_CodigoCneMunicipio()."' AND status_municipio = '1' AND id_estado = '".$this->get_IdEstado()."'");
       
        if( mysql_num_rows($verficar) > 0 )
        {
            while( $row = mysql_fetch_array($verficar) )
            {
                if( $row['id_municipio'] == $this->get_IdMunicipio() ) //presionó modificar sin cambiar nada o dejando todo como esta en base de datos
                {
                    $sql = "UPDATE municipio SET codigo_cne_municipio = '".$this->get_CodigoCneMunicipio()."', nombre_municipio = '".$this->get_NombreMunicipio()."', status_municipio = '".$this->get_StatusMunicipio()."', id_estado = '".$this->get_IdEstado()."' WHERE id_municipio = '".$this->get_IdMunicipio()."'";

                    //MANDO EJECUTAR EL QUERY
                    $modificar = $conn->ejecutarQuery($sql) or die (mysql_error());

                    //VERIFICO QUE SE HAYA REALIZADO la modificacion
                    if( $modificar > 0 )
                    {
                        $resp = 1;
                    }
                    else
                    {
                        $resp = 0;
                    }
                }
                else
                {
                    $resp = "El codigo del CNE o el nombre del estado ya se encuentran asignados a otro estado, verifique e intente nuevamente.";
                }
            }
        }
        else //en caso que no hayan coincidencias 
        {
            $sql = "UPDATE municipio SET codigo_cne_municipio = '".$this->get_CodigoCneMunicipio()."', nombre_municipio = '".$this->get_NombreMunicipio()."', status_municipio = '".$this->get_StatusMunicipio()."', id_estado = '".$this->get_IdEstado()."' WHERE id_municipio = '".$this->get_IdMunicipio()."'";

            //MANDO EJECUTAR EL QUERY
            $modificar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO la modificacion
            if( $modificar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    
    public function EliminarMunicipio()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        $SQL_verificar = "SELECT id_municipio FROM municipio WHERE id_municipio = '".$this->get_IdMunicipio()."'";
        
        $verificar = $conn->ejecutarQuery($SQL_verificar);
        
        
        if(mysql_num_rows($verificar) > 0 )
        {
            //en caso de que este relacionado, hacemos una actualizacion y pasa a inactivo.. eliminacion logica
            
            $sql = "UPDATE municipio SET status_municipio = '0' WHERE id_municipio = '".$this->get_IdMunicipio()."'";

            //MANDO EJECUTAR EL QUERY
            $eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el update
            if( $eliminar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        else
        {
            //en caso de no estar relacionado aplicamos eliminacion fisica
            //TIRA SQL PARA eliminar DATOS DEL MUNICIPIO
            $sql = "DELETE FROM municipio WHERE id_municipio = '".$this->get_IdMunicipio()."'";

            //MANDO EJECUTAR EL QUERY
            $eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el borrado
            if( $eliminar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    
    /*FUNCION PARA BUSCAR SUGERENCIAS DE CODIGO CNE Y NOMBRE DEL MUNICIPIO*/
    public function SugerenciasDeMunicipios( $codigo, $nombre )
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        /*COMPARO PARA SABER POR CUAL DE LOS PARAMETROS REALIZO LA BUSQUEDA*/
        if( strlen($codigo) > 0  && strlen($nombre) == 0 )
        {
            
            if($this->get_IdEstado() > 0){
                
                $sql = 'SELECT id_municipio, codigo_cne_municipio, status_municipio FROM municipio, estado WHERE codigo_cne_municipio like "%'.$codigo.'%" AND municipio.id_estado = "'.$this->get_IdEstado().'" AND estado.id_estado = municipio.id_estado AND estado.status_estado = "1" LIMIT 10';
            }
            else{
                $sql = 'SELECT id_municipio, codigo_cne_municipio, status_municipio FROM municipio WHERE codigo_cne_municipio LIKE "%'.$codigo.'%" LIMIT 10';
            }
            /*EJECUTO EL QUERY*/
            $buscar = $conn->ejecutarQuery( $sql );
            
            
            if( mysql_num_rows($buscar) > 0 )
            {
                while( $row = mysql_fetch_array($buscar) )
                {
                    if( $row['status_municipio'] == 1 )
                    {
                        echo' 
                            <li onclick="Buscar('.$row['id_municipio'].')">'.$row['codigo_cne_municipio'].'</li>
                         ';
                    }else{}
                }
            }
            else
            {
                echo' 
                        <li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>
                    ';
            }
        }
        else if( strlen($codigo) == 0  && strlen($nombre) > 0 )
        {
            if($this->get_IdEstado() > 0){
                
                $sql = 'SELECT id_municipio, nombre_municipio, status_municipio FROM municipio, estado WHERE nombre_municipio like "%'.$nombre.'%" AND municipio.id_estado = "'.$this->get_IdEstado().'" AND estado.id_estado = municipio.id_estado AND estado.status_estado = "1" LIMIT 10';
            }
            else{
                $sql = 'SELECT id_municipio, nombre_municipio, status_municipio FROM municipio WHERE nombre_municipio like "%'.$nombre.'%" LIMIT 10';
            }
            /*EJECUTO EL QUERY*/
            $buscar = $conn->ejecutarQuery( $sql );

            if( mysql_num_rows($buscar) != 0 )
            {
                while($row = mysql_fetch_array($buscar))
                {
                    if( $row['status_municipio'] == 1 )
                    {
                        echo' 
                        <li onclick="Buscar('.$row['id_municipio'].')">'.$row['nombre_municipio'].'</li>
                     ';
                    }else{}
                }
            }
            else
            {
                echo' 
                        <li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>
                     ';
            }
        }
        
        $conn->cerrar();
        
    }
    
    public function ListarMunicipios()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
//        $sql = "SELECT id_municipio, codigo_cne_municipio, nombre_municipio FROM municipio WHERE status_municipio = '1' ORDER BY nombre_municipio ASC";
        $sql = "SELECT estado.id_estado, municipio.id_municipio, municipio.nombre_municipio, municipio.codigo_cne_municipio FROM estado, municipio WHERE estado.status_estado = '1' AND municipio.id_estado = estado.id_estado AND municipio.status_municipio = '1' ORDER BY municipio.nombre_municipio ASC";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
    
        if( mysql_num_rows( $buscar ) > 0 )
        {
            echo ' 
                    <table class="table table-striped table-bordered table-hover" id="tabla_municipios">
                        <thead>
                            <tr>
                                <th width="25%">Cód. CNE</th>
                                <th width="60%">Nombre Municipios</th>
                                <th width="15%">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tabla_estados">

              ';
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <tr onclick="Buscar('.$row['id_municipio'].')"> 
                            <td width="25%">'.$row['codigo_cne_municipio'].' </td>
                            <td width="60%">'.$row['nombre_municipio'].' </td>
                            <td width="15%"><button class="btn btn-danger"><i class=" fa fa-trash-o"></i></button></td>   
                        </tr>
                    ';
            }
            echo '  
                    </tbody>
                </table>
                
                <script>
                        $("#tabla_municipios").dataTable();
                    
                </script>
              ';
        }
        else
        {
            echo'
                    <tr> 
                        <td colspan="3">NO HAY MUNICIPIOS REGISTRADOS</td>
                    </tr>                   
                ';
        }
    }
    
     public function CargarMunicipios()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT id_municipio, nombre_municipio FROM municipio WHERE status_municipio = '1' AND id_estado = '".$this->get_IdEstado()."' ORDER BY nombre_municipio";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
         
        if( mysql_num_rows( $buscar ) > 0 )
        {
            echo '<option value="0">SELECCIONE EL MUNICIPIO</option>';
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <option value="'.$row['id_municipio'].'"> '.$row['nombre_municipio'].' </option>                    
                    ';
            }
        }
        else
        {
            echo'
                    <option value="0">NO HAY MUNICIPIO REGISTRADOS</option>                    
                ';
        }
    }

    
    
    
    
}
