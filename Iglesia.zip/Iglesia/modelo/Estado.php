<?php

include_once("conexionBD.php");

class Estado {
    
    private $_IdEstado;
    private $_CodigoCneEstado;
    private $_NombreEstado;
    private $_StatusEstado;
    private $conn;
    
    
    public function get_IdEstado() {
        return $this->_IdEstado;
    }

    public function get_CodigoCneEstado() {
        return $this->_CodigoCneEstado;
    }

    public function get_NombreEstado() {
        return $this->_NombreEstado;
    }

    public function get_StatusEstado() {
        return $this->_StatusEstado;
    }

    public function set_IdEstado($_IdEstado) {
        $this->_IdEstado = $_IdEstado;
    }

    public function set_CodigoCneEstado($_CodigoCneEstado) {
        $this->_CodigoCneEstado = $_CodigoCneEstado;
    }

    public function set_NombreEstado($_NombreEstado) {
        $this->_NombreEstado = $_NombreEstado;
    }

    public function set_StatusEstado($_StatusEstado) {
        $this->_StatusEstado = $_StatusEstado;
    }

    //CONSTRUCTOR DE LA CLASE
    function __construct() {
        
    }
    
    //funcion para buscar los datos de un estado especifico
    public function BuscarDatosEstado()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $datos = array();
        
        //TIRA SQL PARA CAPTURAR DATOS DEL ESTADO
        $sql = 'SELECT codigo_cne_estado, nombre_estado, status_estado FROM estado WHERE id_estado = "'.$this->get_IdEstado().'"';
        
        //MANDO EJECUTAR EL QUERY
        $buscar = $conn->ejecutarQuery($sql);
        
        //VERIFICO QUE HAYAN RESULTADOS
        if( mysql_num_rows($buscar) > 0 )
        {
            //RECORRO EL REGISTRO, O LA FILA
            while( $row = mysql_fetch_array($buscar) )
            {
                $datos['id_estado'][0] = $this->get_IdEstado(); 
                $datos['codigo_cne_estado'][0] = $row['codigo_cne_estado']; //CAPTURO CODIGO DEL ESTADO
                $datos['nombre_estado'][0] = $row['nombre_estado'];//CAPTURO NOMBRE DEL ESTADO
                $datos['status_estado'][0] = $row['status_estado'];//CAPTURO STATUS DEL ESTADO
            }
        }
        else
        {
            //igualo el array a vacio, esto en caso de encontrar resultados
            $datos['id_estado'][0] = ""; 
            $datos['codigo_cne_estado'][0] = "";
            $datos['nombre_estado'][0] = "";
            $datos['status_estado'][0] = "";
        }
        
        echo json_encode( $datos ); //CONVIERTO EL ARRAY EN JSON PARA USARLO EN EL AJAX
        //ESTE SE RECIBE EN AJAX EN respuesta
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function RegistrarEstado()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //consulto para verficar que no exista el estado que se desea registrar
        $verficar = $conn->ejecutarQuery("SELECT id_estado FROM estado WHERE nombre_estado = '".$this->get_NombreEstado()."' AND status_estado = '1'");
        $verificar_codigo_cne = $conn->ejecutarQuery("SELECT id_estado FROM estado WHERE codigo_cne_estado = '".$this->get_CodigoCneEstado()."' AND status_estado = '1'");
        //verifico que el estado no haya sido inactivado
        $verificar_inactividad = $conn->ejecutarQuery("SELECT id_estado FROM estado WHERE codigo_cne_estado = '".$this->get_CodigoCneEstado()."' AND nombre_estado = '".$this->get_NombreEstado()."' AND status_estado = '0'");
        
        if(mysql_num_rows($verficar) > 0 ) //en caso de encontrar un nombre de estado igual al ingresado por el usuario
        {
            //devuelvo este msj que se mostrará al usuario
            $resp = "Ya existe el estado que desea registrar, verifique el nombre del estado, e intente nuevamente";
        }
        else if( mysql_num_rows($verificar_codigo_cne) > 0 )//en caso de encontrar un codigo de estado igual al ingresado por el usuario
        {
            //devuelvo este msj que se mostrará al usuario
            $resp = "Ya existe un estado con este código, verifique el código ingresado, e intente nuevamente";
        }
        else if(mysql_num_rows($verificar_inactividad) > 0 ) 
        {
            //si estaba inactivo se procede a cambiar el status mediante un update
            while( $row = mysql_fetch_array($verificar_inactividad) )
            {
                $sql = "UPDATE estado SET status_estado = '1' WHERE id_estado = '".$row['id_estado']."' ";

                //MANDO EJECUTAR EL QUERY
                $registrar = $conn->ejecutarQuery($sql);

                //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
                if( $registrar > 0 )
                {
                    //esta variable se retorna como respuesta que recibira el ajax
                    $resp = 1;
                }
                else
                {
                    //si hubo algun problema con la base de datos se devolvera este msj
                    $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
                }
            }
        }
        else //en caso que no se encuentren coincidencias, es decir no exista el estado, se procede a realizar la insercion
        {
            //TIRA SQL PARA registrar DATOS DEL ESTADO
            $sql = "INSERT INTO estado(codigo_cne_estado, nombre_estado, status_estado) VALUES('".$this->get_CodigoCneEstado()."', '".$this->get_NombreEstado()."', '1')";

            //MANDO EJECUTAR EL QUERY
            $registrar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
            if( $registrar > 0 )
            {
                //si la insercion fue realizada de manera correcta
                $resp = 1;
            }
            else
            {
                //si hubo un problema durante la insercion
                $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
            }
        }
        
        echo $resp;
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function ModificarEstado()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        //echo "SELECT id_estado FROM estado WHERE nombre_estado = '".$this->get_NombreEstado()."' OR codigo_cne_estado = '".$this->get_CodigoCneEstado()."'";
        //consulto para verficar que no existan algo repetido
        $verficar = $conn->ejecutarQuery("SELECT id_estado FROM estado WHERE nombre_estado = '".$this->get_NombreEstado()."' OR codigo_cne_estado = '".$this->get_CodigoCneEstado()."' AND status_estado = '1' AND id_estado != '".$this->get_IdEstado()."'");
        //echo mysql_num_rows($verficar);
        if( mysql_num_rows($verficar) > 0 )
        {
            while( $row = mysql_fetch_array($verficar) )
            {
                if( $row['id_estado'] == $this->get_IdEstado() ) //presionó modificar sin cambiar nada o dejando todo como esta en base de datos
                {
                    $sql = "UPDATE estado SET codigo_cne_estado = '".$this->get_CodigoCneEstado()."', nombre_estado = '".$this->get_NombreEstado()."', status_estado = '".$this->get_StatusEstado()."' WHERE id_estado = '".$this->get_IdEstado()."'";

                    //MANDO EJECUTAR EL QUERY
                    $modificar = $conn->ejecutarQuery($sql) or die (mysql_error());

                    //VERIFICO QUE SE HAYA REALIZADO la modificacion
                    if( $modificar > 0 )
                    {
                        $resp = 1;
                    }
                    else
                    {
                        $resp = 0;
                    }
                }
                else
                {
                    $resp = "El codigo del CNE o el nombre del estado ya se encuentran asignados a otro estado, verifique e intente nuevamente.";
                }
            }
        }
        else //en caso que no hayan coincidencias 
        {
            $sql = "UPDATE estado SET codigo_cne_estado = '".$this->get_CodigoCneEstado()."', nombre_estado = '".$this->get_NombreEstado()."', status_estado = '".$this->get_StatusEstado()."' WHERE id_estado = '".$this->get_IdEstado()."'";

            //MANDO EJECUTAR EL QUERY
            $modificar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO la modificacion
            if( $modificar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    
    public function EliminarEstado()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        $SQL_verificar = "SELECT id_municipio FROM municipio WHERE id_estado = '".$this->get_IdEstado()."'";
        
        $verificar = $conn->ejecutarQuery($SQL_verificar);
        
        
        if(mysql_num_rows($verificar) > 0 )
        {
            //en caso de que este relacionado, hacemos una actualizacion y pasa a inactivo.. eliminacion logica
            
            $sql = "UPDATE estado SET status_estado = '0' WHERE id_estado = '".$this->get_IdEstado()."'";

            //MANDO EJECUTAR EL QUERY
            $eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el update
            if( $eliminar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        else
        {
            //en caso de no estar relacionado aplicamos eliminacion fisica
            //TIRA SQL PARA eliminar DATOS DEL ESTADO
            $sql = "DELETE FROM estado WHERE id_estado = '".$this->get_IdEstado()."'";

            //MANDO EJECUTAR EL QUERY
            $eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el borrado
            if( $eliminar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    /*FUNCION PARA BUSCAR SUGERENCIAS DE CODIGO Y NOMBRE DEL ESTADO*/
    public function SugerenciasDeEstados( $codigo, $nombre )
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        /*COMPARO PARA SABER POR CUAL DE LOS PARAMETROS REALIZO LA BUSQUEDA*/
        if( strlen($codigo) > 0  && strlen($nombre) == 0 )
        {
            $sql = 'SELECT id_estado, codigo_cne_estado, status_estado FROM estado WHERE codigo_cne_estado LIKE "%'.$codigo.'%"';
            
            /*EJECUTO EL QUERY*/
            $buscar = $conn->ejecutarQuery( $sql );
            
            if( mysql_num_rows($buscar) != 0 )
            {
                while( $row = mysql_fetch_array($buscar) )
                {
                    if( $row['status_estado'] == 1 )
                    {
                        echo' 
                            <li onclick="Buscar('.$row['id_estado'].')">'.$row['codigo_cne_estado'].'</li>
                         ';
                    }else{}
                }
            }
            else
            {
                echo' 
                        <li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>
                    ';
            }
        }
        else if( strlen($codigo) == 0  && strlen($nombre) > 0 )
        {
            $sql = 'SELECT id_estado, nombre_estado, status_estado FROM estado WHERE nombre_estado LIKE "%'.$nombre.'%" AND status_estado = 1  LIMIT 7';
            /*EJECUTO EL QUERY*/
            $buscar = $conn->ejecutarQuery( $sql );

            if( mysql_num_rows($buscar) != 0 )
            {
                while($row = mysql_fetch_array($buscar))
                {
                    if( $row['status_estado'] == 1 )
                    {
                        echo' 
                        <li onclick="Buscar('.$row['id_estado'].')">'.$row['nombre_estado'].'</li>
                     ';
                    }else{}
                }
            }
            else
            {
                echo' 
                        <li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>
                     ';
            }
        }
        
        $conn->cerrar();
        
    }
    
    //funcion para extraer todos los estados activos y cargarlos en selects
    public function CargarEstados()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT id_estado, nombre_estado FROM estado WHERE status_estado = '1' ORDER BY nombre_estado";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
        if( mysql_num_rows( $buscar ) > 0 )
        {
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <option value="'.$row['id_estado'].'"> '.$row['nombre_estado'].' </option>                    
                    ';
            }
        }
        else
        {
            echo'
                    <option value="0">NO HAY ESTADOS REGISTRADOS</option>                    
                ';
        }
    }
    
    /*funcion para cargar el catalogo*/
    public function ListarEstados()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT id_estado, codigo_cne_estado, nombre_estado FROM estado WHERE status_estado = '1' ORDER BY nombre_estado ASC";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
        if( mysql_num_rows( $buscar ) > 0 )
        {
            echo ' 
                    <table class="table table-striped table-bordered table-hover" id="tabla_estados">
                        <thead>
                            <tr>
                                <th width="25%">Cód. CNE</th>
                                <th width="60%">Nombre Estado</th>
                                <th width="15%">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tabla_estados">

              ';
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <tr onclick="Buscar('.$row['id_estado'].')"> 
                            <td width="25%">'.$row['codigo_cne_estado'].' </td>
                            <td width="60%">'.$row['nombre_estado'].' </td>
                            <td width="15%"> a</td>   
                        </tr>
                    ';
            }
            echo '  
                    </tbody>
                </table>
                
                <script>
                        $("#tabla_estados").dataTable();
                    
                </script>
              ';
        }
        else
        {
            echo'
                    <tr> 
                        <td colspan="3">NO HAY ESTADO REGISTRADOS</td>
                    </tr>                   
                ';
        }
    }

    
}
