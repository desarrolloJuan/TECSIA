<?php

include_once("conexionBD.php");

class EstadoCivil {
    
    private $_Id_Estado_Civil;
    private $_Descripcion_Estado_Civil;
    private $_Status_Estado_Civil;
    private $conn;
    
    
    public function get_Id_Estado_Civil() {
        return $this->_Id_Estado_Civil;
    }

    public function get_Descripcion_Estado_Civil() {
        return $this->_Descripcion_Estado_Civil;
    }

    public function get_Status_Estado_Civil() {
        return $this->_Status_Estado_Civil;
    }

    public function set_Id_Estado_Civil($_Id_Estado_Civil) {
        $this->_Id_Estado_Civil = $_Id_Estado_Civil;
    }

    public function set_Descripcion_Estado_Civil($_Descripcion_Estado_Civil) {
        $this->_Descripcion_Estado_Civil = $_Descripcion_Estado_Civil;
    }

    public function set_Status_Estado_Civil($_Status_Estado_Civil) {
        $this->_Status_Estado_Civil = $_Status_Estado_Civil;
    }

    //CONSTRUCTOR DE LA CLASE
    function __construct() {
        
    }
    
    //funcion para buscar los datos de un departamento especifico
    public function BuscarDatosEstadoCivil()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $datos = array();
        
        //TIRA SQL PARA CAPTURAR DATOS DEL DEPARTAMENTO
        $sql = 'SELECT descripcion_estado_civil , status_estado_civil FROM estado_civil WHERE id_estado_civil = "'.$this->get_Id_Estado_Civil().'"';
        
        //MANDO EJECUTAR EL QUERY
        $buscar = $conn->ejecutarQuery($sql);
        
        //VERIFICO QUE HAYAN RESULTADOS
        if( mysql_num_rows($buscar) > 0 )
        {
            //RECORRO EL REGISTRO, O LA FILA
            while( $row = mysql_fetch_array($buscar) )
            {
                $datos['id_estado_civil'][0] = $this->get_Id_Estado_Civil(); 
                $datos['descripcion_estado_civil'][0] = $row['descripcion_estado_civil'];//CAPTURO EL NOMBRE
                $datos['status_estado_civil'][0] = $row['status_estado_civil'];//CAPTURO STATUS DEL DEPARTAMENTO
            }
        }
        else
        {
            //igualo el array a vacio, esto en caso de encontrar resultados
            $datos['id_estado_civil'][0] = ""; 
            $datos['descripcion_estado_civil'][0] = "";
            $datos['status_estado_civil'][0] = "";
        }
        
        echo json_encode( $datos ); //CONVIERTO EL ARRAY EN JSON PARA USARLO EN EL AJAX
        //ESTE SE RECIBE EN AJAX EN respuesta
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function RegistrarEstadoCivil()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //consulto para verficar que no exista el departamento que se desea registrar
        $verficar = $conn->ejecutarQuery("SELECT id_estado_civil FROM estado_civil WHERE descripcion_estado_civil = '".$this->get_Descripcion_Estado_Civil()."' AND status_estado_civil = '1'");
        
        //verifico que el departamento no haya sido inactivado
        $verificar_inactividad = $conn->ejecutarQuery("SELECT id_estado_civil FROM estado_civil WHERE descripcion_estado_civil = '".$this->get_Descripcion_Estado_Civil()."' AND status_estado_civil = '0'");
        
        if(mysql_num_rows($verficar) > 0 ) //en caso de encontrar un nombre de DEPARTAMENTO igual al ingresado por el usuario
        {
            //devuelvo este msj que se mostrará al usuario
            $resp = "Ya existe el Estado Civil que desea registrar, verifique la Descripcion, e intente nuevamente";
        }
     
        else if(mysql_num_rows($verificar_inactividad) > 0 ) 
        {
            //si estaba inactivo se procede a cambiar el status mediante un update
            while( $row = mysql_fetch_array($verificar_inactividad) )
            {
                $sql = "UPDATE estado_civil SET status_estado_civil = '1' WHERE id_estado_civil = '".$row['id_estado_civil']."' ";

                //MANDO EJECUTAR EL QUERY
                $registrar = $conn->ejecutarQuery($sql);

                //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
                if( $registrar > 0 )
                {
                    //esta variable se retorna como respuesta que recibira el ajax
                    $resp = 1;
                }
                else
                {
                    //si hubo algun problema con la base de datos se devolvera este msj
                    $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
                }
            }
        }
        else //en caso que no se encuentren coincidencias, es decir no exista el departamento, se procede a realizar la insercion
        {
            //TIRA SQL PARA registrar DATOS DEL DEPARTAMENTO
            $sql = "INSERT INTO estado_civil (descripcion_estado_civil, status_estado_civil) VALUES('".$this->get_Descripcion_Estado_Civil()."', '1')";
            
            //MANDO EJECUTAR EL QUERY
            $registrar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
            if( $registrar > 0 )
            {
                //si la insercion fue realizada de manera correcta
                $resp = 1;
            }
            else
            {
                //si hubo un problema durante la insercion
                $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
            }
        }
        
        echo $resp;
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function ModificarEstadoCivil()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //consulto para verficar que no existan algo repetido
        $verficar = $conn->ejecutarQuery("SELECT id_estado_civil FROM estado_civil WHERE descripcion_estado_civil = '".$this->get_Descripcion_Estado_Civil()."' AND status_estado_civil = '1' AND id_estado_civil != '".$this->get_Id_Estado_Civil()."'");
        //echo mysql_num_rows($verficar);
        if( mysql_num_rows($verficar) > 0 )
        {
            while( $row = mysql_fetch_array($verficar) )
            {
                if( $row['id_estado_civil'] == $this->get_Id_Estado_Civil() ) //presionó modificar sin cambiar nada o dejando todo como esta en base de datos
                {
                    $sql = "UPDATE estado_civil SET descripcion_estado_civil = '".$this->get_Descripcion_Estado_Civil()."', status_estado_civil = '".$this->get_Status_Estado_Civil()."' WHERE id_estado_civil = '".$this->get_Id_Estado_Civil()."'";

                    //MANDO EJECUTAR EL QUERY
                    $modificar = $conn->ejecutarQuery($sql) or die (mysql_error());

                    //VERIFICO QUE SE HAYA REALIZADO la modificacion
                    if( $modificar > 0 )
                    {
                        $resp = 1;
                    }
                    else
                    {
                        $resp = 0;
                    }
                }
                else
                {
                    $resp = "El Estado Civil se encuentra asignado, verifique e intente nuevamente.";
                }
            }
        }
        else //en caso que no hayan coincidencias 
        {
            $sql = "UPDATE estado_civil SET descripcion_estado_civil = '".$this->get_Descripcion_Estado_Civil()."', status_estado_civil = '".$this->get_Status_Estado_Civil()."' WHERE id_estado_civil = '".$this->get_Id_Estado_Civil()."'";

            //MANDO EJECUTAR EL QUERY
            $modificar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO la modificacion
            if( $modificar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    
    public function EliminarEstadoCivil()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
       
            //en caso de no estar relacionado aplicamos eliminacion fisica
            //TIRA SQL PARA eliminar DATOS DEL DEPARTAMENTO
            $sql = "DELETE FROM estado_civil WHERE id_estado_civil = '".$this->get_Id_Estado_Civil()."'";

            //MANDO EJECUTAR EL QUERY
            $eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el borrado
            if( $eliminar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
       
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    /*FUNCION PARA BUSCAR SUGERENCIAS DE CODIGO Y NOMBRE DEL DEPARTAMENTO*/
    public function SugerenciasDeEstadoCivil( $descripcion_estado_civil )
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        if( strlen($descripcion_estado_civil) > 0 )
        {
            $sql = 'SELECT id_estado_civil, descripcion_estado_civil, status_estado_civil FROM estado_civil WHERE descripcion_estado_civil LIKE "%'.$descripcion_estado_civil.'%" AND status_estado_civil = 1  LIMIT 7';
            /*EJECUTO EL QUERY*/
            $buscar = $conn->ejecutarQuery( $sql );

            if( mysql_num_rows($buscar) != 0 )
            {
                while($row = mysql_fetch_array($buscar))
                {
                    if( $row['status'] == 1 )
                    {
                        echo' 
                        <li onclick="Buscar('.$row['id_estado_civil'].')">'.$row['descripcion_estado_civil'].'</li>
                     ';
                    }else{}
                }
            }
            else
            {
                echo' 
                        <li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>
                     ';
            }
        }
        
        $conn->cerrar();
        
    }
    
    //funcion para extraer todos los departamento activos y cargarlos en selects
    public function CargarEstadoCivil()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT id_estado_civil, descripcion_estado_civil FROM estado_civil WHERE status_estado_civil = '1' ORDER BY descripcion_estado_civil";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
        if( mysql_num_rows( $buscar ) > 0 )
        {
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <option value="'.$row['id_estado_civil'].'"> '.$row['descripcion_estado_civil'].' </option>                    
                    ';
            }
        }
        else
        {
            echo'
                    <option value="0">NO HAY ESTADO CIVIL REGISTRADOS</option>                    
                ';
        }
    }
    
    /*funcion para cargar el catalogo*/
    public function ListarEstadoCivil()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT id_estado_civil, descripcion_estado_civil FROM estado_civil WHERE status_estado_civil = '1' ORDER BY descripcion_estado_civil ASC";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
        if( mysql_num_rows( $buscar ) > 0 )
        {
            echo ' 
                    <table class="table table-striped table-bordered table-hover" id="tabla_estado_civil">
                        <thead>
                            <tr>
                                <th width="85%">Descripción de Estado Civil/th>
                                <th width="15%">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tabla_estado_civil">

              ';
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <tr onclick="Buscar('.$row['id_estado_civil'].')"> 
                            <td width="85%">'.$row['descripcion_estado_civil'].' </td>
                            <td width="15%"><button class="btn btn-danger"><i class=" fa fa-trash-o"></i></button></td>   
                        </tr>
                    ';
            }
            echo '  
                    </tbody>
                </table>
                
                <script>
                        $("#tabla_estado_civil").dataTable();
                    
                </script>
              ';
        }
        else
        {
            echo'
                    <tr> 
                        <td colspan="3">NO HAY ESTADO CIVIL REGISTRADOS</td>
                    </tr>                   
                ';
        }
    }

    
}
