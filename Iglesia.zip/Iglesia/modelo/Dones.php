<?php

include_once("conexionBD.php");

class Dones {
    
    private $_IdDones;
    private $_Nombre;
    private $_Status;
    private $conn;
    
    
    public function get_IdDones() {
        return $this->_IdDones;
    }

    public function get_Nombre() {
        return $this->_Nombre;
    }

    public function get_Status() {
        return $this->_Status;
    }

    public function set_IdDones($_IdDones) {
        $this->_IdDones = $_IdDones;
    }

    public function set_Nombre($_Nombre) {
        $this->_Nombre = $_Nombre;
    }

    public function set_Status($_Status) {
        $this->_Status = $_Status;
    }

    //CONSTRUCTOR DE LA CLASE
    function __construct() {
        
    }
    
    //funcion para buscar los datos de un dones especifico
    public function BuscarDatosDones()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $datos = array();
        
        //TIRA SQL PARA CAPTURAR DATOS DEL DONES
        $sql = 'SELECT nombre, status FROM dones WHERE id_dones = "'.$this->get_IdDones().'"';
        
        //MANDO EJECUTAR EL QUERY
        $buscar = $conn->ejecutarQuery($sql);
        
        //VERIFICO QUE HAYAN RESULTADOS
        if( mysql_num_rows($buscar) > 0 )
        {
            //RECORRO EL REGISTRO, O LA FILA
            while( $row = mysql_fetch_array($buscar) )
            {
                $datos['id_dones'][0] = $this->get_IdDones(); 
                $datos['nombre'][0] = $row['nombre'];//CAPTURO EL NOMBRE
                $datos['status'][0] = $row['status'];//CAPTURO STATUS DEL DONES
            }
        }
        else
        {
            //igualo el array a vacio, esto en caso de encontrar resultados
            $datos['id_dones'][0] = ""; 
            $datos['nombre'][0] = "";
            $datos['status'][0] = "";
        }
        
        echo json_encode( $datos ); //CONVIERTO EL ARRAY EN JSON PARA USARLO EN EL AJAX
        //ESTE SE RECIBE EN AJAX EN respuesta
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function RegistrarDones()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //consulto para verficar que no exista el dones que se desea registrar
        $verficar = $conn->ejecutarQuery("SELECT id_dones FROM dones WHERE nombre = '".$this->get_Nombre()."' AND status = '1'");
        
        //verifico que el dones no haya sido inactivado
        $verificar_inactividad = $conn->ejecutarQuery("SELECT id_dones FROM dones WHERE nombre = '".$this->get_Nombre()."' AND status = '0'");
        
        if(mysql_num_rows($verficar) > 0 ) //en caso de encontrar un nombre de DONES igual al ingresado por el usuario
        {
            //devuelvo este msj que se mostrará al usuario
            $resp = "Ya existe el dones que desea registrar, verifique el nombre del dones, e intente nuevamente";
        }
       
        else if(mysql_num_rows($verificar_inactividad) > 0 ) 
        {
            //si estaba inactivo se procede a cambiar el status mediante un update
            while( $row = mysql_fetch_array($verificar_inactividad) )
            {
                $sql = "UPDATE dones SET status = '1' WHERE id_dones = '".$row['id_dones']."' ";

                //MANDO EJECUTAR EL QUERY
                $registrar = $conn->ejecutarQuery($sql);

                //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
                if( $registrar > 0 )
                {
                    //esta variable se retorna como respuesta que recibira el ajax
                    $resp = 1;
                }
                else
                {
                    //si hubo algun problema con la base de datos se devolvera este msj
                    $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
                }
            }
        }
        else //en caso que no se encuentren coincidencias, es decir no exista el dones, se procede a realizar la insercion
        {
            //TIRA SQL PARA registrar DATOS DEL DONES
            $sql = "INSERT INTO dones (nombre, status) VALUES('".$this->get_Nombre()."', '1')";
            
            //MANDO EJECUTAR EL QUERY
            $registrar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
            if( $registrar > 0 )
            {
                //si la insercion fue realizada de manera correcta
                $resp = 1;
            }
            else
            {
                //si hubo un problema durante la insercion
                $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
            }
        }
        
        echo $resp;
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function ModificarDones()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //consulto para verficar que no existan algo repetido
        $verficar = $conn->ejecutarQuery("SELECT id_dones FROM dones WHERE nombre = '".$this->get_Nombre()."' AND status = '1' AND id_dones != '".$this->get_IdDones()."'");
        //echo mysql_num_rows($verficar);
        if( mysql_num_rows($verficar) > 0 )
        {
            while( $row = mysql_fetch_array($verficar) )
            {
                if( $row['id_dones'] == $this->get_IdDones() ) //presionó modificar sin cambiar nada o dejando todo como esta en base de datos
                {
                    $sql = "UPDATE dones SET nombre = '".$this->get_Nombre()."', status = '".$this->get_Status()."' WHERE id_dones = '".$this->get_IdDones()."'";

                    //MANDO EJECUTAR EL QUERY
                    $modificar = $conn->ejecutarQuery($sql) or die (mysql_error());

                    //VERIFICO QUE SE HAYA REALIZADO la modificacion
                    if( $modificar > 0 )
                    {
                        $resp = 1;
                    }
                    else
                    {
                        $resp = 0;
                    }
                }
                else
                {
                    $resp = "El codigo del CNE o el nombre del dones ya se encuentran asignados a otro dones, verifique e intente nuevamente.";
                }
            }
        }
        else //en caso que no hayan coincidencias 
        {
            $sql = "UPDATE dones SET nombre = '".$this->get_Nombre()."', status = '".$this->get_Status()."' WHERE id_dones = '".$this->get_IdDones()."'";

            //MANDO EJECUTAR EL QUERY
            $modificar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO la modificacion
            if( $modificar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    
    public function EliminarDones()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        
            //en caso de no estar relacionado aplicamos eliminacion fisica
            //TIRA SQL PARA eliminar DATOS DEL DONES
            $sql = "DELETE FROM dones WHERE id_dones = '".$this->get_IdDones()."'";

            //MANDO EJECUTAR EL QUERY
            $eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el borrado
            if( $eliminar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    /*FUNCION PARA BUSCAR SUGERENCIAS DE CODIGO Y NOMBRE DEL DONES*/
    public function SugerenciasDeDones( $nombre )
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        if( strlen($nombre) > 0 )
        {
            $sql = 'SELECT id_dones, nombre, status FROM dones WHERE nombre LIKE "%'.$nombre.'%" AND status = 1  LIMIT 7';
            /*EJECUTO EL QUERY*/
            $buscar = $conn->ejecutarQuery( $sql );

            if( mysql_num_rows($buscar) != 0 )
            {
                while($row = mysql_fetch_array($buscar))
                {
                    if( $row['status'] == 1 )
                    {
                        echo' 
                        <li onclick="Buscar('.$row['id_dones'].')">'.$row['nombre'].'</li>
                     ';
                    }else{}
                }
            }
            else
            {
                echo' 
                        <li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>
                     ';
            }
        }
        
        $conn->cerrar();
        
    }
    
    //funcion para extraer todos los dones activos y cargarlos en selects
    public function CargarDones()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT id_dones, nombre FROM dones WHERE status = '1' ORDER BY nombre";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
        if( mysql_num_rows( $buscar ) > 0 )
        {
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <option value="'.$row['id_dones'].'"> '.$row['nombre'].' </option>                    
                    ';
            }
        }
        else
        {
            echo'
                    <option value="0">NO HAY DONES REGISTRADOS</option>                    
                ';
        }
    }
    
    /*funcion para cargar el catalogo*/
    public function ListarDones()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT id_dones, nombre FROM dones WHERE status = '1' ORDER BY nombre ASC";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
        if( mysql_num_rows( $buscar ) > 0 )
        {
            echo ' 
                    <table class="table table-striped table-bordered table-hover" id="tabla_dones">
                        <thead>
                            <tr>
                                <th width="85%">Descripción del Dones</th>
                                <th width="15%">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tabla_dones">

              ';
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <tr onclick="Buscar('.$row['id_dones'].')"> 
                            <td width="85%">'.$row['nombre'].' </td>
                            <td width="15%"><button class="btn btn-danger"><i class=" fa fa-trash-o"></i></button></td>   
                        </tr>
                    ';
            }
            echo '  
                    </tbody>
                </table>
                
                <script>
                        $("#tabla_dones").dataTable();
                    
                </script>
              ';
        }
        else
        {
            echo'
                    <tr> 
                        <td colspan="3">NO HAY DONES REGISTRADOS</td>
                    </tr>                   
                ';
        }
    }

    
}
