<?php

class conexionBD { 
    
public $host; // para conectarnos a localhost o el ip del servidor de mysql

public $db; // seleccionar la base de datos que vamos a utilizar

public $user; // seleccionar el usuario con el que nos vamos a conectar

public $pass; // la clave del usuario

public $conexion;  //donde se guardara la conexión

public $url; //dirección de la conexión que se usara para destruirla mas adelante

//creación del constructor

function __construct()
{

}

//creación de la función para cargar los valores de la conexión.

public function cargarValores(){

$this->host='localhost';

$this->db='iglesia';

$this->user='root';

$this->pass='root';

$this->conexion;

}

    //función que se utilizara al momento de hacer la instancia de la clase
    function conectar(){

    $this->cargarValores();

    $this->conexion = mysql_connect( $this->host, $this->user, $this->pass ) or die ("Problemas con la conexion");

    return true;
    
    }
    
    function seleccionarBD(){
    
        mysql_select_db( $this->db, $this->conexion ) or die ("Problemas al seleccionar la Base de Datos");

        return true;

    }

    function ejecutarQuery($query)
    {	
        $result = mysql_query($query); 

        return $result;           
    }

    //función para destruir la conexión.
    function cerrar(){

        mysql_close( $this->conexion );

    }

}

	
		
		
