<?php

class Persona extends conexionBD {
    
    private $_IdPersona;
    private $_Cedula;
    private $_Nombres;
    private $_Apellidos;
    private $_Sexo;
    private $_FechaNacimiento;
    private $_Direccion;
    private $_Correo;
    private $_StatusPersona;
    private $_IdProfesion;
    private $_IdEstadoCivil;
    private $_IdSector;
    
    function get_IdPersona() {
        return $this->_IdPersona;
    }

    function get_StatusPersona() {
        return $this->_StatusPersona;
    }

    function set_IdPersona($_IdPersona) {
        $this->_IdPersona = $_IdPersona;
    }

    function set_StatusPersona($_StatusPersona) {
        $this->_StatusPersona = $_StatusPersona;
    }

        
    public function get_Cedula() {
        return $this->_Cedula;
    }

    public function get_Nombres() {
        return $this->_Nombres;
    }

    public function get_Apellidos() {
        return $this->_Apellidos;
    }

    public function get_Sexo() {
        return $this->_Sexo;
    }

    public function get_FechaNacimiento() {
        return $this->_FechaNacimiento;
    }

    public function set_Cedula($_Cedula) {
        $this->_Cedula = $_Cedula;
    }

    public function set_Nombres($_Nombres) {
        $this->_Nombres = $_Nombres;
    }

    public function set_Apellidos($_Apellidos) {
        $this->_Apellidos = $_Apellidos;
    }

    public function set_Sexo($_Sexo) {
        $this->_Sexo = $_Sexo;
    }

    public function set_FechaNacimiento($_FechaNacimiento) {
        $this->_FechaNacimiento = $_FechaNacimiento;
    }
    
    public function get_Direccion() {
        return $this->_Direccion;
    }

    public function get_Correo() {
        return $this->_Correo;
    }

    public function get_IdProfesion() {
        return $this->_IdProfesion;
    }

    public function get_IdEstadoCivil() {
        return $this->_IdEstadoCivil;
    }

    public function get_IdSector() {
        return $this->_IdSector;
    }

    public function set_Direccion($_Direccion) {
        $this->_Direccion = $_Direccion;
    }

    public function set_Correo($_Correo) {
        $this->_Correo = $_Correo;
    }

    public function set_IdProfesion($_IdProfesion) {
        $this->_IdProfesion = $_IdProfesion;
    }

    public function set_IdEstadoCivil($_IdEstadoCivil) {
        $this->_IdEstadoCivil = $_IdEstadoCivil;
    }

    public function set_IdSector($_IdSector) {
        $this->_IdSector = $_IdSector;
    }

    
    function __construct() {
        
    }
    
    public function BuscarDatosPersona()
    {
        $con = new conexionBD();
        $con->conectar();
        $con->seleccionarBD();
        $resp = 0;
        
        $sql = "SELECT cedula, nombres, apellidos, sexo, fecha_nac FROM persona WHERE cedula = '".$this->get_Cedula()."'";
 
        $buscar = $con->ejecutarQuery($sql);
        
        if(mysql_num_rows($buscar) > 0 )
        {
            while( $row = mysql_fetch_array( $buscar ) )
            {
                $this->set_Cedula( $row['cedula'] );
                $this->set_Nombres( $row['nombres'] );
                $this->set_Apellidos( $row['apellidos'] );
                $this->set_Sexo( $row['sexo'] );
                $this->set_FechaNacimiento( $row['fecha_nac'] );
            }
            
            $resp = 1;
        }
        else 
        {
            $resp = 0;
        }
        
        return $resp;
    }
    

    
}
