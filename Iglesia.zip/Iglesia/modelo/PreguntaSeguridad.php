<?php

include_once("conexionBD.php");

class PreguntaSeguridad {
    
    private $_IdPregunta;
    private $_DescripcionPregunta;
    private $_StatusPregunta;
    
    
    function get_IdPregunta() {
        return $this->_IdPregunta;
    }

    function get_DescripcionPregunta() {
        return $this->_DescripcionPregunta;
    }

    function get_StatusPregunta() {
        return $this->_StatusPregunta;
    }

    function set_IdPregunta($_IdPregunta) {
        $this->_IdPregunta = $_IdPregunta;
    }

    function set_DescripcionPregunta($_DescripcionPregunta) {
        $this->_DescripcionPregunta = $_DescripcionPregunta;
    }

    function set_StatusPregunta($_StatusPregunta) {
        $this->_StatusPregunta = $_StatusPregunta;
    }

        
    function __construct() {
                
    }
    
    
    public function CargarPreguntas()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = " SELECT id_pregunta, descripcion_pregunta FROM pregunta_seguridad WHERE status_pregunta = '1' ";
        $buscar = $conn->ejecutarQuery( $sql );
        
        if(mysql_num_rows( $buscar ) > 0 )
        {
            echo'<option value="0">SELECCIONE LA PREGUNTA</option>';
            while( $row = mysql_fetch_array($buscar) )
            {
                echo'
                    <option value="'.$row['id_pregunta'].'">'.utf8_encode($row['descripcion_pregunta']).'</option>
                ';
            }
        }
        else 
        {
            echo'<option value="0">NO HAY PREGUNTAS REGISTRADAS</option>';
        }
        
    }

    
}
