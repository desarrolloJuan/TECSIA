<?php

class FotoPerfil extends conexionBD {
    private $_IdFoto;
    private $_Ruta;
    private $_StatusFoto;
    
    public function get_IdFoto() {
        return $this->_IdFoto;
    }

    public function get_Ruta() {
        return $this->_Ruta;
    }

    public function get_StatusFoto() {
        return $this->_StatusFoto;
    }

    public function set_IdFoto($_IdFoto) {
        $this->_IdFoto = $_IdFoto;
    }

    public function set_Ruta($_Ruta) {
        $this->_Ruta = $_Ruta;
    }

    public function set_StatusFoto($_StatusFoto) {
        $this->_StatusFoto = $_StatusFoto;
    }


    public function BuscarFotoActiva( $id_usuario )
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT ruta FROM foto_perfil WHERE id_usuario = '".$id_usuario."' AND status_foto = '1'";
        
        $buscar = $conn->ejecutarQuery($sql);

        $resp = 0;
        
        if( mysql_num_rows($buscar) > 0 )
        {
            while( $row = mysql_fetch_array($buscar) )
            {
                $this->set_Ruta( $row['ruta'] );
                $resp = 1;
            }
        }
        else 
        {
            $resp = 0;
        }
        
        //$conn->cerrar();
        return $resp;
    }
    
    
}
