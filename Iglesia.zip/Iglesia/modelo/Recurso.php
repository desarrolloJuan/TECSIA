<?php

include_once("conexionBD.php");

class Recurso {
    
    private $_IdRecurso;
    private $_Descripcion;
    private $_Status;
    private $conn;
    
    
    public function get_IdRecurso() {
        return $this->_IdRecurso;
    }

    public function get_Descripcion() {
        return $this->_Descripcion;
    }

    public function get_Status() {
        return $this->_Status;
    }

    public function set_IdRecurso($_IdRecurso) {
        $this->_IdRecurso = $_IdRecurso;
    }

    public function set_Descripcion($_Descripcion) {
        $this->_Descripcion = $_Descripcion;
    }

    public function set_Status($_Status) {
        $this->_Status = $_Status;
    }

    //CONSTRUCTOR DE LA CLASE
    function __construct() {
        
    }
    
    //funcion para buscar los datos de un recurso especifico
    public function BuscarDatosRecurso()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $datos = array();
        
        //TIRA SQL PARA CAPTURAR DATOS DEL RECURSO
        $sql = 'SELECT descripcion, status FROM recurso WHERE id_recurso = "'.$this->get_IdRecurso().'"';
        
        //MANDO EJECUTAR EL QUERY
        $buscar = $conn->ejecutarQuery($sql);
        
        //VERIFICO QUE HAYAN RESULTADOS
        if( mysql_num_rows($buscar) > 0 )
        {
            //RECORRO EL REGISTRO, O LA FILA
            while( $row = mysql_fetch_array($buscar) )
            {
                $datos['id_recurso'][0] = $this->get_IdRecurso(); 
                $datos['descripcion'][0] = $row['descripcion'];//CAPTURO LA DESCRIPCION
                $datos['status'][0] = $row['status'];//CAPTURO STATUS DEL RECURSO
            }
        }
        else
        {
            //igualo el array a vacio, esto en caso de encontrar resultados
            $datos['id_ecurso'][0] = ""; 
            $datos['descripcion'][0] = "";
            $datos['status'][0] = "";
        }
        
        echo json_encode( $datos ); //CONVIERTO EL ARRAY EN JSON PARA USARLO EN EL AJAX
        //ESTE SE RECIBE EN AJAX EN respuesta
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function RegistrarRecurso()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //consulto para verficar que no exista el recurso que se desea registrar
        $verficar = $conn->ejecutarQuery("SELECT id_recurso FROM recurso WHERE descripcion = '".$this->get_Descripcion()."' AND status = '1'");
        
        //verifico que el recurso no haya sido inactivado
        $verificar_inactividad = $conn->ejecutarQuery("SELECT id_recurso FROM recurso WHERE descripcion = '".$this->get_Descripcion()."' AND status = '0'");
        
        if(mysql_num_rows($verficar) > 0 ) //en caso de encontrar un nombre de recurso igual al ingresado por el usuario
        {
            //devuelvo este msj que se mostrará al usuario
            $resp = "Ya existe el recurso que desea registrar, verifique el nombre del recurso, e intente nuevamente";
        }
    
        else if(mysql_num_rows($verificar_inactividad) > 0 ) 
        {
            //si estaba inactivo se procede a cambiar el status mediante un update
            while( $row = mysql_fetch_array($verificar_inactividad) )
            {
                $sql = "UPDATE recurso SET status = '1' WHERE id_recurso = '".$row['id_recurso']."' ";

                //MANDO EJECUTAR EL QUERY
                $registrar = $conn->ejecutarQuery($sql);

                //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
                if( $registrar > 0 )
                {
                    //esta variable se retorna como respuesta que recibira el ajax
                    $resp = 1;
                }
                else
                {
                    //si hubo algun problema con la base de datos se devolvera este msj
                    $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
                }
            }
        }
        else //en caso que no se encuentren coincidencias, es decir no exista el recurso, se procede a realizar la insercion
        {
            //TIRA SQL PARA registrar DATOS DEL RECURSO
            $sql = "INSERT INTO recurso(descripcion, status) VALUES('".$this->get_Descripcion()."', '1')";

            //MANDO EJECUTAR EL QUERY
            $registrar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
            if( $registrar > 0 )
            {
                //si la insercion fue realizada de manera correcta
                $resp = 1;
            }
            else
            {
                //si hubo un problema durante la insercion
                $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
            }
        }
        
        echo $resp;
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function ModificarRecurso()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //consulto para verficar que no existan algo repetido
        $verficar = $conn->ejecutarQuery("SELECT id_recurso FROM recurso WHERE descripcion = '".$this->get_Descripcion()."' AND status = '1' AND id_recurso != '".$this->get_IdRecurso()."'");
        //echo mysql_num_rows($verficar);
        if( mysql_num_rows($verficar) > 0 )
        {
            while( $row = mysql_fetch_array($verficar) )
            {
                if( $row['id_recurso'] == $this->get_IdRecurso() ) //presionó modificar sin cambiar nada o dejando todo como esta en base de datos
                {
                    $sql = "UPDATE recurso SET descripcion = '".$this->get_Descripcion()."', status = '".$this->get_Status()."' WHERE id_recurso = '".$this->get_IdRecurso()."'";

                    //MANDO EJECUTAR EL QUERY
                    $modificar = $conn->ejecutarQuery($sql) or die (mysql_error());

                    //VERIFICO QUE SE HAYA REALIZADO la modificacion
                    if( $modificar > 0 )
                    {
                        $resp = 1;
                    }
                    else
                    {
                        $resp = 0;
                    }
                }
                else
                {
                    $resp = "El nombre del recurso ya se encuentran asignados a otro recurso, verifique e intente nuevamente.";
                }
            }
        }
        else //en caso que no hayan coincidencias 
        {
            $sql = "UPDATE recurso SET descripcion = '".$this->get_Descripcion()."', status = '".$this->get_Status()."' WHERE id_recurso = '".$this->get_IdRecurso()."'";

            //MANDO EJECUTAR EL QUERY
            $modificar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO la modificacion
            if( $modificar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    
    public function EliminarRecurso()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
    
            //en caso de no estar relacionado aplicamos eliminacion fisica
            //TIRA SQL PARA eliminar DATOS DEL RECURSO
            $sql = "DELETE FROM recurso WHERE id_recurso = '".$this->get_IdRecurso()."'";

            //MANDO EJECUTAR EL QUERY
            $eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el borrado
            if( $eliminar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
   
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    /*FUNCION PARA BUSCAR SUGERENCIAS DE CODIGO Y NOMBRE DEL RECURSO*/
    public function SugerenciasDeRecursos( $descripcion )
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        if( strlen($descripcion) > 0 )
        {
            $sql = 'SELECT id_recurso, descripcion, status FROM recurso WHERE descripcion LIKE "%'.$descripcion.'%" AND status = 1  LIMIT 7';
            /*EJECUTO EL QUERY*/
            $buscar = $conn->ejecutarQuery( $sql );

            if( mysql_num_rows($buscar) != 0 )
            {
                while($row = mysql_fetch_array($buscar))
                {
                    if( $row['status'] == 1 )
                    {
                        echo' 
                        <li onclick="Buscar('.$row['id_recurso'].')">'.$row['descripcion'].'</li>
                     ';
                    }else{}
                }
            }
            else
            {
                echo' 
                        <li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>
                     ';
            }
        }
        
        $conn->cerrar();
        
    }
    
    //funcion para extraer todos los recursos activos y cargarlos en selects
    public function CargarRecursos()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT id_recurso, descripcion FROM recurso WHERE status = '1' ORDER BY descripcion";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
        if( mysql_num_rows( $buscar ) > 0 )
        {
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <option value="'.$row['id_recurso'].'"> '.$row['descripcion'].' </option>                    
                    ';
            }
        }
        else
        {
            echo'
                    <option value="0">NO HAY RECURSOS REGISTRADOS</option>                    
                ';
        }
    }
    
    /*funcion para cargar el catalogo*/
    public function ListarRecursos()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT id_recurso, descripcion FROM recurso WHERE status = '1' ORDER BY descripcion ASC";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
        if( mysql_num_rows( $buscar ) > 0 )
        {
            echo ' 
                    <table class="table table-striped table-bordered table-hover" id="tabla_recursos">
                        <thead>
                            <tr>
                                <th width="85%">Descripción del Recurso</th>
                                <th width="15%">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tabla_recursos">

              ';
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <tr onclick="Buscar('.$row['id_recurso'].')"> 
                            <td width="85%">'.$row['descripcion'].' </td>
                            <td width="15%"><button class="btn btn-danger"><i class=" fa fa-trash-o"></i></button></td>   
                        </tr>
                    ';
            }
            echo '  
                    </tbody>
                </table>
                
                <script>
                        $("#tabla_recursos").dataTable();
                    
                </script>
              ';
        }
        else
        {
            echo'
                    <tr> 
                        <td colspan="3">NO HAY RECURSOS REGISTRADOS</td>
                    </tr>                   
                ';
        }
    }

    
}
