<?php

include_once("conexionBD.php");

class ProfesionOcupacion {
    
    private $_Id_Profesion;
    private $_Descripcion_Profesion;
    private $_Status_Profesion;
    private $conn;
    
    
    public function get_Id_Profesion() {
        return $this->_Id_Profesion;
    }

    public function get_Descripcion_Profesion() {
        return $this->_Descripcion_Profesion;
    }

    public function get_Status_Profesion() {
        return $this->_Status_Profesion;
    }

    public function set_Id_Profesion($_Id_Profesion) {
        $this->_Id_Profesion = $_Id_Profesion;
    }

    public function set_Descripcion_Profesion($_Descripcion_Profesion) {
        $this->_Descripcion_Profesion = $_Descripcion_Profesion;
    }

    public function set_Status_Profesion($_Status_Profesion) {
        $this->_Status_Profesion = $_Status_Profesion;
    }

    //CONSTRUCTOR DE LA CLASE
    function __construct() {
        
    }
    
    //funcion para buscar los datos de profesion ocupacion especifico
    public function BuscarDatosProfesionOcupacion()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $datos = array();
        
        //TIRA SQL PARA CAPTURAR DATOS DE LA OCUPACION
        $sql = 'SELECT descripcion_profesion , status_profesion FROM profesion_ocupacion WHERE id_profesion = "'.$this->get_Id_Profesion().'"';
        
        //MANDO EJECUTAR EL QUERY
        $buscar = $conn->ejecutarQuery($sql);
        
        //VERIFICO QUE HAYAN RESULTADOS
        if( mysql_num_rows($buscar) > 0 )
        {
            //RECORRO EL REGISTRO, O LA FILA
            while( $row = mysql_fetch_array($buscar) )
            {
                $datos['id_profesion'][0] = $this->get_Id_Profesion(); 
                $datos['descripcion_profesion'][0] = $row['descripcion_profesion'];//CAPTURO EL NOMBRE
                $datos['status_profesion'][0] = $row['status_profesion'];//CAPTURO STATUS DE LA PROFESION
            }
        }
        else
        {
            //igualo el array a vacio, esto en caso de encontrar resultados
            $datos['id_profesion'][0] = ""; 
            $datos['descripcion_profesion'][0] = "";
            $datos['status_profesion'][0] = "";
        }
        
        echo json_encode( $datos ); //CONVIERTO EL ARRAY EN JSON PARA USARLO EN EL AJAX
        //ESTE SE RECIBE EN AJAX EN respuesta
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function RegistrarProfesionOcupacion()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //consulto para verficar que no exista la profesion que se desea registrar
        $verficar = $conn->ejecutarQuery("SELECT id_profesion FROM profesion_ocupacion WHERE descripcion_profesion = '".$this->get_Descripcion_Profesion()."' AND status_profesion = '1'");
        
        //verifico que la profesion no haya sido inactivado
        $verificar_inactividad = $conn->ejecutarQuery("SELECT id_profesion FROM profesion_ocupacion WHERE descripcion_profesion = '".$this->get_Descripcion_Profesion()."' AND status_profesion = '0'");
        
        if(mysql_num_rows($verficar) > 0 ) //en caso de encontrar una descripcion de PROFESION igual al ingresado por el usuario
        {
            //devuelvo este msj que se mostrará al usuario
            $resp = "Ya existe el Profesion Ocupacion que desea registrar, verifique la Descripcion, e intente nuevamente";
        }
     
        else if(mysql_num_rows($verificar_inactividad) > 0 ) 
        {
            //si estaba inactivo se procede a cambiar el status mediante un update
            while( $row = mysql_fetch_array($verificar_inactividad) )
            {
                $sql = "UPDATE profesion_ocupacion SET status_profesion = '1' WHERE id_profesion = '".$row['id_profesion']."' ";

                //MANDO EJECUTAR EL QUERY
                $registrar = $conn->ejecutarQuery($sql);

                //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
                if( $registrar > 0 )
                {
                    //esta variable se retorna como respuesta que recibira el ajax
                    $resp = 1;
                }
                else
                {
                    //si hubo algun problema con la base de datos se devolvera este msj
                    $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
                }
            }
        }
        else //en caso que no se encuentren coincidencias, es decir no exista la profesion, se procede a realizar la insercion
        {
            //TIRA SQL PARA registrar DATOS DE PROFESION
            $sql = "INSERT INTO profesion_ocupacion (descripcion_profesion, status_profesion) VALUES('".$this->get_Descripcion_Profesion()."', '1')";
            
            //MANDO EJECUTAR EL QUERY
            $registrar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
            if( $registrar > 0 )
            {
                //si la insercion fue realizada de manera correcta
                $resp = 1;
            }
            else
            {
                //si hubo un problema durante la insercion
                $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
            }
        }
        
        echo $resp;
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function ModificarProfesionOcupacion()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //consulto para verficar que no existan algo repetido
        $verficar = $conn->ejecutarQuery("SELECT id_profesion FROM profesion_ocupacion WHERE descripcion_profesion = '".$this->get_Descripcion_Profesion()."' AND status_profesion = '1' AND id_profesion != '".$this->get_Id_Profesion()."'");
        //echo mysql_num_rows($verficar);
        if( mysql_num_rows($verficar) > 0 )
        {
            while( $row = mysql_fetch_array($verficar) )
            {
                if( $row['id_profesion'] == $this->get_Id_Profesion() ) //presionó modificar sin cambiar nada o dejando todo como esta en base de datos
                {
                    $sql = "UPDATE profesion_ocupacion SET descripcion_profesion = '".$this->get_Descripcion_Profesion()."', status_profesion = '".$this->get_Status_Profesion()."' WHERE id_profesion = '".$this->get_Id_Profesion()."'";

                    //MANDO EJECUTAR EL QUERY
                    $modificar = $conn->ejecutarQuery($sql) or die (mysql_error());

                    //VERIFICO QUE SE HAYA REALIZADO la modificacion
                    if( $modificar > 0 )
                    {
                        $resp = 1;
                    }
                    else
                    {
                        $resp = 0;
                    }
                }
                else
                {
                    $resp = "La Profesion Ocupacion se encuentra asignado, verifique e intente nuevamente.";
                }
            }
        }
        else //en caso que no hayan coincidencias 
        {
            $sql = "UPDATE profesion_ocupacion SET descripcion_profesion = '".$this->get_Descripcion_Profesion()."', status_profesion = '".$this->get_Status_Profesion()."' WHERE id_profesion = '".$this->get_Id_Profesion()."'";

            //MANDO EJECUTAR EL QUERY
            $modificar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO la modificacion
            if( $modificar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    
    public function EliminarProfesionOcupacion()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
       
            //en caso de no estar relacionado aplicamos eliminacion fisica
            //TIRA SQL PARA eliminar DATOS DE PROFESION OCUPACION 
            $sql = "DELETE FROM profesion_ocupacion WHERE id_profesion = '".$this->get_Id_Profesion()."'";

            //MANDO EJECUTAR EL QUERY
            $eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el borrado
            if( $eliminar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
       
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    /*FUNCION PARA BUSCAR SUGERENCIAS DE DESCRIPCION DE PROFESION OCUPACION*/
    public function SugerenciasDeProfesionOcupacion( $descripcion_profesion)
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        if( strlen($descripcion_profesion) > 0 )
        {
            $sql = 'SELECT id_profesion, descripcion_profesion, status_profesion FROM profesion_ocupacion WHERE descripcion_profesion LIKE "%'.$descripcion_profesion.'%" AND status_profesion = 1  LIMIT 7';
            /*EJECUTO EL QUERY*/
            $buscar = $conn->ejecutarQuery( $sql );

            if( mysql_num_rows($buscar) != 0 )
            {
                while($row = mysql_fetch_array($buscar))
                {
                    if( $row['status'] == 1 )
                    {
                        echo' 
                        <li onclick="Buscar('.$row['id_profesion'].')">'.$row['descripcion_profesion'].'</li>
                     ';
                    }else{}
                }
            }
            else
            {
                echo' 
                        <li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>
                     ';
            }
        }
        
        $conn->cerrar();
        
    }
    
    //funcion para extraer todos los departamento activos y cargarlos en selects
    public function CargarProfesionOcupacion()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT id_profesion, descripcion_profesion FROM profesion_ocupacion WHERE status_profesion = '1' ORDER BY descripcion_profesion";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
        if( mysql_num_rows( $buscar ) > 0 )
        {
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <option value="'.$row['id_profesion'].'"> '.$row['descripcion_profesion'].' </option>                    
                    ';
            }
        }
        else
        {
            echo'
                    <option value="0">NO HAY PROFESION U OCUPACION REGISTRADOS</option>                    
                ';
        }
    }
    
    /*funcion para cargar el catalogo*/
    public function ListarProfesionOcupacion()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT id_profesion, descripcion_profesion FROM profesion_ocupacion WHERE status_profesion = '1' ORDER BY descripcion_profesion ASC";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
        if( mysql_num_rows( $buscar ) > 0 )
        {
            echo ' 
                    <table class="table table-striped table-bordered table-hover" id="tabla_profesion">
                        <thead>
                            <tr>
                                <th width="85%">Descripción de Profesion Ocupacion/th>
                                <th width="15%">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tabla_profesion">

              ';
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <tr onclick="Buscar('.$row['id_profesion'].')"> 
                            <td width="85%">'.$row['descripcion_profesion'].' </td>
                            <td width="15%"><button class="btn btn-danger"><i class=" fa fa-trash-o"></i></button></td>   
                        </tr>
                    ';
            }
            echo '  
                    </tbody>
                </table>
                
                <script>
                        $("#tabla_profesion_ocupacion").dataTable();
                    
                </script>
              ';
        }
        else
        {
            echo'
                    <tr> 
                        <td colspan="3">NO HAY PROFESION U OCUPACION REGISTRADOS</td>
                    </tr>                   
                ';
        }
    }

    
}
