<?php

include_once '../modelo/conexionBD.php';

class Parroquia{
    
    private $_IdParroquia;
    private $_CodigoCneParroquia;
    private $_NombreParroquia;
    private $_StatusParroquia;
    private $_IdMunicipio;
    private $conn;
    
    function get_IdParroquia() {
        return $this->_IdParroquia;
    }

    function get_CodigoCneParroquia() {
        return $this->_CodigoCneParroquia;
    }

    function get_NombreParroquia() {
        return $this->_NombreParroquia;
    }

    function get_StatusParroquia() {
        return $this->_StatusParroquia;
    }

    function get_IdMunicipio() {
        return $this->_IdMunicipio;
    }

    function set_IdParroquia($_IdParroquia) {
        $this->_IdParroquia = $_IdParroquia;
    }

    function set_CodigoCneParroquia($_CodigoCneParroquia) {
        $this->_CodigoCneParroquia = $_CodigoCneParroquia;
    }

    function set_NombreParroquia($_NombreParroquia) {
        $this->_NombreParroquia = $_NombreParroquia;
    }

    function set_StatusParroquia($_StatusParroquia) {
        $this->_StatusParroquia = $_StatusParroquia;
    }

    function set_IdMunicipio($_IdMunicipio) {
        $this->_IdMunicipio = $_IdMunicipio;
    }

    
    
    //CONSTRUCTOR DE LA CLASE
    function __construct() {
        
    }
    
    //funcion para buscar los datos de un estado especifico
    public function BuscarDatosParroquia()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $datos = array();
        
        //TIRA SQL PARA CAPTURAR DATOS DEL ESTADO
        $sql = 'SELECT parroquia.codigo_cne_parroquia, parroquia.nombre_parroquia, parroquia.id_municipio, municipio.id_estado FROM parroquia, municipio WHERE parroquia.id_parroquia = "'.$this->get_IdParroquia().'" AND municipio.id_municipio = parroquia.id_municipio';
        
        //MANDO EJECUTAR EL QUERY
        $buscar = $conn->ejecutarQuery($sql);
        
        //VERIFICO QUE HAYAN RESULTADOS
        if( mysql_num_rows($buscar) > 0 )
        {
            //RECORRO EL REGISTRO, O LA FILA
            while( $row = mysql_fetch_array($buscar) )
            {
                $datos['id_parroquia'][0] = $this->get_IdParroquia(); 
                $datos['codigo_cne_parroquia'][0] = $row['codigo_cne_parroquia']; //CAPTURO CODIGO DEL ESTADO
                $datos['nombre_parroquia'][0] = $row['nombre_parroquia'];//CAPTURO NOMBRE DEL ESTADO
                $datos['id_estado'][0] = $row['id_estado'];//CAPTURO STATUS DEL ESTADO
                $datos['id_municipio'][0] = $row['id_municipio'];//CAPTURO STATUS DEL ESTADO
            }
        }
        else
        {
            //igualo el array a vacio, esto en caso de encontrar resultados
            $datos['id_parroquia'][0] = ""; 
            $datos['codigo_cne_parroquia'][0] = "";
            $datos['nombre_parroquia'][0] = "";
            $datos['id_estado'][0] = 0;
            $datos['id_municipio'][0] = 0;
        }
        
        echo json_encode( $datos ); //CONVIERTO EL ARRAY EN JSON PARA USARLO EN EL AJAX
        //ESTE SE RECIBE EN AJAX EN respuesta
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function RegistrarParroquia(  )
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //consulto para verficar que no exista el municipio que se desea registrar
        $verficar = $conn->ejecutarQuery("SELECT id_parroquia FROM parroquia WHERE nombre_parroquia = '".$this->get_NombreParroquia()."' AND id_municipio = '".$this->get_IdMunicipio()."' AND status_parroquia = '1'");
        $verificar_codigo_cne = $conn->ejecutarQuery("SELECT id_parroquia FROM parroquia WHERE codigo_cne_parroquia = '".$this->get_CodigoCneParroquia()."' AND status_parroquia = '1'");
        //verifico que el estado no haya sido inactivado
        $verificar_inactividad = $conn->ejecutarQuery("SELECT id_parroquia FROM parroquia WHERE codigo_cne_parroquia = '".$this->get_CodigoCneParroquia()."' AND nombre_parroquia = '".$this->get_NombreParroquia()."' AND id_municipio = '".$this->get_IdMunicipio()."' AND status_parroquia = '0'");
        
        if(mysql_num_rows($verficar) > 0 ) //en caso de encontrar un nombre de estado igual al ingresado por el usuario
        {
            //devuelvo este msj que se mostrará al usuario
            $resp = "Ya existe la parroquia que desea registrar, verifique el nombre de la parroquiao, e intente nuevamente";
        }
        else if( mysql_num_rows($verificar_codigo_cne) > 0 )//en caso de encontrar un codigo de estado igual al ingresado por el usuario
        {
            //devuelvo este msj que se mostrará al usuario
            $resp = "Ya existe una parroquia con este código, verifique el código ingresado, e intente nuevamente";
        }
        else if(mysql_num_rows($verificar_inactividad) > 0 ) 
        {
            //si estaba inactivo se procede a cambiar el status mediante un update
            while( $row = mysql_fetch_array($verificar_inactividad) )
            {
                $sql = "UPDATE parroquia SET status_parroquia = '1' WHERE id_parroquia = '".$row['id_parroquia']."' ";

                //MANDO EJECUTAR EL QUERY
                $registrar = $conn->ejecutarQuery($sql);

                //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
                if( $registrar > 0 )
                {
                    //esta variable se retorna como respuesta que recibira el ajax
                    $resp = 1;
                }
                else
                {
                    //si hubo algun problema con la base de datos se devolvera este msj
                    $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
                    
                }
            }
        }
        else //en caso que no se encuentren coincidencias, es decir no exista el estado, se procede a realizar la insercion
        {
            //TIRA SQL PARA registrar DATOS DEL ESTADO
            
            $sql = "INSERT INTO parroquia(codigo_cne_parroquia, nombre_parroquia, status_parroquia, id_municipio) VALUES('".$this->get_CodigoCneParroquia()."', '".$this->get_NombreParroquia()."', '1', '".$this->get_IdMunicipio()."')";

            //MANDO EJECUTAR EL QUERY
            $registrar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
            if( $registrar > 0 )
            {
                //si la insercion fue realizada de manera correcta
                $resp = 1;
                
            }
            else
            {
                //si hubo un problema durante la insercion
                $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
                
            }
        }
        
        echo $resp;
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function ModificarParroquia()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //echo "SELECT id_estado FROM estado WHERE nombre_estado = '".$this->get_NombreEstado()."' OR codigo_cne_estado = '".$this->get_CodigoCneEstado()."'";
        //consulto para verficar que no existan algo repetido
        $verficar = $conn->ejecutarQuery("SELECT id_parroquia FROM parroquia WHERE nombre_parroquia = '".$this->get_NombreParroquia()."' OR codigo_cne_parroquia = '".$this->get_CodigoCneParroquia()."' AND status_parroquia = '1' AND id_municipio = '".$this->get_IdMunicipio()."'");
        //echo mysql_num_rows($verficar);
        
        if( mysql_num_rows($verficar) > 0 )
        {
            while( $row = mysql_fetch_array($verficar) )
            {
                if( $row['id_parroquia'] == $this->get_IdParroquia() ) //presionó modificar sin cambiar nada o dejando todo como esta en base de datos
                {
                    $sql = "UPDATE parroquia SET codigo_cne_parroquia = '".$this->get_CodigoCneParroquia()."', nombre_parroquia = '".$this->get_NombreParroquia()."', status_parroquia = '".$this->get_StatusParroquia()."', id_municipio = '".$this->get_IdMunicipio()."' WHERE id_parroquia = '".$this->get_IdParroquia()."'";

                    //MANDO EJECUTAR EL QUERY
                    $modificar = $conn->ejecutarQuery($sql) or die (mysql_error());

                    //VERIFICO QUE SE HAYA REALIZADO la modificacion
                    if( $modificar > 0 )
                    {
                        $resp = 1;
                        
                        
                    }
                    else
                    {
                        $resp = 0;
                        
                    }
                }
                else
                {
                    $resp = "El codigo del CNE o el nombre de la parroquia ya se encuentran asignados a otro municipio, verifique e intente nuevamente.";
                }
            }
        }
        else //en caso que no hayan coincidencias 
        {
            $sql = "UPDATE parroquia SET codigo_cne_parroquia = '".$this->get_CodigoCneParroquia()."', nombre_parroquia = '".$this->get_NombreParroquia()."', status_parroquia = '".$this->get_StatusParroquia()."', id_municipio = '".$this->get_IdMunicipio()."' WHERE id_parroquia = '".$this->get_IdParroquia()."'";

            //MANDO EJECUTAR EL QUERY
            $modificar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO la modificacion
            if( $modificar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    
    public function EliminarParroquia()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        $SQL_verificar = "SELECT id_parroquia FROM parroquia WHERE id_parroquia = '".$this->get_IdParroquia()."'";
        
        $verificar = $conn->ejecutarQuery($SQL_verificar);
        
        
        if(mysql_num_rows($verificar) > 0 )
        {
            //en caso de que este relacionado, hacemos una actualizacion y pasa a inactivo.. eliminacion logica
            
            $sql = "UPDATE  parroquia SET status_parroquia = '0' WHERE id_parroquia = '".$this->get_IdParroquia()."'";

            //MANDO EJECUTAR EL QUERY
            $eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el update
            if( $eliminar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        else
        {
            //en caso de no estar relacionado aplicamos eliminacion fisica
            //TIRA SQL PARA eliminar DATOS DEL ESTADO
            $sql = "DELETE FROM parroquia WHERE id_parroquia = '".$this->get_IdParroquia()."'";

            //MANDO EJECUTAR EL QUERY
            $eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el borrado
            if( $eliminar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
     public function SugerenciasDeParroquias( $codigo, $nombre )
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        /*COMPARO PARA SABER POR CUAL DE LOS PARAMETROS REALIZO LA BUSQUEDA*/
        if( strlen($codigo) > 0  && strlen($nombre) == 0 )
        {
            //echo $this->get_IdMunicipio();
            if($this->get_IdMunicipio() > 0){
                
                $sql = 'SELECT id_parroquia, codigo_cne_parroquia, status_parroquia FROM parroquia WHERE codigo_cne_parroquia LIKE "%'.$codigo.'%" AND id_municipio = "'.$this->get_IdMunicipio().'" LIMIT 10';
            }
            else{
                $sql = 'SELECT id_parroquia, codigo_cne_parroquia, status_parroquia FROM parroquia WHERE codigo_cne_parroquia LIKE "%'.$codigo.'%" LIMIT 10';
            }
            /*EJECUTO EL QUERY*/
            $buscar = $conn->ejecutarQuery( $sql );
            
            
            if( mysql_num_rows($buscar) > 0 )
            {
                while( $row = mysql_fetch_array($buscar) )
                {
                    if( $row['status_parroquia'] == 1 )
                    {
                        echo' 
                                <li onclick="Buscar('.$row['id_parroquia'].')">'.$row['codigo_cne_parroquia'].'</li>
                             ';
                    }
                    else{}
                }
            }
            else
            {
                echo' 
                        <li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>
                    ';
            }
        }
        else if( strlen($codigo) == 0  && strlen($nombre) > 0 )
        {
            if($this->get_IdMunicipio() > 0){
                
                $sql = 'SELECT id_parroquia, nombre_parroquia, status_parroquia FROM parroquia WHERE nombre_parroquia LIKE "%'.$nombre.'%" AND id_municipio = "'.$this->get_IdMunicipio().'" AND status_parroquia = 1 LIMIT 10';
            }
            else{
                $sql = 'SELECT id_parroquia, nombre_parroquia, status_parroquia FROM parroquia WHERE nombre_parroquia LIKE "%'.$nombre.'%" LIMIT 10';
            }
            /*EJECUTO EL QUERY*/
            $buscar = $conn->ejecutarQuery( $sql );

            if( mysql_num_rows($buscar) != 0 )
            {
                while($row = mysql_fetch_array($buscar))
                {
                    if( $row['status_parroquia'] == 1 )
                    {
                        echo' 
                        <li onclick="Buscar('.$row['id_parroquia'].')">'.$row['nombre_parroquia'].'</li>
                     ';
                    }
                    else{}
                }
            }
            else
            {
                echo' 
                        <li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>
                     ';
            }
        }
        
        $conn->cerrar();
        
    }
    
    public function ListarParroquias()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        //$sql = "SELECT estado.id_estado, municipio.id_municipio, municipio.nombre_municipio, municipio.codigo_cne_municipio FROM estado, municipio WHERE estado.status_estado = '1' AND municipio.id_estado = estado.id_estado AND municipio.status_municipio = '1' ORDER BY municipio.nombre_municipio ASC";
        $sql = "SELECT municipio.id_municipio, parroquia.id_parroquia, parroquia.codigo_cne_parroquia, parroquia.nombre_parroquia FROM municipio, parroquia WHERE municipio.status_municipio = '1' AND parroquia.id_municipio = municipio.id_municipio AND parroquia.status_parroquia = '1' ORDER BY parroquia.nombre_parroquia ASC";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
        if( mysql_num_rows( $buscar ) > 0 )
        {
            echo ' 
                    <table class="table table-striped table-bordered table-hover" id="tabla_parroquias">
                        <thead>
                            <tr>
                                <th width="25%">Cód. CNE</th>
                                <th width="60%">Nombre Parroquias</th>
                                <th width="15%">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tabla_estados">

              ';
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <tr onclick="Buscar('.$row['id_parroquia'].')"> 
                            <td width="25%">'.$row['codigo_cne_parroquia'].' </td>
                            <td width="60%">'.$row['nombre_parroquia'].' </td>
                            <td width="15%"> a</td>   
                        </tr>
                    ';
            }
            echo '  
                    </tbody>
                </table>
                
                <script>
                        $("#tabla_parroquias").dataTable();
                    
                </script>
              ';
        }
        else
        {
            echo'
                    <tr> 
                        <td colspan="3">NO HAY PARROQUIAS REGISTRADOS</td>
                    </tr>                   
                ';
        }
    }
    
    public function CargarParroquias()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT id_parroquia, nombre_parroquia FROM parroquia WHERE status_parroquia = '1' AND id_municipio = '".$this->get_IdMunicipio()."' ORDER BY nombre_parroquia";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
         
        if( mysql_num_rows( $buscar ) > 0 )
        {
            echo '<option value="0">SELECCIONE LA PARROQUIA</option>';
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <option value="'.$row['id_parroquia'].'"> '.$row['nombre_parroquia'].' </option>                    
                    ';
            }
        }
        else
        {
            echo'
                    <option value="0">NO HAY PARROQUIAS REGISTRADOS</option>                    
                ';
        }
    }
    
}



