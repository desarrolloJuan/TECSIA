<?php

include_once("conexionBD.php");

class Discipulado {
    
    private $_IdDiscipulado;
    private $_Descripcion;
    private $_StatusDiscipulado;
    private $conn;
    
    
    public function get_IdDiscipulado() {
        return $this->_IdDiscipulado;
    }

    public function get_Descripcion() {
        return $this->_Descripcion;
    }

    public function get_StatusDiscipulado() {
        return $this->_StatusDiscipulado;
    }

    public function set_IdDiscipulado($_IdDiscipulado) {
        $this->_IdDiscipulado = $_IdDiscipulado;
    }

    public function set_Descripcion($_Descripcion) {
        $this->_Descripcion = $_Descripcion;
    }

    public function set_StatusDiscipulado($_StatusDiscipulado) {
        $this->_StatusDiscipulado = $_StatusDiscipulado;
    }
  
    //CONSTRUCTOR DE LA CLASE
    function __construct() {
        
    }
    
    //funcion para buscar los datos de un estado especifico
    public function BuscarDatosDiscipulado()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $datos = array();
        
        //TIRA SQL PARA CAPTURAR DATOS DEL ESTADO
        $sql = 'SELECT descripcion, status_discipulado FROM discipulado WHERE id_discipulado = "'.$this->get_IdDiscipulado().'"';
       
        //MANDO EJECUTAR EL QUERY
        $buscar = $conn->ejecutarQuery($sql);
        
        //VERIFICO QUE HAYAN RESULTADOS
        if( mysql_num_rows($buscar) > 0 )
        {
            //RECORRO EL REGISTRO, O LA FILA
            while( $row = mysql_fetch_array($buscar) )
            {
                $datos['id_discipulado'][0] = $this->get_IdDiscipulado();
                $datos['descripcion'][0] = $row['descripcion'];//CAPTURO NOMBRE DEL ESTADO
                $datos['status_discipulado'][0] = $row['status_discipulado'];//CAPTURO STATUS DEL ESTADO
            }
        }
        else
        {
            //igualo el array a vacio, esto en caso de encontrar resultados
            $datos['id_discipulado'][0] = ""; 
            $datos['descripcion'][0] = "";
            $datos['status_discipulados'][0] = "";
        }
        
        echo json_encode( $datos ); //CONVIERTO EL ARRAY EN JSON PARA USARLO EN EL AJAX
        //ESTE SE RECIBE EN AJAX EN respuesta
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function RegistrarDiscipulado()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //consulto para verficar que no exista el estado que se desea registrar
        $verficar = $conn->ejecutarQuery("SELECT id_discipulado FROM discipulado WHERE descripcion = '".$this->get_Descripcion()."' AND status_discipulado = '1'");
        //verifico que el estado no haya sido inactivado
        $verificar_inactividad = $conn->ejecutarQuery("SELECT id_discipulado FROM discipulado WHERE descripcion = '".$this->get_Descripcion()."'  AND status_discipulado = '0'");
        
        if(mysql_num_rows($verficar) > 0 ) //en caso de encontrar un nombre de estado igual al ingresado por el usuario
        {
            //devuelvo este msj que se mostrará al usuario
            $resp = "Ya existe el Discipulado que desea registrar, verifique e intente nuevamente";
        }
         else if(mysql_num_rows($verificar_inactividad) > 0 ) 
        {
            //si estaba inactivo se procede a cambiar el status mediante un update
            while( $row = mysql_fetch_array($verificar_inactividad) )
            {
                $sql = "UPDATE discipulado SET status_discipulado = '1' WHERE id_discipulado = '".$row['id_discipulado']."' ";

                //MANDO EJECUTAR EL QUERY
                $registrar = $conn->ejecutarQuery($sql);

                //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
                if( $registrar > 0 )
                {
                    //esta variable se retorna como respuesta que recibira el ajax
                    $resp = 1;
                }
                else
                {
                    //si hubo algun problema con la base de datos se devolvera este msj
                    $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
                }
            }
        }
        else //en caso que no se encuentren coincidencias, es decir no exista el estado, se procede a realizar la insercion
        {
            //TIRA SQL PARA registrar DATOS DEL ESTADO
            $sql = "INSERT INTO discipulado(descripcion, status_discipulado) VALUES('".$this->get_Descripcion()."', '1')";

            //MANDO EJECUTAR EL QUERY
            $registrar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
            if( $registrar > 0 )
            {
                //si la insercion fue realizada de manera correcta
                $resp = 1;
            }
            else
            {
                //si hubo un problema durante la insercion
                $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
            }
        }
        
        echo $resp;
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function ModificarDiscipulado()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        //echo "SELECT id_estado FROM estado WHERE nombre_estado = '".$this->get_NombreEstado()."' OR codigo_cne_estado = '".$this->get_CodigoCneEstado()."'";
        //consulto para verficar que no existan algo repetido
        $verficar = $conn->ejecutarQuery("SELECT id_discipulado FROM discipulado WHERE descripcion = '".$this->get_Descripcion()."' AND status_discipulado = '1'");
        //echo mysql_num_rows($verficar);
        if( mysql_num_rows($verficar) > 0 )
        {
            $resp = "Ya existe un Discipulado, verifique e intente nuevamente.";
        }
        else
        {        
            $sql = "UPDATE discipulado SET  descripcion = '".$this->get_Descripcion()."', status_discipulado = '1' WHERE id_discipulado = '".$this->get_IdDiscipulado()."'";

            //MANDO EJECUTAR EL QUERY
            $modificar = $conn->ejecutarQuery($sql) or die (mysql_error());

            //VERIFICO QUE SE HAYA REALIZADO la modificacion
            if( $modificar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = "Problemas con la base de datos, intente nuevamente, si el problema persiste comuniquese con el administrador del sistema";
            }
                
        }
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    
    public function EliminarDiscipulado()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //$SQL_verificar = "SELECT id_municipio FROM municipio WHERE id_estado = '".$this->get_IdEstado()."'";
        
        //$verificar = $conn->ejecutarQuery($SQL_verificar);
        
        
        //if(mysql_num_rows($verificar) > 0 )
        //{
            //en caso de que este relacionado, hacemos una actualizacion y pasa a inactivo.. eliminacion logica
            
            //$sql = "UPDATE estado SET status_estado = '0' WHERE id_estado = '".$this->get_IdEstado()."'";

            //MANDO EJECUTAR EL QUERY
            //$eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el update
            //if( $eliminar > 0 )
            //{
                //$resp = 1;
            //}
            //else
            //{
                //$resp = 0;
            //}
        //}
        //else
        //{
            //en caso de no estar relacionado aplicamos eliminacion fisica
            //TIRA SQL PARA eliminar DATOS DEL ESTADO
            $sql = "DELETE FROM discipulado WHERE id_discipulado = '".$this->get_IdDiscipulado()."'";

            //MANDO EJECUTAR EL QUERY
            $eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el borrado
            if( $eliminar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        //}
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    /*FUNCION PARA BUSCAR SUGERENCIAS DE CODIGO Y NOMBRE DEL ESTADO*/
    public function SugerenciasDeDiscipulado( $descripcion )
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $sql = 'SELECT id_discipulado, descripcion FROM discipulado WHERE descripcion LIKE "%'.$descripcion.'%" AND status_discipulado = 1';
        /*EJECUTO EL QUERY*/
        $buscar = $conn->ejecutarQuery( $sql );

        if( mysql_num_rows($buscar) > 0 )
        {
            while($row = mysql_fetch_array($buscar))
            {
                
                echo' 
                    <li onclick="Buscar('.$row['id_discipulado'].')">'.$row['descripcion'].'</li>
                 ';
                
            }
        }
        else
        {
            echo' 
                    <li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>
                 ';
        }
        
        
        $conn->cerrar();
        
    }
    
    /*funcion para cargar el catalogo*/
    public function ListaDiscipulado()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT id_discipulado, descripcion FROM discipulado WHERE status_discipulado = '1' ORDER BY descripcion ASC";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
        if( mysql_num_rows( $buscar ) > 0 )
        {
            echo ' 
                    <table class="table table-striped table-bordered table-hover" id="tabla_discipulado">
                        <thead>
                            <tr>
                                <th width="60%">Discipulado</th>
                                <th width="15%">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tabla_discipulado">

              ';
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <tr onclick="Buscar('.$row['id_discipulado'].')"> 
                            <td width="60%">'.$row['descripcion'].' </td>
                            <td width="15%"> a</td>   
                        </tr>
                    ';
            }
            echo '  
                    </tbody>
                </table>
                
                <script>
                        $("#tabla_discipulado").dataTable();
                    
                </script>
              ';
        }
        else
        {
            echo'
                    <tr> 
                        <td colspan="3">NO HAY DISCIPULADO REGISTRADOS</td>
                    </tr>                   
                ';
        }
    }
}