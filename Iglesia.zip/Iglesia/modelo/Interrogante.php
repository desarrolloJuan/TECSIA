<?php

include_once("conexionBD.php");

class Interrogante {
    
    private $_IdInterrogante;
    private $_Descripcion;
    private $_StatusInterrogante;
    private $conn;
    
    function get_IdInterrogante() {
        return $this->_IdInterrogante;
    }

    function get_Descripcion() {
        return $this->_Descripcion;
    }

    function get_StatusInterrogante() {
        return $this->_StatusInterrogante;
    }

    function set_IdInterrogante($_IdInterrogante) {
        $this->_IdInterrogante = $_IdInterrogante;
    }

    function set_Descripcion($_Descripcion) {
        $this->_Descripcion = $_Descripcion;
    }

    function set_StatusInterrogante($_StatusInterrogante) {
        $this->_StatusInterrogante = $_StatusInterrogante;
    }

        
  
    //CONSTRUCTOR DE LA CLASE
    function __construct() {
        
    }
    
    //funcion para buscar los datos de un estado especifico
    public function BuscarDatosInterrogante()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $datos = array();
        
        //TIRA SQL PARA CAPTURAR DATOS DEL ESTADO
        $sql = 'SELECT descripcion, status_interrogante FROM interrogante WHERE id_interrogante = "'.$this->get_IdInterrogante().'"';
       
        //MANDO EJECUTAR EL QUERY
        $buscar = $conn->ejecutarQuery($sql);
        
        //VERIFICO QUE HAYAN RESULTADOS
        if( mysql_num_rows($buscar) > 0 )
        {
            //RECORRO EL REGISTRO, O LA FILA
            while( $row = mysql_fetch_array($buscar) )
            {
                $datos['id_interrogante'][0] = $this->get_IdInterrogante();
                $datos['descripcion'][0] = $row['descripcion'];//CAPTURO NOMBRE DEL ESTADO
                $datos['status_interrogante'][0] = $row['status_interrogante'];//CAPTURO STATUS DEL ESTADO
            }
        }
        else
        {
            //igualo el array a vacio, esto en caso de encontrar resultados
            $datos['id_interrogante'][0] = ""; 
            $datos['descripcion'][0] = "";
            $datos['status_interrogante'][0] = "";
        }
        
        echo json_encode( $datos ); //CONVIERTO EL ARRAY EN JSON PARA USARLO EN EL AJAX
        //ESTE SE RECIBE EN AJAX EN respuesta
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function RegistrarInterrogante()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //consulto para verficar que no exista el estado que se desea registrar
        $verficar = $conn->ejecutarQuery("SELECT id_interrogante FROM interrogante WHERE descripcion = '".$this->get_Descripcion()."' AND status_interrogante = '1'");
        //verifico que el estado no haya sido inactivado
        $verificar_inactividad = $conn->ejecutarQuery("SELECT id_interrogante FROM interrogante WHERE descripcion = '".$this->get_Descripcion()."'  AND status_interrogante = '0'");
        
        if(mysql_num_rows($verficar) > 0 ) //en caso de encontrar un nombre de estado igual al ingresado por el usuario
        {
            //devuelvo este msj que se mostrará al usuario
            $resp = "Ya existe la Interrogante que desea registrar, verifique e intente nuevamente";
        }
         else if(mysql_num_rows($verificar_inactividad) > 0 ) 
        {
            //si estaba inactivo se procede a cambiar el status mediante un update
            while( $row = mysql_fetch_array($verificar_inactividad) )
            {
                $sql = "UPDATE interrogante SET status_interrogante = '1' WHERE id_interrogante = '".$row['id_interrogante']."' ";

                //MANDO EJECUTAR EL QUERY
                $registrar = $conn->ejecutarQuery($sql);

                //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
                if( $registrar > 0 )
                {
                    //esta variable se retorna como respuesta que recibira el ajax
                    $resp = 1;
                }
                else
                {
                    //si hubo algun problema con la base de datos se devolvera este msj
                    $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
                }
            }
        }
        else //en caso que no se encuentren coincidencias, es decir no exista el estado, se procede a realizar la insercion
        {
            //TIRA SQL PARA registrar DATOS DEL ESTADO
            $sql = "INSERT INTO interrogante(descripcion, status_interrogante) VALUES('".$this->get_Descripcion()."', '1')";

            //MANDO EJECUTAR EL QUERY
            $registrar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
            if( $registrar > 0 )
            {
                //si la insercion fue realizada de manera correcta
                $resp = 1;
            }
            else
            {
                //si hubo un problema durante la insercion
                $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
            }
        }
        
        echo $resp;
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function ModificarInterrogante()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        //echo "SELECT id_estado FROM estado WHERE nombre_estado = '".$this->get_NombreEstado()."' OR codigo_cne_estado = '".$this->get_CodigoCneEstado()."'";
        //consulto para verficar que no existan algo repetido
        $verficar = $conn->ejecutarQuery("SELECT id_interrogante FROM interrogante WHERE descripcion = '".$this->get_Descripcion()."' AND status_interrogante = '1'");
        //echo mysql_num_rows($verficar);
        if( mysql_num_rows($verficar) > 0 )
        {
            $resp = "Ya existe la Interrogante, verifique e intente nuevamente.";
        }
        else
        {        
            $sql = "UPDATE interrogante SET  descripcion = '".$this->get_Descripcion()."', status_interrogante = '1' WHERE id_interrogante = '".$this->get_IdInterrogante()."'";

            //MANDO EJECUTAR EL QUERY
            $modificar = $conn->ejecutarQuery($sql) or die (mysql_error());

            //VERIFICO QUE SE HAYA REALIZADO la modificacion
            if( $modificar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = "Problemas con la base de datos, intente nuevamente, si el problema persiste comuniquese con el administrador del sistema";
            }
                
        }
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    
     public function EliminarInterrogante()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        $SQL_verificar = "SELECT id_interrogante FROM interrogante WHERE id_interrogante = '".$this->get_IdInterrogante()."'";
        
        $verificar = $conn->ejecutarQuery($SQL_verificar);
        
        
        if(mysql_num_rows($verificar) > 0 )
        {
            //en caso de que este relacionado, hacemos una actualizacion y pasa a inactivo.. eliminacion logica
            
            $sql = "UPDATE interrogante SET status_interrogante = '0' WHERE id_interrogante = '".$this->get_IdInterrogante()."'";

            //MANDO EJECUTAR EL QUERY
            $eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el update
            if( $eliminar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        else
        {
            //en caso de no estar relacionado aplicamos eliminacion fisica
            //TIRA SQL PARA eliminar DATOS DEL ESTADO
            $sql = "DELETE FROM interrogante WHERE id_interrogante = '".$this->get_IdInterrogante()."'";

            //MANDO EJECUTAR EL QUERY
            $eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el borrado
            if( $eliminar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    /*FUNCION PARA BUSCAR SUGERENCIAS DE CODIGO Y NOMBRE DEL ESTADO*/
     public function SugerenciasDeInterrogante( $descripcion )
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        /*COMPARO PARA SABER POR CUAL DE LOS PARAMETROS REALIZO LA BUSQUEDA*/
        if( strlen($descripcion) > 0 )
        {
             $sql = 'SELECT id_interrogante, descripcion, status_interrogante FROM interrogante WHERE descripcion LIKE "%'.$descripcion.'%" AND status_interrogante = "1"';
            /*EJECUTO EL QUERY*/
            $buscar = $conn->ejecutarQuery( $sql );

            if( mysql_num_rows($buscar) > 0 )
            {
                while($row = mysql_fetch_array($buscar))
                {
                    if( $row['status_interrogante'] == 1 )
                    {
                        echo' 
                        <li onclick="Buscar('.$row['id_interrogante'].')">'.$row['descripcion'].'</li>
                     ';
                    }else{}
                }
            }
            else
            {
                echo' 
                        <li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>
                     ';
            }
        }
          
            
       
      
        
        $conn->cerrar();
        
    }
    
    /*funcion para cargar el catalogo*/
    public function ListaInterrogante()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT id_interrogante, descripcion FROM interrogante WHERE status_interrogante = '1' ORDER BY descripcion ASC";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
        if( mysql_num_rows( $buscar ) > 0 )
        {
            echo ' 
                    <table class="table table-striped table-bordered table-hover" id="tabla_interrogante">
                        <thead>
                            <tr>
                                <th width="60%">Interrogante</th>
                                <th width="15%">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tabla_interrogante">

              ';
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <tr onclick="Buscar('.$row['id_interrogante'].')"> 
                            <td width="60%">'.$row['descripcion'].' </td>
                            <td width="15%"> a</td>   
                        </tr>
                    ';
            }
            echo '  
                    </tbody>
                </table>
                
                <script>
                        $("#tabla_interrogante").dataTable();
                    
                </script>
              ';
        }
        else
        {
            echo'
                    <tr> 
                        <td colspan="3">NO HAY INTERROGANTE REGISTRADAS</td>
                    </tr>                   
                ';
        }
    }
}