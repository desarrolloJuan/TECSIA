<?php

include_once("conexionBD.php");

class Usuario {
    
    private $_IdUsuario;
    private $_NombreUsuario;
    private $_Clave;
    private $_StatusUsuario;
    private $_RespuestaSeguridad;
    private $_IdPregunta;
    private $_IdPersona;
    private $con;
    

    public function get_IdUsuario() {
        return $this->_IdUsuario;
    }

    public function get_NombreUsuario() {
        return $this->_NombreUsuario;
    }

    public function get_Clave() {
        return $this->_Clave;
    }

    public function get_StatusUsuario() {
        return $this->_StatusUsuario;
    }

    public function set_IdUsuario($_IdUsuario) {
        $this->_IdUsuario = $_IdUsuario;
    }

    public function set_NombreUsuario($_NombreUsuario) {
        $this->_NombreUsuario = $_NombreUsuario;
    }

    public function set_Clave($_Clave) {
        $this->_Clave = $_Clave;
    }

    public function set_StatusUsuario($_StatusUsuario) {
        $this->_StatusUsuario = $_StatusUsuario;
    }

    function get_RespuestaSeguridad() {
        return $this->_RespuestaSeguridad;
    }
    function get_IdPregunta() {
        return $this->_IdPregunta;
    }

    function set_IdPregunta($_IdPregunta) {
        $this->_IdPregunta = $_IdPregunta;
    }

    
    function set_RespuestaSeguridad($_RespuestaSeguridad) {
        $this->_RespuestaSeguridad = $_RespuestaSeguridad;
    }

        
    public function get_IdPersona() {
        return $this->_IdPersona;
    }

    public function set_IdPersona($_IdPersona) {
        $this->_IdPersona = $_IdPersona;
    }

    
    
    function __construct() {
        
    }
            
    public function BuscarDatosUsuario()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
    
        $sql = "SELECT id_usuario, status_usuario, id_persona FROM usuario WHERE nombre_usuario = '".$this->get_NombreUsuario()."' AND clave = '".$this->get_Clave()."' ";
        //echo $sql;
        $buscar = $conn->ejecutarQuery($sql);

        $resp = 0;
        
        if( mysql_num_rows($buscar) > 0 )
        {
            while( $row = mysql_fetch_array($buscar) )
            {
                $this->set_IdUsuario( $row['id_usuario'] );
                $this->set_StatusUsuario( $row['status_usuario'] );
                $this->set_IdPersona( $row['id_persona'] );
                $resp = 1;
            }
        }
        else 
        {
            $resp = 0;
        }
        
        $conn->cerrar();
        return $resp;
    }
    
    
    public function BuscarUsuario()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $datos = array();
        
        $sql = "SELECT usuario.id_usuario, usuario.nombre_usuario, usuario.clave, usuario.status_usuario, usuario.id_pregunta, usuario.respuesta_seguridad, usuario.id_persona, persona.cedula, foto_perfil.ruta  
                FROM usuario, foto_perfil, persona
                WHERE usuario.id_persona = '".$this->get_IdPersona()."' AND persona.id_persona = '".$this->get_IdPersona()."' AND foto_perfil.id_usuario = usuario.id_usuario";
        
        //echo $sql;
        
        $buscar = $conn->ejecutarQuery($sql);

        $resp = 0;
        
        if( mysql_num_rows($buscar) > 0 )
        {
            while( $row = mysql_fetch_array($buscar) )
            {
                $datos['id_usuario'][0] = $row['id_usuario'];
                $datos['nombre_usuario'][0] = $row['nombre_usuario'];
                $datos['clave'][0] = $row['clave'];
                $datos['status_usuario'][0] = $row['status_usuario'];
                $datos['id_pregunta'][0] = $row['id_pregunta'];
                $datos['respuesta_seguridad'][0] = $row['respuesta_seguridad'];
                $datos['id_persona'][0] = $row['id_persona'];
                $datos['cedula'][0] = $row['cedula'];
                $datos['ruta'][0] = $row['ruta'];
            }
        }
        else 
        {
            $datos = "";
        }
        
        $conn->cerrar();
        echo json_encode($datos);
    }
    
    
    public function RegistrarUsuario()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = " INSERT INTO usuario(nombre_usuario, clave, status_usuario, respuesta_seguridad, id_pregunta, cedula)
                 VALUES('".$this->get_NombreUsuario()."', '".$this->get_Clave()."'), '".$this->get_StatusUsuario()."', '".$this->get_RespuestaSeguridad()."', '".$this->get_IdPregunta()."', '".$this->get_Cedula()."'";
        
        $registrar = $conn->ejecutarQuery($sql);
        
        if( $registrar )
        {
            $resp = 1;
        }
        else 
        {
            $resp = 0;
        }
        
        $conn->cerrar();
        return $resp;
    }
    
    public function BuscarDisponibilidad()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = ' SELECT id_usuario FROM usuario WHERE nombre_usuario = "'.$this->get_NombreUsuario().'" ';
        
        $buscar = $conn->ejecutarQuery( $sql );
        
        if( mysql_num_rows( $buscar ) > 0 )
        {
            echo 2;
        }
        else
        {
            echo 0;
        }
        
        $conn->cerrar();
    }
    
    
    public function ListarUsuarios()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = 'SELECT usuario.id_usuario, usuario.nombre_usuario, usuario.status_usuario, usuario.id_persona, foto_perfil.ruta, persona.cedula, persona.nombres, persona.apellidos
                FROM usuario, foto_perfil, persona
                WHERE foto_perfil.id_usuario = usuario.id_usuario AND persona.id_persona = usuario.id_persona';
        
        $buscar = $conn->ejecutarQuery($sql);
        
        if(mysql_num_rows($buscar) > 0 )
        {
            echo ' 
                    <table class="table table-striped table-bordered table-hover" id="tabla_usuarios">
                        <thead>
                            <tr>
                                <th width="15%">Foto</th>
                                <th width="40%">Nombres y Apellidos</th>
                                <th width="15%">Nombre de Usuario</th>
                                <th width="15%">Status</th>
                                <th width="15%">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tabla_usua">

              ';
            while( $row = mysql_fetch_array( $buscar ) )
            {
                if( $row['status_usuario'] == 1 )
                {
                    $status = "Activo";
                    $class = "label label-success";
                }
                else
                {
                    $status = "Inactivo";
                    $class = "label label-danger";
                }
                echo'
                        <tr onclick="Buscar('.$row['id_persona'].')"> 
                            <td class="center" width="15%"><img class="btn btn-default btn-circle" src="../assets/img/'.$row['ruta'].'"> </td>
                            <td width="40%">'.utf8_encode($row['nombres'])." ".utf8_encode($row['apellidos']).' </td>
                            <td width="15%">'.$row['nombre_usuario'].' </td>
                            <td width="15%"><span class="'.$class.'">'.$status.'</span></td>   
                            <td width="15%"><button class="btn btn-danger" title="Eliminar el usuario '.$row['nombre_usuario'].'"><i class=" fa fa-trash-o"></i></button></td>    
                        </tr>
                    ';
            }
            echo '  
                    </tbody>
                </table>
                
                <script>
                        $("#tabla_usuarios").dataTable();
                </script>
              ';
        }
        else
        {
            
        }
    }
}
