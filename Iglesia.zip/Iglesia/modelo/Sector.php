<?php

include_once '../modelo/conexionBD.php';

class Sector{
    
    private $_IdSector;
    private $_NombreSector;
    private $_StatusSector;
    private $_IdParroquia;
    private $_conn;
    
    function get_IdSector() {
        return $this->_IdSector;
    }

    function get_NombreSector() {
        return $this->_NombreSector;
    }

    function get_StatusSector() {
        return $this->_StatusSector;
    }

    function get_IdParroquia() {
        return $this->_IdParroquia;
    }

    function set_IdSector($_IdSector) {
        $this->_IdSector = $_IdSector;
    }

    function set_NombreSector($_NombreSector) {
        $this->_NombreSector = $_NombreSector;
    }

    function set_StatusSector($_StatusSector) {
        $this->_StatusSector = $_StatusSector;
    }

    function set_IdParroquia($_IdParroquia) {
        $this->_IdParroquia = $_IdParroquia;
    }

    //CONSTRUCTOR DE LA CLASE
    function __construct() {
        
    }
    
    //funcion para buscar los datos de un estado especifico
    public function BuscarDatosSector()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $datos = array();
        
        //TIRA SQL PARA CAPTURAR DATOS DEL ESTADO
        $sql = 'SELECT sector.nombre_sector, sector.id_parroquia, parroquia.id_municipio, municipio.id_estado FROM sector, parroquia, municipio WHERE sector.id_sector = "'.$this->get_IdSector().'" AND parroquia.id_parroquia = sector.id_parroquia AND municipio.id_municipio = parroquia.id_municipio';
        
        //MANDO EJECUTAR EL QUERY
        $buscar = $conn->ejecutarQuery($sql);
        
        //VERIFICO QUE HAYAN RESULTADOS
        if( mysql_num_rows($buscar) > 0 )
        {
            //RECORRO EL REGISTRO, O LA FILA
            while( $row = mysql_fetch_array($buscar) )
            {
                $datos['id_sector'][0] = $this->get_IdSector(); 
                $datos['nombre_sector'][0] = $row['nombre_sector'];//CAPTURO NOMBRE DEL ESTADO
                $datos['id_estado'][0] = $row['id_estado'];//CAPTURO STATUS DEL ESTADO
                $datos['id_municipio'][0] = $row['id_municipio'];//CAPTURO STATUS DEL ESTADO
                $datos['id_parroquia'][0] = $row['id_parroquia'];
            }
        }
        else
        {
            //igualo el array a vacio, esto en caso de encontrar resultados
            $datos['id_sector'][0] = ""; 
            $datos['nombre_sector'][0] = "";
            $datos['id_estado'][0] = 0;
            $datos['id_municipio'][0] = 0;
            $datos['id_parroquia'][0] = 0;
        }
        
        echo json_encode( $datos ); //CONVIERTO EL ARRAY EN JSON PARA USARLO EN EL AJAX
        //ESTE SE RECIBE EN AJAX EN respuesta
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function RegistrarSector(  )
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //consulto para verficar que no exista el municipio que se desea registrar
        $verficar = $conn->ejecutarQuery("SELECT id_sector FROM sector WHERE nombre_sector = '".$this->get_NombreSector()."' AND id_parroquia = '".$this->get_IdParroquia()."' AND status_sector = '1'");
        //$verificar_codigo_cne = $conn->ejecutarQuery("SELECT id_parroquia FROM parroquia WHERE codigo_cne_parroquia = '".$this->get_CodigoCneParroquia()."' AND status_parroquia = '1'");
        //verifico que el estado no haya sido inactivado
        $verificar_inactividad = $conn->ejecutarQuery("SELECT id_sector FROM sector WHERE nombre_sector = '".$this->get_NombreSector()."' AND id_parroquia = '".$this->get_IdParroquia()."' AND status_sector = '0'");
        
        if(mysql_num_rows($verficar) > 0 ) //en caso de encontrar un nombre de estado igual al ingresado por el usuario
        {
            //devuelvo este msj que se mostrará al usuario
            $resp = "Ya existe la parroquia que desea registrar, verifique el nombre de la parroquiao, e intente nuevamente";
        }
        else if(mysql_num_rows($verificar_inactividad) > 0 ) 
        {
            //si estaba inactivo se procede a cambiar el status mediante un update
            while( $row = mysql_fetch_array($verificar_inactividad) )
            {
                $sql = "UPDATE sector SET status_sector = '1' WHERE id_sector = '".$row['id_sector']."' ";

                //MANDO EJECUTAR EL QUERY
                $registrar = $conn->ejecutarQuery($sql);

                //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
                if( $registrar > 0 )
                {
                    //esta variable se retorna como respuesta que recibira el ajax
                    $resp = 1;
                }
                else
                {
                    //si hubo algun problema con la base de datos se devolvera este msj
                    $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
                    
                }
            }
        }
        else //en caso que no se encuentren coincidencias, es decir no exista el estado, se procede a realizar la insercion
        {
            //TIRA SQL PARA registrar DATOS DEL ESTADO
            
            $sql = "INSERT INTO sector(nombre_sector, status_sector, id_parroquia) VALUES('".$this->get_NombreSector()."', '1', '".$this->get_IdParroquia()."')";

            //MANDO EJECUTAR EL QUERY
            $registrar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
            if( $registrar > 0 )
            {
                //si la insercion fue realizada de manera correcta
                $resp = 1;
                
            }
            else
            {
                //si hubo un problema durante la insercion
                $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
                
            }
        }
        
        echo $resp;
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function ModificarSector()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //echo "SELECT id_estado FROM estado WHERE nombre_estado = '".$this->get_NombreEstado()."' OR codigo_cne_estado = '".$this->get_CodigoCneEstado()."'";
        //consulto para verficar que no existan algo repetido
        $verficar = $conn->ejecutarQuery("SELECT id_sector FROM sector WHERE nombre_sector = '".$this->get_NombreSector()."' AND status_sector = '1' AND id_parroquia = '".$this->get_IdParroquia()."'");
        //echo mysql_num_rows($verficar);
        
        if( mysql_num_rows($verficar) > 0 )
        {
            while( $row = mysql_fetch_array($verficar) )
            {
                if( $row['id_sector'] == $this->get_IdSector() ) //presionó modificar sin cambiar nada o dejando todo como esta en base de datos
                {
                    $sql = "UPDATE sector SET nombre_sector = '".$this->get_NombreSector()."', status_sector = '".$this->get_StatusSector()."', id_parroquia = '".$this->get_IdParroquia()."' WHERE id_sector = '".$this->get_IdSector()."'";

                    //MANDO EJECUTAR EL QUERY
                    $modificar = $conn->ejecutarQuery($sql) or die (mysql_error());

                    //VERIFICO QUE SE HAYA REALIZADO la modificacion
                    if( $modificar > 0 )
                    {
                        $resp = 1;
                        
                        
                    }
                    else
                    {
                        $resp = 0;
                        
                    }
                }
                else
                {
                    $resp = "El codigo del CNE o el nombre de la parroquia ya se encuentran asignados a otro municipio, verifique e intente nuevamente.";
                }
            }
        }
        else //en caso que no hayan coincidencias 
        {
            $sql = "UPDATE sector SET nombre_sector = '".$this->get_NombreSector()."', status_sector = '".$this->get_StatusSector()."', id_parroquia = '".$this->get_IdParroquia()."' WHERE id_sector = '".$this->get_IdSector()."'";

            //MANDO EJECUTAR EL QUERY
            $modificar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO la modificacion
            if( $modificar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function EliminarSector()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        $SQL_verificar = "SELECT id_sector FROM sector WHERE id_sector = '".$this->get_IdSector()."'";
        
        $verificar = $conn->ejecutarQuery($SQL_verificar);
        
        
        if(mysql_num_rows($verificar) > 0 )
        {
            //en caso de que este relacionado, hacemos una actualizacion y pasa a inactivo.. eliminacion logica
            
            $sql = "UPDATE  sector SET status_sector = '0' WHERE id_sector = '".$this->get_IdSector()."'";

            //MANDO EJECUTAR EL QUERY
            $eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el update
            if( $eliminar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        else
        {
            //en caso de no estar relacionado aplicamos eliminacion fisica
            //TIRA SQL PARA eliminar DATOS DEL ESTADO
            $sql = "DELETE FROM sector WHERE id_sector = '".$this->get_IdSector()."'";

            //MANDO EJECUTAR EL QUERY
            $eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el borrado
            if( $eliminar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function SugerenciasDeSectores( $nombre )
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        /*COMPARO PARA SABER POR CUAL DE LOS PARAMETROS REALIZO LA BUSQUEDA*/
        if( strlen($nombre) > 0 )          
        {
            if($this->get_IdParroquia() > 0){
                
                $sql = 'SELECT id_sector, nombre_sector, status_sector FROM sector WHERE nombre_sector LIKE "%'.$nombre.'%" AND id_parroquia = "'.$this->get_IdParroquia().'" LIMIT 10';
            }
            else{
                $sql = 'SELECT id_sector, nombre_sector, status_sector FROM sector WHERE nombre_sector LIKE "%'.$nombre.'%" LIMIT 10';
            }
            /*EJECUTO EL QUERY*/
            $buscar = $conn->ejecutarQuery( $sql );

            if( mysql_num_rows($buscar) != 0 )
            {
                while($row = mysql_fetch_array($buscar))
                {
                    if( $row['status_sector'] == 1 )
                    {
                        echo' 
                        <li onclick="Buscar('.$row['id_sector'].')">'.$row['nombre_sector'].'</li>
                     ';
                        
                    }else{}
                }
            }
            else
            {
                echo' 
                        <li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>
                     ';
            }
        }
        else 
        {
            echo' 
                        <li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>
                     ';
        }
        
        $conn->cerrar();
        
    }
    
    public function ListarSectores()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT id_sector, nombre_sector FROM sector WHERE status_sector = '1' ORDER BY nombre_sector ASC";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
        if( mysql_num_rows( $buscar ) > 0 )
        {
            echo ' 
                    <table class="table table-striped table-bordered table-hover" id="tabla_sectores">
                        <thead>
                            <tr>
                                <th width="60%">Nombre Sectores</th>
                                <th width="15%">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tabla_sectores">

              ';
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <tr onclick="Buscar('.$row['id_sector'].')"> 
                            <td width="60%">'.$row['nombre_sector'].' </td>
                            <td width="15%"><button class="btn btn-danger"><i class=" fa fa-cog"></i></button></td>   
                        </tr>
                    ';
            }
            echo '  
                    </tbody>
                </table>
                
                <script>
                        $("#tabla_sectores").dataTable();
                    
                </script>
              ';
        }
        else
        {
            echo'
                    <tr> 
                        <td colspan="3">NO HAY SECTORES REGISTRADOS</td>
                    </tr>                   
                ';
        }
    }
    
    
}

