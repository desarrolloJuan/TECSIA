<?php

include_once("conexionBD.php");

class Departamento {
    
    private $_IdDepartamento;
    private $_Nombre;
    private $_Status;
    private $conn;
    
    
    public function get_IdDepartamento() {
        return $this->_IdDepartamento;
    }

    public function get_Nombre() {
        return $this->_Nombre;
    }

    public function get_Status() {
        return $this->_Status;
    }

    public function set_IdDepartamento($_IdDepartamento) {
        $this->_IdDepartamento = $_IdDepartamento;
    }

    public function set_Nombre($_Nombre) {
        $this->_Nombre = $_Nombre;
    }

    public function set_Status($_Status) {
        $this->_Status = $_Status;
    }

    //CONSTRUCTOR DE LA CLASE
    function __construct() {
        
    }
    
    //funcion para buscar los datos de un departamento especifico
    public function BuscarDatosDepartamento()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $datos = array();
        
        //TIRA SQL PARA CAPTURAR DATOS DEL DEPARTAMENTO
        $sql = 'SELECT nombre, status FROM departamento WHERE id_departamento = "'.$this->get_IdDepartamento().'"';
        
        //MANDO EJECUTAR EL QUERY
        $buscar = $conn->ejecutarQuery($sql);
        
        //VERIFICO QUE HAYAN RESULTADOS
        if( mysql_num_rows($buscar) > 0 )
        {
            //RECORRO EL REGISTRO, O LA FILA
            while( $row = mysql_fetch_array($buscar) )
            {
                $datos['id_departamento'][0] = $this->get_IdDepartamento(); 
                $datos['nombre'][0] = $row['nombre'];//CAPTURO EL NOMBRE
                $datos['status'][0] = $row['status'];//CAPTURO STATUS DEL DEPARTAMENTO
            }
        }
        else
        {
            //igualo el array a vacio, esto en caso de encontrar resultados
            $datos['id_dones'][0] = ""; 
            $datos['nombre'][0] = "";
            $datos['status'][0] = "";
        }
        
        echo json_encode( $datos ); //CONVIERTO EL ARRAY EN JSON PARA USARLO EN EL AJAX
        //ESTE SE RECIBE EN AJAX EN respuesta
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function RegistrarDepartamento()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //consulto para verficar que no exista el departamento que se desea registrar
        $verficar = $conn->ejecutarQuery("SELECT id_departamento FROM departamento WHERE nombre = '".$this->get_Nombre()."' AND status = '1'");
        
        //verifico que el departamento no haya sido inactivado
        $verificar_inactividad = $conn->ejecutarQuery("SELECT id_departamento FROM departamento WHERE nombre = '".$this->get_Nombre()."' AND status = '0'");
        
        if(mysql_num_rows($verficar) > 0 ) //en caso de encontrar un nombre de DEPARTAMENTO igual al ingresado por el usuario
        {
            //devuelvo este msj que se mostrará al usuario
            $resp = "Ya existe el departamento que desea registrar, verifique el nombre del departamento, e intente nuevamente";
        }
     
        else if(mysql_num_rows($verificar_inactividad) > 0 ) 
        {
            //si estaba inactivo se procede a cambiar el status mediante un update
            while( $row = mysql_fetch_array($verificar_inactividad) )
            {
                $sql = "UPDATE departamento SET status = '1' WHERE id_departamento = '".$row['id_departamento']."' ";

                //MANDO EJECUTAR EL QUERY
                $registrar = $conn->ejecutarQuery($sql);

                //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
                if( $registrar > 0 )
                {
                    //esta variable se retorna como respuesta que recibira el ajax
                    $resp = 1;
                }
                else
                {
                    //si hubo algun problema con la base de datos se devolvera este msj
                    $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
                }
            }
        }
        else //en caso que no se encuentren coincidencias, es decir no exista el departamento, se procede a realizar la insercion
        {
            //TIRA SQL PARA registrar DATOS DEL DEPARTAMENTO
            $sql = "INSERT INTO departamento (nombre, status) VALUES('".$this->get_Nombre()."', '1')";
            
            //MANDO EJECUTAR EL QUERY
            $registrar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO EL REGISTRO
            if( $registrar > 0 )
            {
                //si la insercion fue realizada de manera correcta
                $resp = 1;
            }
            else
            {
                //si hubo un problema durante la insercion
                $resp = "Problemas con la base de datos, comuniquese con el administrador del Sistema";
            }
        }
        
        echo $resp;
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    public function ModificarDepartamento()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
        //consulto para verficar que no existan algo repetido
        $verficar = $conn->ejecutarQuery("SELECT id_departamento FROM departamento WHERE nombre = '".$this->get_Nombre()."' AND status = '1' AND id_departamento != '".$this->get_IdDepartamento()."'");
        //echo mysql_num_rows($verficar);
        if( mysql_num_rows($verficar) > 0 )
        {
            while( $row = mysql_fetch_array($verficar) )
            {
                if( $row['id_departamento'] == $this->get_IdDepartamento() ) //presionó modificar sin cambiar nada o dejando todo como esta en base de datos
                {
                    $sql = "UPDATE departamento SET nombre = '".$this->get_Nombre()."', status = '".$this->get_Status()."' WHERE id_departamento = '".$this->get_IdDepartamento()."'";

                    //MANDO EJECUTAR EL QUERY
                    $modificar = $conn->ejecutarQuery($sql) or die (mysql_error());

                    //VERIFICO QUE SE HAYA REALIZADO la modificacion
                    if( $modificar > 0 )
                    {
                        $resp = 1;
                    }
                    else
                    {
                        $resp = 0;
                    }
                }
                else
                {
                    $resp = "El nombre del departamento ya se encuentran asignados a otro departamento, verifique e intente nuevamente.";
                }
            }
        }
        else //en caso que no hayan coincidencias 
        {
            $sql = "UPDATE departamento SET nombre = '".$this->get_Nombre()."', status = '".$this->get_Status()."' WHERE id_departamento = '".$this->get_IdDepartamento()."'";

            //MANDO EJECUTAR EL QUERY
            $modificar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO la modificacion
            if( $modificar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
        }
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    
    public function EliminarDepartamento()
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        $resp = 0;
        
       
            //en caso de no estar relacionado aplicamos eliminacion fisica
            //TIRA SQL PARA eliminar DATOS DEL DEPARTAMENTO
            $sql = "DELETE FROM departamento WHERE id_departamento = '".$this->get_IdDepartamento()."'";

            //MANDO EJECUTAR EL QUERY
            $eliminar = $conn->ejecutarQuery($sql);

            //VERIFICO QUE SE HAYA REALIZADO el borrado
            if( $eliminar > 0 )
            {
                $resp = 1;
            }
            else
            {
                $resp = 0;
            }
       
        
        echo $resp; 
        
        $conn->cerrar();//CIERRO LA CONEXION CON MYSQL
    }
    
    /*FUNCION PARA BUSCAR SUGERENCIAS DE CODIGO Y NOMBRE DEL DEPARTAMENTO*/
    public function SugerenciasDeDepartamentos( $nombre )
    {
        $conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
        $conn->conectar();//CONECTO CON MYSQL   
        $conn->seleccionarBD(); //SELECCIONO LA BD
        
        if( strlen($nombre) > 0 )
        {
            $sql = 'SELECT id_departamento, nombre, status FROM departamento WHERE nombre LIKE "%'.$nombre.'%" AND status = 1  LIMIT 7';
            /*EJECUTO EL QUERY*/
            $buscar = $conn->ejecutarQuery( $sql );

            if( mysql_num_rows($buscar) != 0 )
            {
                while($row = mysql_fetch_array($buscar))
                {
                    if( $row['status'] == 1 )
                    {
                        echo' 
                        <li onclick="Buscar('.$row['id_departamento'].')">'.$row['nombre'].'</li>
                     ';
                    }else{}
                }
            }
            else
            {
                echo' 
                        <li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>
                     ';
            }
        }
        
        $conn->cerrar();
        
    }
    
    //funcion para extraer todos los departamento activos y cargarlos en selects
    public function CargarDepartamentos()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT id_departamento, nombre FROM departamento WHERE status = '1' ORDER BY nombre";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
        if( mysql_num_rows( $buscar ) > 0 )
        {
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <option value="'.$row['id_departamento'].'"> '.$row['nombre'].' </option>                    
                    ';
            }
        }
        else
        {
            echo'
                    <option value="0">NO HAY DEPARTAMENTOS REGISTRADOS</option>                    
                ';
        }
    }
    
    /*funcion para cargar el catalogo*/
    public function ListarDepartamentos()
    {
        $conn = new conexionBD();
        $conn->conectar();
        $conn->seleccionarBD();
        
        $sql = "SELECT id_departamento, nombre FROM departamento WHERE status = '1' ORDER BY nombre ASC";
        
        $buscar = $conn->ejecutarQuery( $sql );
        
        if( mysql_num_rows( $buscar ) > 0 )
        {
            echo ' 
                    <table class="table table-striped table-bordered table-hover" id="tabla_departamentos">
                        <thead>
                            <tr>
                                <th width="85%">Descripción del MDepartamento/th>
                                <th width="15%">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tabla_departamentos">

              ';
            while( $row = mysql_fetch_array( $buscar ) )
            {
                echo'
                        <tr onclick="Buscar('.$row['id_departamento'].')"> 
                            <td width="85%">'.$row['nombre'].' </td>
                            <td width="15%"><button class="btn btn-danger"><i class=" fa fa-trash-o"></i></button></td>   
                        </tr>
                    ';
            }
            echo '  
                    </tbody>
                </table>
                
                <script>
                        $("#tabla_departamentos").dataTable();
                    
                </script>
              ';
        }
        else
        {
            echo'
                    <tr> 
                        <td colspan="3">NO HAY DEPARTAMENTOS REGISTRADOS</td>
                    </tr>                   
                ';
        }
    }

    
}
