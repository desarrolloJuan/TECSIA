-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 05-05-2016 a las 22:44:58
-- Versión del servidor: 5.6.16
-- Versión de PHP: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `iglesia`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `actividad`
--

CREATE TABLE IF NOT EXISTS `actividad` (
  `id_actividad` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion_actividad` varchar(300) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_actividad` date NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `cantidad_participantes` int(11) NOT NULL,
  `status_actividad` int(1) NOT NULL,
  PRIMARY KEY (`id_actividad`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `actividad_departamento`
--

CREATE TABLE IF NOT EXISTS `actividad_departamento` (
  `id_actividad_departamento` int(11) NOT NULL AUTO_INCREMENT,
  `id_actividad` int(11) NOT NULL,
  `id_departamento` int(11) NOT NULL,
  PRIMARY KEY (`id_actividad_departamento`),
  KEY `id_actividad` (`id_actividad`),
  KEY `id_departamento` (`id_departamento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `actividad_miembro`
--

CREATE TABLE IF NOT EXISTS `actividad_miembro` (
  `id_actividad_miembro` int(11) NOT NULL AUTO_INCREMENT,
  `id_actividad` int(11) NOT NULL,
  `id_miembro` int(11) NOT NULL,
  PRIMARY KEY (`id_actividad_miembro`),
  KEY `id_actividad` (`id_actividad`),
  KEY `id_miembro` (`id_miembro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `actividad_recurso`
--

CREATE TABLE IF NOT EXISTS `actividad_recurso` (
  `id_actividad_recurso` int(11) NOT NULL AUTO_INCREMENT,
  `id_actividad` int(11) NOT NULL,
  `id_recurso` int(11) NOT NULL,
  PRIMARY KEY (`id_actividad_recurso`),
  KEY `id_actividad` (`id_actividad`),
  KEY `id_recurso` (`id_recurso`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `codigo`
--

CREATE TABLE IF NOT EXISTS `codigo` (
  `id_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion_codigo` int(3) NOT NULL,
  `status_codigo` int(1) NOT NULL,
  PRIMARY KEY (`id_codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamento`
--

CREATE TABLE IF NOT EXISTS `departamento` (
  `id_departamento` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_departamento` varchar(100) NOT NULL,
  `status_departamento` int(1) NOT NULL,
  `id_iglesia` int(11) NOT NULL,
  PRIMARY KEY (`id_departamento`),
  KEY `id_iglesia` (`id_iglesia`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamento_miembro`
--

CREATE TABLE IF NOT EXISTS `departamento_miembro` (
  `id_departamento_miembro` int(11) NOT NULL AUTO_INCREMENT,
  `id_departamento` int(11) NOT NULL,
  `id_miembro` int(11) NOT NULL,
  PRIMARY KEY (`id_departamento_miembro`),
  KEY `id_departamento` (`id_departamento`),
  KEY `id_miembro` (`id_miembro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `discipulado`
--

CREATE TABLE IF NOT EXISTS `discipulado` (
  `id_discipulado` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion_discipulado` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `status_discipulado` int(1) NOT NULL,
  PRIMARY KEY (`id_discipulado`),
  UNIQUE KEY `id_discipulado` (`id_discipulado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dones`
--

CREATE TABLE IF NOT EXISTS `dones` (
  `id_dones` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id_dones`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `dones`
--

INSERT INTO `dones` (`id_dones`, `nombre`, `status`) VALUES
(1, 'DON UNO', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado`
--

CREATE TABLE IF NOT EXISTS `estado` (
  `id_estado` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_cne_estado` varchar(20) NOT NULL,
  `nombre_estado` varchar(100) NOT NULL,
  `status_estado` int(1) NOT NULL,
  PRIMARY KEY (`id_estado`),
  UNIQUE KEY `codigo_cne_estado` (`codigo_cne_estado`),
  UNIQUE KEY `nombre_estado` (`nombre_estado`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Volcado de datos para la tabla `estado`
--

INSERT INTO `estado` (`id_estado`, `codigo_cne_estado`, `nombre_estado`, `status_estado`) VALUES
(1, '20', 'YARACUY', 1),
(3, '21', 'ZULIA', 1),
(4, '22', 'AMAZONAS', 1),
(6, '51', 'BARINAS', 1),
(7, '30', 'APURE', 1),
(10, '23', 'ANZOATEGUI', 1),
(11, '90', 'FALCON', 1),
(12, '41', 'ARAGUA', 1),
(13, '60', 'BOLIVAR', 1),
(14, '17', 'SUCRE', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_civil`
--

CREATE TABLE IF NOT EXISTS `estado_civil` (
  `id_estado_civil` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion_estado_civil` varchar(50) NOT NULL,
  `status_estado_civil` int(1) NOT NULL,
  PRIMARY KEY (`id_estado_civil`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `estado_civil`
--

INSERT INTO `estado_civil` (`id_estado_civil`, `descripcion_estado_civil`, `status_estado_civil`) VALUES
(1, 'SOLTERO (A) ', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `foto_perfil`
--

CREATE TABLE IF NOT EXISTS `foto_perfil` (
  `id_foto` int(11) NOT NULL AUTO_INCREMENT,
  `ruta` varchar(200) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `status_foto` int(1) DEFAULT NULL,
  PRIMARY KEY (`id_foto`),
  UNIQUE KEY `ruta` (`ruta`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `foto_perfil`
--

INSERT INTO `foto_perfil` (`id_foto`, `ruta`, `id_usuario`, `status_foto`) VALUES
(1, 'foto_perfil/perfil-1-1.png', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `funciones`
--

CREATE TABLE IF NOT EXISTS `funciones` (
  `id_funcion` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion_funcion` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `status_funcion` int(1) NOT NULL,
  PRIMARY KEY (`id_funcion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grupo_pequeno`
--

CREATE TABLE IF NOT EXISTS `grupo_pequeno` (
  `id_grupo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_grupo` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `status_grupo` int(1) NOT NULL,
  PRIMARY KEY (`id_grupo`),
  UNIQUE KEY `nombre_grupo` (`nombre_grupo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `iglesia`
--

CREATE TABLE IF NOT EXISTS `iglesia` (
  `id_iglesia` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_iglesia` varchar(200) NOT NULL,
  `direccion` varchar(200) NOT NULL,
  `status_iglesia` int(1) NOT NULL,
  `id_sector` int(11) NOT NULL,
  `id_pastor` int(11) NOT NULL,
  PRIMARY KEY (`id_iglesia`),
  KEY `id_sector` (`id_sector`),
  KEY `id_pastor` (`id_pastor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `interrogante`
--

CREATE TABLE IF NOT EXISTS `interrogante` (
  `id_interrogante` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion_interrogante` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `status_interrogante` int(1) NOT NULL,
  PRIMARY KEY (`id_interrogante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lugar`
--

CREATE TABLE IF NOT EXISTS `lugar` (
  `id_lugar` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion_lugar` varchar(300) COLLATE utf8_spanish_ci NOT NULL,
  `status_lugar` int(1) NOT NULL,
  PRIMARY KEY (`id_lugar`),
  UNIQUE KEY `id_lugar` (`id_lugar`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `miembro`
--

CREATE TABLE IF NOT EXISTS `miembro` (
  `id_miembro` int(11) NOT NULL AUTO_INCREMENT,
  `numero_hijo` int(2) NOT NULL,
  `foto` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `observacion` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `id_persona` int(11) NOT NULL,
  `status_miembro` int(1) NOT NULL,
  PRIMARY KEY (`id_miembro`),
  KEY `id_persona` (`id_persona`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `miembro_interrogante`
--

CREATE TABLE IF NOT EXISTS `miembro_interrogante` (
  `id_miembro_interrogante` int(11) NOT NULL AUTO_INCREMENT,
  `id_miembro` int(11) NOT NULL,
  `id_interrogante` int(11) NOT NULL,
  PRIMARY KEY (`id_miembro_interrogante`),
  KEY `id_miembro` (`id_miembro`),
  KEY `id_interrogante` (`id_interrogante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `miembro_ministerio`
--

CREATE TABLE IF NOT EXISTS `miembro_ministerio` (
  `id_miembro_ministerio` int(11) NOT NULL AUTO_INCREMENT,
  `id_ministeio` int(11) NOT NULL,
  `id_miembro` int(11) NOT NULL,
  `id_tipo_miembro` int(11) NOT NULL,
  PRIMARY KEY (`id_miembro_ministerio`),
  KEY `id_ministeio` (`id_ministeio`),
  KEY `id_miembro` (`id_miembro`),
  KEY `id_tipo_miembro` (`id_tipo_miembro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ministerio`
--

CREATE TABLE IF NOT EXISTS `ministerio` (
  `id_ministerio` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_ministerio` varchar(100) NOT NULL,
  `status_ministerio` int(1) NOT NULL,
  `id_iglesia` int(11) NOT NULL,
  PRIMARY KEY (`id_ministerio`),
  KEY `id_iglesia` (`id_iglesia`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `municipio`
--

CREATE TABLE IF NOT EXISTS `municipio` (
  `id_municipio` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_cne_municipio` varchar(20) NOT NULL,
  `nombre_municipio` varchar(100) NOT NULL,
  `status_municipio` int(1) NOT NULL,
  `id_estado` int(11) NOT NULL,
  PRIMARY KEY (`id_municipio`),
  KEY `id_estado` (`id_estado`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `municipio`
--

INSERT INTO `municipio` (`id_municipio`, `codigo_cne_municipio`, `nombre_municipio`, `status_municipio`, `id_estado`) VALUES
(1, '1', 'ARISTIDES BASTIDAS', 1, 1),
(5, '13', 'BOLIVAR', 1, 1),
(6, '4', 'SAN FELIPE', 1, 1),
(7, '5', 'BRUZUAL', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nuevo_creyente`
--

CREATE TABLE IF NOT EXISTS `nuevo_creyente` (
  `id_nuevo_creyente` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fecha_ingreso` date NOT NULL,
  `status_nuevo_creyente` int(1) NOT NULL,
  `id_persona` int(11) NOT NULL,
  PRIMARY KEY (`id_nuevo_creyente`),
  UNIQUE KEY `id_nuevo_creyente` (`id_nuevo_creyente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `parroquia`
--

CREATE TABLE IF NOT EXISTS `parroquia` (
  `id_parroquia` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_cne_parroquia` varchar(20) NOT NULL,
  `nombre_parroquia` varchar(100) NOT NULL,
  `status_parroquia` int(1) NOT NULL,
  `id_municipio` int(11) NOT NULL,
  PRIMARY KEY (`id_parroquia`),
  KEY `id_municipio` (`id_municipio`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `parroquia`
--

INSERT INTO `parroquia` (`id_parroquia`, `codigo_cne_parroquia`, `nombre_parroquia`, `status_parroquia`, `id_municipio`) VALUES
(1, '10', 'SAN PABLO', 1, 1),
(2, '02', 'AROA', 1, 5),
(4, '03', 'AROA2', 1, 5),
(5, '04', 'AROA3', 1, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pastor`
--

CREATE TABLE IF NOT EXISTS `pastor` (
  `id_pastor` int(11) NOT NULL AUTO_INCREMENT,
  `especializacion` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `status_pastor` int(1) NOT NULL,
  `id_persona` int(11) NOT NULL,
  PRIMARY KEY (`id_pastor`),
  UNIQUE KEY `especializacion` (`especializacion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfil`
--

CREATE TABLE IF NOT EXISTS `perfil` (
  `id_perfil` int(11) NOT NULL,
  `descripcion_perfil` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `status_perfil` int(1) NOT NULL,
  PRIMARY KEY (`id_perfil`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfil_funciones`
--

CREATE TABLE IF NOT EXISTS `perfil_funciones` (
  `id_perfil_funcion` int(11) NOT NULL AUTO_INCREMENT,
  `id_funcion` int(11) NOT NULL,
  `id_perfil` int(11) NOT NULL,
  PRIMARY KEY (`id_perfil_funcion`),
  KEY `id_funcion` (`id_funcion`),
  KEY `id_perfil` (`id_perfil`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--

CREATE TABLE IF NOT EXISTS `persona` (
  `id_persona` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` int(8) NOT NULL COMMENT 'clave primaria de la tabla persona, integer que captura la cedula de identidad de la persona',
  `nombres` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT 'nombres de la persona, de tipo varchar una longitud maxima de 50 caracteres',
  `apellidos` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT 'apellidos de la persona, de tipo varchar, longitud maxima de 50 caracteres',
  `sexo` varchar(10) CHARACTER SET utf8 NOT NULL,
  `fecha_nacimiento` date NOT NULL COMMENT 'fecha de nacimiento de la persona',
  `direccion_persona` varchar(300) CHARACTER SET utf8 NOT NULL,
  `correo` varchar(60) CHARACTER SET utf8 NOT NULL,
  `status_persona` int(1) NOT NULL,
  `id_profesion` int(11) NOT NULL,
  `id_estado_civil` int(11) NOT NULL,
  `id_sector` int(11) NOT NULL,
  `id_telefono` int(11) NOT NULL,
  PRIMARY KEY (`id_persona`),
  KEY `id_profesion` (`id_profesion`),
  KEY `id_estado_civil` (`id_estado_civil`),
  KEY `id_sector` (`id_sector`),
  KEY `id_persona` (`id_persona`,`cedula`),
  KEY `cedula` (`cedula`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `persona`
--

INSERT INTO `persona` (`id_persona`, `cedula`, `nombres`, `apellidos`, `sexo`, `fecha_nacimiento`, `direccion_persona`, `correo`, `status_persona`, `id_profesion`, `id_estado_civil`, `id_sector`, `id_telefono`) VALUES
(1, 23573119, 'JUAN CARLOS', 'GARCIA O.', 'M', '1995-05-28', 'CALLE PRINCIPAL FRENTE A LA PLAZA', 'juanc.iuty@gmail.com', 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pregunta_seguridad`
--

CREATE TABLE IF NOT EXISTS `pregunta_seguridad` (
  `id_pregunta` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion_pregunta` varchar(400) NOT NULL DEFAULT '',
  `status_pregunta` int(1) NOT NULL,
  PRIMARY KEY (`id_pregunta`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `pregunta_seguridad`
--

INSERT INTO `pregunta_seguridad` (`id_pregunta`, `descripcion_pregunta`, `status_pregunta`) VALUES
(1, '¿COLOR FAVORITO?', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesion_ocupacion`
--

CREATE TABLE IF NOT EXISTS `profesion_ocupacion` (
  `id_profesion` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion_profesion` varchar(100) NOT NULL,
  `status_profesion` int(1) NOT NULL,
  PRIMARY KEY (`id_profesion`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `profesion_ocupacion`
--

INSERT INTO `profesion_ocupacion` (`id_profesion`, `descripcion_profesion`, `status_profesion`) VALUES
(1, 'ESTUDIANTE', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recurso`
--

CREATE TABLE IF NOT EXISTS `recurso` (
  `id_recurso` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion_recurso` varchar(100) NOT NULL,
  `status_recurso` int(1) NOT NULL,
  PRIMARY KEY (`id_recurso`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sector`
--

CREATE TABLE IF NOT EXISTS `sector` (
  `id_sector` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_cne_sector` varchar(70) NOT NULL,
  `nombre_sector` varchar(100) NOT NULL,
  `status_sector` int(1) NOT NULL,
  `id_parroquia` int(11) NOT NULL,
  PRIMARY KEY (`id_sector`),
  KEY `id_parroquia` (`id_parroquia`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `sector`
--

INSERT INTO `sector` (`id_sector`, `codigo_cne_sector`, `nombre_sector`, `status_sector`, `id_parroquia`) VALUES
(1, '100', 'LA GOTERA', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `telefono`
--

CREATE TABLE IF NOT EXISTS `telefono` (
  `id_telefono` int(11) NOT NULL AUTO_INCREMENT,
  `numero_telefono` int(7) NOT NULL,
  `status_telefono` int(1) NOT NULL,
  `id_codigo` int(1) DEFAULT NULL,
  PRIMARY KEY (`id_telefono`),
  KEY `id_codigo` (`id_codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_miembro`
--

CREATE TABLE IF NOT EXISTS `tipo_miembro` (
  `id_tipo_miembro` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion_tipo_miembro` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `status_tipo_miembro` int(1) NOT NULL,
  PRIMARY KEY (`id_tipo_miembro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT COMMENT 'autoincremento que sera la clave primaria de la tabla',
  `nombre_usuario` varchar(16) NOT NULL,
  `clave` varchar(16) NOT NULL,
  `status_usuario` int(1) NOT NULL,
  `id_pregunta` int(11) NOT NULL,
  `respuesta_seguridad` varchar(150) NOT NULL,
  `id_persona` int(11) NOT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `nombre_usuario` (`nombre_usuario`),
  KEY `id_pregunta` (`id_pregunta`),
  KEY `id_persona` (`id_persona`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nombre_usuario`, `clave`, `status_usuario`, `id_pregunta`, `respuesta_seguridad`, `id_persona`) VALUES
(1, 'JUANGARCIA', '23573119', 1, 1, 'AZUL', 1);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `actividad_departamento`
--
ALTER TABLE `actividad_departamento`
  ADD CONSTRAINT `actividad_departamento_ibfk_1` FOREIGN KEY (`id_actividad`) REFERENCES `actividad` (`id_actividad`) ON UPDATE CASCADE,
  ADD CONSTRAINT `actividad_departamento_ibfk_2` FOREIGN KEY (`id_departamento`) REFERENCES `departamento` (`id_departamento`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `actividad_miembro`
--
ALTER TABLE `actividad_miembro`
  ADD CONSTRAINT `actividad_miembro_ibfk_1` FOREIGN KEY (`id_actividad`) REFERENCES `actividad` (`id_actividad`) ON UPDATE CASCADE,
  ADD CONSTRAINT `actividad_miembro_ibfk_2` FOREIGN KEY (`id_miembro`) REFERENCES `miembro` (`id_miembro`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `actividad_recurso`
--
ALTER TABLE `actividad_recurso`
  ADD CONSTRAINT `actividad_recurso_ibfk_1` FOREIGN KEY (`id_actividad`) REFERENCES `actividad` (`id_actividad`) ON UPDATE CASCADE,
  ADD CONSTRAINT `actividad_recurso_ibfk_2` FOREIGN KEY (`id_recurso`) REFERENCES `recurso` (`id_recurso`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `departamento`
--
ALTER TABLE `departamento`
  ADD CONSTRAINT `departamento_ibfk_1` FOREIGN KEY (`id_iglesia`) REFERENCES `departamento` (`id_departamento`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `departamento_miembro`
--
ALTER TABLE `departamento_miembro`
  ADD CONSTRAINT `departamento_miembro_ibfk_1` FOREIGN KEY (`id_departamento`) REFERENCES `departamento` (`id_departamento`) ON UPDATE CASCADE,
  ADD CONSTRAINT `departamento_miembro_ibfk_2` FOREIGN KEY (`id_miembro`) REFERENCES `miembro` (`id_miembro`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `foto_perfil`
--
ALTER TABLE `foto_perfil`
  ADD CONSTRAINT `foto_perfil_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `iglesia`
--
ALTER TABLE `iglesia`
  ADD CONSTRAINT `iglesia_ibfk_1` FOREIGN KEY (`id_sector`) REFERENCES `sector` (`id_sector`) ON UPDATE CASCADE,
  ADD CONSTRAINT `iglesia_ibfk_2` FOREIGN KEY (`id_pastor`) REFERENCES `pastor` (`id_pastor`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `miembro`
--
ALTER TABLE `miembro`
  ADD CONSTRAINT `miembro_ibfk_1` FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id_persona`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `miembro_interrogante`
--
ALTER TABLE `miembro_interrogante`
  ADD CONSTRAINT `miembro_interrogante_ibfk_1` FOREIGN KEY (`id_miembro`) REFERENCES `miembro` (`id_miembro`) ON UPDATE CASCADE,
  ADD CONSTRAINT `miembro_interrogante_ibfk_2` FOREIGN KEY (`id_interrogante`) REFERENCES `interrogante` (`id_interrogante`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `miembro_ministerio`
--
ALTER TABLE `miembro_ministerio`
  ADD CONSTRAINT `miembro_ministerio_ibfk_1` FOREIGN KEY (`id_ministeio`) REFERENCES `ministerio` (`id_ministerio`) ON UPDATE CASCADE,
  ADD CONSTRAINT `miembro_ministerio_ibfk_2` FOREIGN KEY (`id_miembro`) REFERENCES `miembro` (`id_miembro`) ON UPDATE CASCADE,
  ADD CONSTRAINT `miembro_ministerio_ibfk_3` FOREIGN KEY (`id_tipo_miembro`) REFERENCES `tipo_miembro` (`id_tipo_miembro`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `ministerio`
--
ALTER TABLE `ministerio`
  ADD CONSTRAINT `ministerio_ibfk_1` FOREIGN KEY (`id_iglesia`) REFERENCES `iglesia` (`id_iglesia`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `municipio`
--
ALTER TABLE `municipio`
  ADD CONSTRAINT `municipio_ibfk_1` FOREIGN KEY (`id_estado`) REFERENCES `estado` (`id_estado`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `parroquia`
--
ALTER TABLE `parroquia`
  ADD CONSTRAINT `parroquia_ibfk_1` FOREIGN KEY (`id_municipio`) REFERENCES `municipio` (`id_municipio`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `perfil_funciones`
--
ALTER TABLE `perfil_funciones`
  ADD CONSTRAINT `perfil_funciones_ibfk_1` FOREIGN KEY (`id_funcion`) REFERENCES `funciones` (`id_funcion`) ON UPDATE CASCADE,
  ADD CONSTRAINT `perfil_funciones_ibfk_2` FOREIGN KEY (`id_perfil`) REFERENCES `perfil` (`id_perfil`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `persona`
--
ALTER TABLE `persona`
  ADD CONSTRAINT `persona_ibfk_1` FOREIGN KEY (`id_profesion`) REFERENCES `profesion_ocupacion` (`id_profesion`) ON UPDATE CASCADE,
  ADD CONSTRAINT `persona_ibfk_2` FOREIGN KEY (`id_estado_civil`) REFERENCES `estado_civil` (`id_estado_civil`) ON UPDATE CASCADE,
  ADD CONSTRAINT `persona_ibfk_3` FOREIGN KEY (`id_sector`) REFERENCES `sector` (`id_sector`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `sector`
--
ALTER TABLE `sector`
  ADD CONSTRAINT `sector_ibfk_1` FOREIGN KEY (`id_parroquia`) REFERENCES `parroquia` (`id_parroquia`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `telefono`
--
ALTER TABLE `telefono`
  ADD CONSTRAINT `telefono_ibfk_1` FOREIGN KEY (`id_codigo`) REFERENCES `codigo` (`id_codigo`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`id_pregunta`) REFERENCES `pregunta_seguridad` (`id_pregunta`) ON UPDATE CASCADE,
  ADD CONSTRAINT `usuario_ibfk_2` FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id_persona`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
