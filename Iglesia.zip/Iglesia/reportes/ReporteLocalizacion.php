<?php
include ('FPDF/fpdf.php');
include('../modelo/conexionBD.php');

$conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
$conn->conectar();//CONECTO CON MYSQL   
$conn->seleccionarBD(); //selecciono bd

$pdf = new FPDF();
$pdf->AddPage();

$pdf->SetFont('Times','B',10);
//$pdf->Image('../SRC/IMG/cintillo3.jpg' ,10,10,190,20,'JPG');
$pdf->Ln(20);
$pdf->Cell(0,4,utf8_decode("República Bolivariana de Venezuela"),0,1,'C');
$pdf->Cell(0,4,utf8_decode("Ministerio del Poder Poular para la Defensa"),0,1,'C');
$pdf->Cell(0,4,utf8_decode('Batallón de Helicopteros "Florencio Jiménez"'),0,1,'C');
$pdf->Cell(0,4,utf8_decode("ni idea"),0,1,'C');
$pdf->Cell(0,4,utf8_decode("Independencia - Yaracuy"),0,1,'C');
$pdf->Cell(0,4,utf8_decode(""),0,1,'C');
$pdf->Ln(7);
//$pdf->Cell(0,4,utf8_decode("San Felipe ".date("j")."  de ".date("M")." del ".date("Y")."."),0,1,'R');
$pdf->Ln(7); //salto 4de linea
$pdf->SetFillColor(255,120,0);//Fuente de letra,Tipo y Tamaño
$pdf->Cell(0,6,'Personal',1,0,'C','true');
$pdf->Ln(5);
$pdf->SetFont('Times', 'B', 8);//Fuente de letra,Tipo y Tamaño
$pdf->SetFillColor(230,230,230);//Color de la Cell
$pdf->Cell(10,5,"COD",1,0,'C','true');
$pdf->Cell(40,5,"ESTADO",1,0,'C','true');
$pdf->Cell(10,5,"COD",1,0,'C','true');
$pdf->Cell(40,5,"MUNICIPIO",1,0,'C','true');
$pdf->Cell(10,5,"COD",1,0,'C','true');
$pdf->Cell(40,5,"PARROQUIA",1,0,'C','true');
$pdf->Cell(40,5,"SECTOR",1,0,'C','true');
$pdf->Ln(5);

$sql = "SELECT estado.codigo_cne_estado, estado.nombre_estado, municipio.codigo_cne_municipio, municipio.nombre_municipio, parroquia.codigo_cne_parroquia, parroquia.nombre_parroquia, sector.nombre_sector FROM estado, municipio, parroquia, sector WHERE sector.id_parroquia = parroquia.id_parroquia AND parroquia.id_municipio = municipio.id_municipio AND municipio.id_estado = estado.id_estado AND estado.status_estado = '1' AND municipio.status_municipio = '1' AND parroquia.status_parroquia = '1' AND sector.status_sector = '1'";

$buscar = $conn->ejecutarQuery($sql);

if(mysql_num_rows($buscar) > 0){
    while($resultado = mysql_fetch_array($buscar)){
        $pdf->Cell(10,5,utf8_decode($resultado['codigo_cne_estado']),1,0,'C');
        $pdf->Cell(40,5,utf8_decode($resultado['nombre_estado']),1,0,'C');
        $pdf->Cell(10,5,utf8_decode($resultado['codigo_cne_municipio']),1,0,'C');
        $pdf->Cell(40,5,utf8_decode($resultado['nombre_municipio']),1,0,'C');
        $pdf->Cell(10,5,utf8_decode($resultado['codigo_cne_parroquia']),1,0,'C');
        $pdf->Cell(40,5,utf8_decode($resultado['nombre_parroquia']),1,0,'C');
        $pdf->Cell(40,5,utf8_decode($resultado['nombre_sector']),1,0,'C');
        $pdf->Ln();
    }
}else{
     $pdf->Cell(20,5,"NO SE ENCUENTRAN RESULTADOS",1,0,'C');
}

 $pdf->Output("PrimerPDF.pdf",'F');
 echo "<script language='javascript'>window.open('../reportes/PrimerPDF.pdf','_blank','');</script>";//para ver el archivo pdf generado
 echo"<META HTTP-EQUIV='refresh' CONTENT='0; URL=../vista/V_GestionSector.php'>";
		exit;


		
		
