<?php 
require('fpdf.php'); 

class PDF extends FPDF 
{ 
    //Cabecera de página 
    function Header() 
    { 
        $this->Image('images/barra.jpg',50,10,180); 
        $this->SetFont('Arial','B',6); 
        $this->Cell(0,20,"Fecha de Impresion: ".date('d - m - Y')."  ",'',1,'R'); 
            $this->Ln(2); 
    } 
    //Pie de página 
    function Footer() 
    { 
        //Posición: a 2 cm del final 
        $this->SetY(-20); 
         //Arial italic 8 
        $this->SetFont('Arial','',8); 
        $this->Cell(300,4,'Firma:__________________________                                Responsable:__________________________','',1,'C'); 
         //Arial italic 8 
        $this->SetFont('Arial','BI',8); 
        $this->Cell(250,2,'GENERAL MOTORS VENEZOLANA C.A','',1,'L'); 
        $this->Cell(250,5,'Sistema para la Gestion de CNP','',1,'L'); 
        //Arial italic 8 
        $this->SetFont('Arial','BI',8); 
        //Número de página 
        $this->Cell(195,4,'Reporte de Materiales','T',0,'L'); 
        $this->Cell(0,4,'Pagina '.$this->PageNo().'/TPAG','T',1,'R'); 
         
         

    } 
}//Fin de la clase 