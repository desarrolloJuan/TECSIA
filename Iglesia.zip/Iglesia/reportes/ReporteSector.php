<?php

include ('FPDF/fpdf.php');
include_once '../modelo/conexionBD.php';

class ReporteSector{
    
}

$pdf = new FPDF();
$pdf->AddPage();

$pdf->SetTopMargin(20); 
$pdf->SetLeftMargin(20); 
$pdf->SetRightMargin(20);
        
/* seleccionamos el tipo, estilo y tamaño de la letra a utilizar */
$pdf->Image($ruta,20,17,170,20);
$pdf->Ln(30);
//$pdf->Image('../SRC/IMG/escudo_ejercito.jpg' ,10,20,32,32,'JPG');
//$pdf->Ln(10);
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,5,utf8_decode("REPÚBLICA BOLIVARIANA DE VENEZUELA"),0,1,'C');
$pdf->Cell(0,5,utf8_decode("MINISTERIO DEL PODER POPULAR PARA LA DEFENSA"),0,1,'C');
$pdf->Cell(0,5,utf8_decode("EJÉRCITO BOLIVARIANO"),0,1,'C');
$pdf->Cell(0,5,utf8_decode('BATALLÓN DE HELICOPTEROS "FLORENCIO JIMÉNEZ"'),0,1,'C');
$pdf->Cell(0,5,utf8_decode('COCOROTE - YARACUY'),0,1,'C');

$conn = new conexionBD();//INSTANCIO LA CLASE conexionBD
$conn->conectar();//CONECTO CON MYSQL   
$conn->seleccionarBD(); //SELECCIONO LA BD

$sql = "SELECT estado.codigo_cne_estado, estado.nombre_estado, estado.status_estado, municipio.codigo_cne_municipio, municipio.nombre_municipio, municipio.status_municipio, parroquia.codigo_cne_parroquia, parroquia.nombre_parroquia, parroquia.status_parroquia, sector.id_sector, sector.nombre_sector, sector.status_sector FROM estado, municipio, parroquia, sector WHERE estado.status_estado = '1' AND municipio.status_municipio = '1' AND parroquia.status_parroquia = '1' AND sector.id_parroquia = parroquia.id_parroquia AND parroquia.id_municipio = municipio.id_municipio AND municipio.id_estado = estado.id_estado AND sector.status_sector = '1'";

$buscar = $conn->ejecutarQuery($sql);

if(mysql_num_rows($buscar) > 0 ){
    while( $row = mysql_fetch_array($buscar) ){
        if($row['status_estado'] == 1 && $row['status_municipio'] == 1 && $row['status_parroquia'] == 1 && $row['status_sector'] == 1 ){
           
            $nombre_estado = explode(" ", $row['nombre_estado']);
            $nombre_municipio = explode(" ", $row['nombre_municipio']);
            $nombre_parroquia = explode(" ", $row['nombre_parroquia']);
            $nombre_sector = explode(" ", $row['nombre_sector']);
//            $ho =  date("g:i a",strtotime($row['fecha_presentacion']));
            
//            $dias = array('Dia', 'Lunes','Martes','Miercoles','Jueves','Viernes','Sabado','Domingo');
//            $dia = $dias[date('N', strtotime($row['fecha_presentacion']))];
            
            $pdf->SetFont('Arial','', 10);//Fuente de letra y Tamaño
            $pdf->SetFillColor(250,250,250);//Color de la Cell
            $pdf->SetTextColor(0,0,0);
            
//            $pdf->Cell(42,7,utf8_decode($row['identificador']),1,0,'C','true');
//            $pdf->Cell(90,7,utf8_decode($dia.", ".strftime("%d-%m-%Y", strtotime($row['fecha_presentacion']))." ".$ho),1,0,'C','true');
//            if( $row['calificacion'] > 55 )
//            {
//                $pdf->SetFont('Arial','B', 10);
//                $pdf->SetTextColor(0,255,0);
//                $pdf->Cell(41,7,utf8_decode($row['calificacion']."%"),1,0,'C','true');
//            }
//            else
//            {
//                $pdf->SetFont('Arial','B', 10);
//                $pdf->SetTextColor(255,0,0);
//                $pdf->Cell(41,7,utf8_decode($row['calificacion']."%"),1,0,'C','true');
//            }
//            $pdf->Ln(7); //salto de linea
        }
    }
}else{
    
}

$nom_pdf = 'generados/sectores.pdf';
    $res = $pdf->Output($nom_pdf,'F');

    header ("Content-Disposition: attachment; filename=$nom_pdf ");
    header ("Content-Type: application/force-download");
    header ("Content-Length: ".filesize($nom_pdf));
    readfile($nom_pdf);
//    header("location:../VISTA/VistaRecordDeEstudiante.php");

