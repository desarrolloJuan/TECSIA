<?php

include_once("../modelo/Dones.php"); //incluyo la clase

$dones = new Dones(); //instancio la clase

if( isset( $_POST['autocompletar'] ) ) //para cuando se llame el controlador para buscar sugerencias
{    
    //verifico sobre que campo se buscaran las sugerencias
    if( $_POST['campo'] == 'NOMBRE' )
    {
        $nombre = $_POST['nombre'];
        $dones->SugerenciasDeDones($nombre);
    }
}
else if( isset( $_POST['buscar_dones'] ) ) //para buscar los datos de un dones ya seleccionado de las sugerencias
{    
    $dones->set_IdDones( $_POST['id_dones'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $dones->BuscarDatosDones();//mando ejecutar la funcion que devolvera el array con los datos
}
else if( isset( $_POST['registrar_dones'] ) ) //para buscar los datos de un dones ya seleccionado de las sugerencias
{    
    $dones->set_Nombre( strtoupper($_POST['nombre']) );
    $dones->RegistrarDones();
}
else if( isset( $_POST['modificar_dones'] ) ) //para buscar los datos de un dones ya seleccionado de las sugerencias
{        
    $dones->set_IdDones( $_POST['id_dones'] );
    $dones->set_Nombre( strtoupper($_POST['nombre']) );
    $dones->set_Status( '1' );
    $dones->ModificarDones();
}
else if( isset( $_POST['eliminar_dones'] ) ) //para buscar los datos de un dones ya seleccionado de las sugerencias
{    
    $dones->set_IdDones( $_POST['id_dones'] );
    $dones->EliminarDones();
}
else if( isset( $_POST['cargar_dones'] ) ) //para buscar los datos de un dones ya seleccionado de las sugerencias
{
    $dones->CargarDones();
}

else if( isset( $_POST['listar_dones'] ) ) //para buscar los datos de un dones ya seleccionado de las sugerencias
{
    $dones->ListarDones();
}
