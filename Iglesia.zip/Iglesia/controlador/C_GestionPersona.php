<?php

include_once('../modelo/Persona.php');
$persona = new Persona();

if( isset( $_POST['autocompletar'] ) )
{
    $cedula = trim($_POST['cedula'], $character_mask = " \t\n\r\0\x0B" );
    $persona->SugerenciasCedula($cedula);
}
else if( isset( $_POST['verificar_cedula'] ) )
{
    $cedula = trim( $_POST['cedula'], $character_mask = " \t\n\r\0\x0B" );
    
    echo $cedula;
    
    $resp = $persona->VerificarCedula( $cedula );
    
    if( $resp == 1 )
    {
        echo 1;
    }
    else
    {
        echo 0;
    }
    
}