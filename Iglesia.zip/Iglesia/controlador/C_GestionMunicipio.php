<?php

include_once("../modelo/Municipio.php"); //incluyo la clase
include_once("../modelo/Estado.php");

if( isset( $_POST['autocompletar'] ) ) //para cuando se llame el controlador para buscar sugerencias
{
    $municipio = new Municipio(); //instancio la clase
    
    //verifico sobre que campo se buscaran las sugerencias
    if( $_POST['campo'] == 'CODIGO' ) 
    {
        $codigo = $_POST['codigo_cne_municipio'];
        $id_estado = $_POST['id_estado'];
        $municipio->set_IdEstado($id_estado);
        $municipio->SugerenciasDeMunicipios($codigo, "");
    }
    else if( $_POST['campo'] == 'NOMBRE' )
    {
        $nombre = $_POST['nombre_municipio'];
        $id_estado = $_POST['id_estado'];
        $municipio->set_IdEstado($id_estado);
        $municipio->SugerenciasDeMunicipios("", $nombre);
    }
}
else if( isset( $_POST['buscar_municipio'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $municipio = new Municipio();//instancio la clase
    
    $municipio->set_IdMunicipio( $_POST['id_municipio'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $municipio->BuscarDatosMunicipio();//mando ejecutar la funcion que devolvera el array con los datos
}
else if( isset( $_POST['registrar_municipio'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $municipio = new Municipio();//instancio la clase
    
    $municipio->set_CodigoCneMunicipio( $_POST['codigo_cne_municipio'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $municipio->set_NombreMunicipio( strtoupper($_POST['nombre_municipio']) );
    $municipio->set_IdEstado($_POST['id_estado']);
    $municipio->RegistrarMunicipio();
}
else if( isset( $_POST['modificar_municipio'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $municipio = new Municipio();//instancio la clase
    
    //echo $_POST['id_estado']." ".$_POST['codigo_cne_estado']." ".$_POST['nombre_estado'];
    
    $municipio->set_IdMunicipio( $_POST['id_municipio'] );
    $municipio->set_CodigoCneMunicipio( $_POST['codigo_cne_municipio'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $municipio->set_NombreMunicipio( strtoupper($_POST['nombre_municipio']) );
    $municipio->set_StatusMunicipio( '1' );
    $municipio->set_IdEstado($_POST['id_estado']);
    $municipio->ModificarMunicipio();
}
else if( isset( $_POST['eliminar_municipio'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $municipio = new Municipio();//instancio la clase
    
    $municipio->set_IdMunicipio( $_POST['id_municipio'] );
    $municipio->EliminarMunicipio();
}
else if( isset( $_POST['listar_municipio'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $municipio = new Municipio();//instancio la clase
    $municipio->get_IdEstado( $_POST['id_estado'] );
    $municipio->ListarMunicipios();
}
else if(isset($_POST["cargar_municipio"]))
{
    $municipio = new Municipio();
   	
    $id_estado = $_POST['id_estado'];
    
    $municipio->set_IdEstado($id_estado);
	
    $municipio->CargarMunicipios();
    
}
