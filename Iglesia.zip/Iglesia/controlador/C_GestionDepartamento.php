<?php

include_once("../modelo/Departamento.php"); //incluyo la clase

$departamento = new Departamento(); //instancio la clase

if( isset( $_POST['autocompletar'] ) ) //para cuando se llame el controlador para buscar sugerencias
{    
    //verifico sobre que campo se buscaran las sugerencias
    if( $_POST['campo'] == 'NOMBRE' )
    {
        $nombre = $_POST['nombre'];
        $departamento->SugerenciasDeDepartamentos($nombre);
    }
}
else if( isset( $_POST['buscar_departamento'] ) ) //para buscar los datos de un departamento ya seleccionado de las sugerencias
{    
    $departamento->set_IdDepartamento( $_POST['id_departamento'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $departamento->BuscarDatosDepartamento();//mando ejecutar la funcion que devolvera el array con los datos
}
else if( isset( $_POST['registrar_departamento'] ) ) //para buscar los datos de un departamento ya seleccionado de las sugerencias
{    
    $departamento->set_Nombre( strtoupper($_POST['nombre']) );
    $departamento->RegistrarDepartamento();
}
else if( isset( $_POST['modificar_departamento'] ) ) //para buscar los datos de un departamento ya seleccionado de las sugerencias
{        
    $departamento->set_IdDepartamento( $_POST['id_departamento'] );
    $departamento->set_Nombre( strtoupper($_POST['nombre']) );
    $departamento->set_Status( '1' );
    $departamento->ModificarDepartamento();
}
else if( isset( $_POST['eliminar_departamento'] ) ) //para buscar los datos de un departamento ya seleccionado de las sugerencias
{    
    $departamento->set_IdDepartamento( $_POST['id_departamento'] );
    $departamento->EliminarDepartamento();
}
else if( isset( $_POST['cargar_departamentos'] ) ) //para buscar los datos de un departamento ya seleccionado de las sugerencias
{
    $departamento->CargarDepartamento();
}

else if( isset( $_POST['listar_departamentos'] ) ) //para buscar los datos de un departamento ya seleccionado de las sugerencias
{
    $departamento->ListarDepartamentos();
}
