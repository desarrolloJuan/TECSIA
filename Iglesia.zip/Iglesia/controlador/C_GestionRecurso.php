<?php

include_once("../modelo/Recurso.php"); //incluyo la clase

$recurso = new Recurso(); //instancio la clase

if( isset( $_POST['autocompletar'] ) ) //para cuando se llame el controlador para buscar sugerencias
{    
    //verifico sobre que campo se buscaran las sugerencias
    if( $_POST['campo'] == 'DESCRIPCION' )
    {
        $descripcion = $_POST['descripcion'];
        $recurso->SugerenciasDeRecursos($descripcion);
    }
}
else if( isset( $_POST['buscar_recurso'] ) ) //para buscar los datos de un recurso ya seleccionado de las sugerencias
{    
    $recurso->set_IdRecurso( $_POST['id_recurso'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $recurso->BuscarDatosRecurso();//mando ejecutar la funcion que devolvera el array con los datos
}
else if( isset( $_POST['registrar_recurso'] ) ) //para buscar los datos de un recurso ya seleccionado de las sugerencias
{    
    $recurso->set_Descripcion( strtoupper($_POST['descripcion']) );
    $recurso->RegistrarRecurso();
}
else if( isset( $_POST['modificar_recurso'] ) ) //para buscar los datos de un recurso ya seleccionado de las sugerencias
{        
    $recurso->set_IdRecurso( $_POST['id_recurso'] );
    $recurso->set_Descripcion( strtoupper($_POST['descripcion']) );
    $recurso->set_Status( '1' );
    $recurso->ModificarRecurso();
}
else if( isset( $_POST['eliminar_recurso'] ) ) //para buscar los datos de un recurso ya seleccionado de las sugerencias
{    
    $recurso->set_IdRecurso( $_POST['id_recurso'] );
    $recurso->EliminarRecurso();
}
else if( isset( $_POST['cargar_recursos'] ) ) //para buscar los datos de un recurso ya seleccionado de las sugerencias
{
    $recurso->CargarRecursos();
}

else if( isset( $_POST['listar_recursos'] ) ) //para buscar los datos de un recurso ya seleccionado de las sugerencias
{
    $recurso->ListarRecursos();
}
