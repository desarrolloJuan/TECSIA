<?php

include_once("../modelo/GrupoPequeno.php"); //incluyo la clase

if( isset( $_POST['autocompletar'] ) ) //para cuando se llame el controlador para buscar sugerencias
{
    $interrogante = new Grupo_Pequeno(); //instancio la clase
    
    //verifico sobre que campo se buscaran las sugerencias
    {
    $descripcion = $_POST['descripcion'];
    $grupo_pequeno->SugerenciasDeGrupoPequeno("", $descripcion);
    }
}
else if( isset( $_POST['buscar_grupo_pequeno'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $grupo_pequeno = new Grupo_Pequeno();//instancio la clase
    
    $grupo_pequeno->set_IdGrupo( $_POST['id_grupo'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $grupo_pequeno->BuscarDatosGrupo_Pequeno();//mando ejecutar la funcion que devolvera el array con los datos
}
else if( isset( $_POST['registrar_grupo_pequeno'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $grupo_pequeno = new Interrogante();//instancio la clase
   
    $grupo_pequeno->set_Descripcion( strtoupper($_POST['descripcion']) );
    $grupo_pequeno->RegistrarGrupo_Pequeno();
}
else if( isset( $_POST['modificar_Grupo_Pequeno'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $grupo_pequeno = new Grupo_Pequeno();//instancio la clase
    
    //echo $_POST['id_estado']." ".$_POST['codigo_cne_estado']." ".$_POST['nombre_estado'];
    
    $grupo_pequeno->set_IdGrupo_Pequeno( $_POST['id_grupo'] );
    $grupo_pequeno->set_Descripcion( strtoupper($_POST['descripcion']) );
    $grupo_pequeno->set_StatusGrupo( '1' );
    $grupo_pequeno->ModificarGrupo_Pequeno();
}
else if( isset( $_POST['eliminar_grupo_pequeno'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $grupo_pequeno = new Grupo_Pequeno();//instancio la clase
    
    $grupo_pequeno->set_IdGrupo_Pequeno( $_POST['id_grupo_pequeno'] );
    $grupo_pequeno->EliminarGrupo_Pequeno();
}
else if( isset( $_POST['cargar_grupo_pequeno'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $grupo_pequeno = new Grupo_Pequeno();//instancio la clase
    $grupo_pequeno->CargarGrupo_Pequeno();
}

else if( isset( $_POST['listar_grupo_pequeno'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $grupo_pequeno = new Grupo_Pequeno();//instancio la clase
    $grupo_pequeno->ListarGrupo_Pequeno();
}

