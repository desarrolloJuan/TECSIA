<?php

include_once("../modelo/Discipulado.php"); //incluyo la clase

if( isset( $_POST['autocompletar'] ) ) //para cuando se llame el controlador para buscar sugerencias
{
    $discipulado = new Discipulado(); //instancio la clase
    
    //verifico sobre que campo se buscaran las sugerencias
   
    $descripcion = $_POST['descripcion'];
    $discipulado->SugerenciasDeDiscipulado($descripcion);

}
else if( isset( $_POST['buscar_discipulado'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $discipulado = new Interrogante();//instancio la clase
    
    $discipulado->set_IdDiscipulado( $_POST['id_discipulado'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $discipulado->BuscarDatosDiscipulado();//mando ejecutar la funcion que devolvera el array con los datos
}
else if( isset( $_POST['registrar_discipulado'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $discipulado = new Discipulado();//instancio la clase
    
    //$interrogante->set_CodigoCneEstado( $_POST['codigo_cne_estado'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $discipulado->set_Descripcion( strtoupper($_POST['nombre_discipulado']) );
    $discipulado->RegistrarDiscipulado();
}
else if( isset( $_POST['modificar_discipulado'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $discipulado = new Discipulado();//instancio la clase
    
    //echo $_POST['id_estado']." ".$_POST['codigo_cne_estado']." ".$_POST['nombre_estado'];
    
    $discipulado->set_IdDiscipulado( $_POST['id_discipulado'] );
    $discipulado->set_Descripcion( strtoupper($_POST['descripcion']) );
    $discipulado->set_StatusDiscipulado( '1' );
    $discipulado->ModificarDiscipulado();
}
else if( isset( $_POST['eliminar_discipulado'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $discipulado = new Discipulado();//instancio la clase
    
    $discipulado->set_IdDiscipulado( $_POST['id_discipulado'] );
    $discipulado->EliminarDiscipulado();
}
else if( isset( $_POST['cargar_discipulado'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $discipulado = new Discipulado();//instancio la clase
    $discipulado->CargarDiscipulado();
}

else if( isset( $_POST['listar_discipulado'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $discipulado = new Discipulado();//instancio la clase
    $discipulado->ListarDiscipulado();
}