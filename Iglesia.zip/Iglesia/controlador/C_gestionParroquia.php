<?php


include_once("../modelo/Parroquia.php"); //incluyo la clase

if( isset( $_POST['autocompletar'] ) ) //para cuando se llame el controlador para buscar sugerencias
{
    $parroquia = new Parroquia(); //instancio la clase
    
    //verifico sobre que campo se buscaran las sugerencias
    if( $_POST['campo'] == 'CODIGO' ) 
    {
        $codigo = $_POST['codigo_cne_parroquia'];
        $id_municipio = $_POST['id_municipio'];
        $parroquia->set_IdMunicipio($id_municipio);
        $parroquia->SugerenciasDeParroquias($codigo, "");
    }
    else if( $_POST['campo'] == 'NOMBRE' )
    {
        $nombre = $_POST['nombre_parroquia'];
        $id_municipio = $_POST['id_municipio'];
        $parroquia->set_IdMunicipio($id_municipio);
        $parroquia->SugerenciasDeParroquias("", $nombre);
    }
}
else if( isset( $_POST['buscar_parroquia'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $parroquia = new Parroquia();//instancio la clase
    
    $parroquia->set_IdParroquia( $_POST['id_parroquia'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $parroquia->BuscarDatosParroquia();//mando ejecutar la funcion que devolvera el array con los datos
}

else if( isset( $_POST['registrar_parroquia'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $parroquia = new Parroquia();//instancio la clase
    
    $parroquia->set_CodigoCneParroquia( $_POST['codigo_cne_parroquia'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $parroquia->set_NombreParroquia( strtoupper($_POST['nombre_parroquia']) );
    $parroquia->set_IdMunicipio($_POST['id_municipio']);
    $parroquia->RegistrarParroquia();
}
else if( isset( $_POST['modificar_parroquia'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $parroquia = new Parroquia();//instancio la clase
    
    //echo $_POST['id_estado']." ".$_POST['codigo_cne_estado']." ".$_POST['nombre_estado'];
    
    $parroquia->set_IdParroquia( $_POST['id_parroquia'] );
    $parroquia->set_CodigoCneParroquia( $_POST['codigo_cne_parroquia'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $parroquia->set_NombreParroquia( strtoupper($_POST['nombre_parroquia']) );
    $parroquia->set_StatusParroquia( '1' );
    $parroquia->set_IdMunicipio($_POST['id_municipio']);
    $parroquia->ModificarParroquia();
}
else if( isset( $_POST['eliminar_parroquia'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $parroquia = new Parroquia();//instancio la clase
    
    $parroquia->set_IdParroquia( $_POST['id_parroquia'] );
    $parroquia->EliminarParroquia();
}
else if( isset( $_POST['listar_parroquia'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $parroquia = new Parroquia();//instancio la clase
    $parroquia->ListarParroquias();
}
else if(isset($_POST["cargar_parroquia"]))
{
    $parroquia = new Parroquia();
   	
    $id_municipio = $_POST['id_municipio'];
    
    $parroquia->set_IdMunicipio($id_municipio);
	
    $parroquia->CargarParroquias();
    
}



