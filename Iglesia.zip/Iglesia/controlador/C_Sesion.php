<?php

$estado_session = session_status(); //para obtener el estado de la sesion iniciada

if($estado_session == PHP_SESSION_NONE) //en caso que no haya sesion iniciada
{
    session_start(); //se inicia una sesion, con esto podremos usar las variables $_SESSION[]
}
else{}


include_once("../modelo/Usuario.php"); //incluimos modelo o clase Usuario
include_once("../modelo/FotoPerfil.php"); //incluimos modelo o clase FotoPerfil
include_once("../modelo/Persona.php"); //incluimos modelo o clase Persona

if( isset( $_POST['nombre_usuario'] ) && isset( $_POST['clave'] ) ) //verifico la obtencion del nombre de usuario y la clave
{
    $usuario = new Usuario(); //instancio la clase Usuario
    $foto = new FotoPerfil(); //instancio la clase FotoPerfil
    $persona = new Persona(); //instancio la clase Usuario
    
    if( strlen($_POST['nombre_usuario']) < 8 || strlen($_POST['nombre_usuario']) > 16 ) //verifico la longitud del nombre de usuario
    {
        $_SESSION['resp'] = "N_< 8"; 
        echo'<META HTTP-EQUIV="refresh" CONTENT="10; URL=../index.php">'; //le recargo la pagina index.
    }
    else if( strlen($_POST['clave']) < 8 || strlen($_POST['clave']) > 16 ) //verifico longitud de la clave
    {
        $_SESSION['resp'] = "C_< 8"; 
        echo'<META HTTP-EQUIV="refresh" CONTENT="10; URL=../index.php">';
    }
    else //si todo esta de manera correcta procedo a realizar la consulta
    {
        $usuario->set_NombreUsuario( strtoupper( $_POST['nombre_usuario'] ) ); //paso el nombre de usuario a la clase
        $usuario->set_Clave( $_POST['clave'] ); //paso la clave a la clase

        $respt = $usuario->BuscarDatosUsuario(); //mando ejecutar la funcion BuscarDatosUsuario()

        if( $respt == 1 ) //en caso de que la funcion me devuelva un 1, es decir que encontro algo
        {
            $status = $usuario->get_StatusUsuario(); //capturo el status            
            $buscar_foto = $foto->BuscarFotoActiva( $usuario->get_IdUsuario() ); //mando a buscar su foto de perfil
            $persona->set_IdPersona( $usuario->get_IdPersona() ); //paso la cedula a la clase Persona
            $datos_personales = $persona->BuscarDatosPersona();//ejecuto la funcion que busca los datos personales del usuario
            
            if( $status == 1 ) //si el status es igual a 1, es decir la cuenta esta activa
            {
                if( $buscar_foto == 1 ) //si encuentra la foto de perfil
                {
                    $_SESSION['foto_perfil'] = $foto->get_Ruta(); //creo una variable SESSION con la ruta donde esta la foto
                }
                else //en caso de no encontrarla se usa una imagen de usuario por defecto
                {
                    $_SESSION['foto_perfil'] = "";
                }
                
                if( $datos_personales == 1 )
                {
                    $_SESSION['cedula'] = $persona->get_Cedula();
                    $_SESSION['apellidos'] = utf8_encode($persona->get_Apellidos());
                    $_SESSION['nombres'] = utf8_encode($persona->get_Nombres());
                    $_SESSION['canti'] = 0;
                }
                else
                {}
                
                $_SESSION['usuario'] = $usuario->get_NombreUsuario(); //creo una variable SESSION con el nombre de usuario
                
                echo'<META HTTP-EQUIV="refresh" CONTENT="0; URL=../vista/Inicio.php">';
            }
            else
            {
                $_SESSION['resp'] = "Disab"; 
                echo'<META HTTP-EQUIV="refresh" CONTENT="10; URL=../index.php">';
            }
        }
        else
        {
            $_SESSION['resp'] = "Inc"; 
            echo'<META HTTP-EQUIV="refresh" CONTENT="10; URL=../index.php">';
        }
    }
    
}
else if( isset( $_GET['cerrar'] ) )
{
    session_destroy();
    header("location: ../index.php");
}