<?php

include_once("../modelo/TipoInterrogante.php"); //incluyo la clase

if( isset( $_POST['autocompletar'] ) ) //para cuando se llame el controlador para buscar sugerencias
{
    $tipo_interrogante = new Tipo_Interrogante(); //instancio la clase
    
    //verifico sobre que campo se buscaran las sugerencias
    // REVISAR ESTA PARTE
    if( $_POST['campo'] == 'CODIGO' ) 
    {
        $codigo = $_POST['codigo_cne'];
        $estado->SugerenciasDeEstados($codigo, "");
    }
    else if( $_POST['campo'] == 'DESCRIPCION' )
    {
        $descripcion = $_POST['descripcion'];
        $tipo_interrogante->SugerenciasDeTipoInterrogante("", $descripcion);
    }
}
else if( isset( $_POST['buscar_tipo_interrogante'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $tipo_interrogante = new Tipo_Interrogante();//instancio la clase
    
    $tipo_interrogante->set_IdInterrogante( $_POST['id_interrogante'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $tipo_interrogante->BuscarDatosTipoInterrogante();//mando ejecutar la funcion que devolvera el array con los datos
}
else if( isset( $_POST['registrar_tipo_interrogante'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $tipo_interrogante = new Interrogante();//instancio la clase
   
    $tipo_interrogante->set_Descripcion( strtoupper($_POST['descripcion']) );
    $tipo_interrogante->RegistrarTipoInterrogante();
}
else if( isset( $_POST['modificar_tipo_interrogante'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $tipo_interrogante = new Tipo_Interrogante();//instancio la clase
    
    //echo $_POST['id_estado']." ".$_POST['codigo_cne_estado']." ".$_POST['nombre_estado'];
    
    $tipo_interrogante->set_IdInterrogante( $_POST['id_tipo_interrogante'] );
    $tipo_interrogante->set_Descripcion( strtoupper($_POST['descripcion']) );
    $tipo_interrogante->set_StatusTipo( '1' );
    $tipo_interrogante->ModificarTipoInterrogante();
}
else if( isset( $_POST['eliminar_tipo_interrogante'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $tipo_interrogante = new Tipo_Interrogante();//instancio la clase
    
    $tipo_interrogante->set_IdTipo_Interrogante( $_POST['id_tipo_interrogante'] );
    $tipo_interrogante->EliminarTipoInterrogante();
}
else if( isset( $_POST['cargar_tipo_interrogante'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $tipo_interrogante = new Tipo_Interrogante();//instancio la clase
    $tipo_interrogante->CargarTipo_Interrogante();
}

else if( isset( $_POST['listar_tipo_interrogante'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $tipo_interrogante = new Tipo_Interrogante();//instancio la clase
    $tipo_interrogante->ListarTipoInterrogante();
}