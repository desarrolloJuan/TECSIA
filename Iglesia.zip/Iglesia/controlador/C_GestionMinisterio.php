<?php

include_once("../modelo/Ministerio.php"); //incluyo la clase

$ministerio = new Ministerio(); //instancio la clase

if( isset( $_POST['autocompletar'] ) ) //para cuando se llame el controlador para buscar sugerencias
{    
    //verifico sobre que campo se buscaran las sugerencias
    if( $_POST['campo'] == 'NOMBRE' )
    {
        $nombre = $_POST['nombre'];
        $ministerio->SugerenciasDeMinisterios($nombre);
    }
}
else if( isset( $_POST['buscar_ministerio'] ) ) //para buscar los datos de un ministerio ya seleccionado de las sugerencias
{    
    $ministerio->set_IdMinisterio( $_POST['id_ministerio'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $ministerio->BuscarDatosMinisterio();//mando ejecutar la funcion que devolvera el array con los datos
}
else if( isset( $_POST['registrar_ministerio'] ) ) //para buscar los datos de un ministerio ya seleccionado de las sugerencias
{    
    $ministerio->set_Nombre( strtoupper($_POST['nombre']) );
    $ministerio->RegistrarMinisterio();
}
else if( isset( $_POST['modificar_ministerio'] ) ) //para buscar los datos de un ministerio ya seleccionado de las sugerencias
{        
    $ministerio->set_IdMinisterio( $_POST['id_ministerio'] );
    $ministerio->set_Nombre( strtoupper($_POST['nombre']) );
    $ministerio->set_Status( '1' );
    $ministerio->ModificarMinisterio();
}
else if( isset( $_POST['eliminar_ministerio'] ) ) //para buscar los datos de un ministerio ya seleccionado de las sugerencias
{    
    $ministerio->set_IdMinisterio( $_POST['id_ministerio'] );
    $ministerio->EliminarMinisterio();
}
else if( isset( $_POST['cargar_ministerios'] ) ) //para buscar los datos de un ministerio ya seleccionado de las sugerencias
{
    $ministerio->CargarMinisterio();
}

else if( isset( $_POST['listar_ministerios'] ) ) //para buscar los datos de un ministerio ya seleccionado de las sugerencias
{
    $ministerio->ListarMinisterios();
}
