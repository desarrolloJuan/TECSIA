<?php

include_once('../modelo/Usuario.php');
$usuario = new Usuario();

if( isset( $_POST['buscar_usuario'] ) )
{
    $id_persona = $_POST['id_persona'];
    
    $usuario->set_IdPersona( $id_persona );
    $usuario->BuscarUsuario();
}
else if( isset( $_POST['listar_usuarios'] ) )
{
    $usuario->ListarUsuarios();
}
else if( isset( $_POST['buscar_disponibilidad'] ) )
{
    $nombre_usuario = trim( $_POST['nombre_usuario'] );
    
    $usuario->set_NombreUsuario( $nombre_usuario );
    $usuario->BuscarDisponibilidad();
}
else if( isset( $_POST['registrar_usuario'] ) )
{
    echo $_POST['nombre_usuario']." ".$_POST['clave']." ".$_POST['cedula'];
}