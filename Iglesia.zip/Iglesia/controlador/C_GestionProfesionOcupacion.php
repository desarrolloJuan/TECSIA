<?php

include_once("../modelo/ProfesionOcupacion.php"); //incluyo la clase

$profesion_ocupacion = new ProfesionOcupacion(); //instancio la clase

if( isset( $_POST['autocompletar'] ) ) //para cuando se llame el controlador para buscar sugerencias
{    
    //verifico sobre que campo se buscaran las sugerencias
    if( $_POST['campo'] == 'DESCRIPCION_PROFESION' )
    {
        $descripcion_profesion = $_POST['descripcion_profesion'];
        $profesion_ocupacion->SugerenciasDeProfesionOcupacion($descripcion_profesion);
    }
}
else if( isset( $_POST['buscar_profesion'] ) ) //para buscar los datos de la profesion ya seleccionado de las sugerencias
{    
    $profesion_ocupacion->set_Id_Profesion( $_POST['id_profesion'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $profesion_ocupacion->BuscarDatosProfesionOcupacion();//mando ejecutar la funcion que devolvera el array con los datos
}
else if( isset( $_POST['registrar_profesion_ocupacion'] ) ) //para buscar los datos de un departamento ya seleccionado de las sugerencias
{    
    $profesion_ocupacion->set_Descripcion_Profesion( strtoupper($_POST['descripcion_profesion']) );
    $profesion_ocupacion->RegistrarProfesionOcupacion();
}
else if( isset( $_POST['modificar_profesion'] ) ) //para buscar los datos de una profesion u ocupacion ya seleccionado de las sugerencias
{        
    $profesion_ocupacion->set_Id_Profesion( $_POST['id_profesion'] );
    $profesion_ocupacion->set_Descripcion_Profesion( strtoupper($_POST['descripcion_profesion']) );
    $profesion_ocupacion->set_Status_Profesion( '1' );
    $profesion_ocupacion->ModificarProfesionOcupacion();
}
else if( isset( $_POST['eliminar_profesion_ocupacion'] ) ) //para buscar los datos de una profesion u ocupacion ya seleccionado de las sugerencias
{    
    $profesion_ocupacion->set_Id_Profesion( $_POST['id_profesion'] );
    $profesion_ocupacion->EliminarProfesionOcupacion();
}
else if( isset( $_POST['cargar_profesion_ocupacion'] ) ) //para buscar los datos de una profesion u ocupacion ya seleccionado de las sugerencias
{
    $profesion_ocupacion->CargarProfesionOcupacion();
}

else if( isset( $_POST['listar_profesion_ocupacion'] ) ) //para buscar los datos de una profesion u ocupacion ya seleccionado de las sugerencias
{
    $profesion_ocupacion->ListarProfesionOcupacionn();
}


