<?php

include_once("../modelo/Sector.php"); //incluyo la clase

if( isset( $_POST['autocompletar'] ) ) //para cuando se llame el controlador para buscar sugerencias
{
    $sector = new Sector(); //instancio la clase
    

    $nombre = $_POST['nombre_sector'];
    $id_parroquia = $_POST['id_parroquia'];
    $sector->set_IdParroquia($id_parroquia);
    $sector->SugerenciasDeSectores($nombre);

}
else if( isset( $_POST['buscar_sector'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $sector = new Sector();//instancio la clase
    
    $sector->set_IdSector( $_POST['id_sector'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $sector->BuscarDatosSector();//mando ejecutar la funcion que devolvera el array con los datos
}
else if( isset( $_POST['registrar_sector'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $sector = new Sector();//instancio la clase
    
    //$sector->set_CodigoCneParroquia( $_POST['codigo_cne_parroquia'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $sector->set_NombreSector( strtoupper($_POST['nombre_sector']) );
    $sector->set_IdParroquia($_POST['id_parroquia']);
    $sector->RegistrarSector();
}
else if( isset( $_POST['modificar_sector'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $sector = new Sector();//instancio la clase
    
    //echo $_POST['id_estado']." ".$_POST['codigo_cne_estado']." ".$_POST['nombre_estado'];
    
    $sector->set_IdSector( $_POST['id_sector'] );
    //$sector->set_CodigoCneParroquia( $_POST['codigo_cne_parroquia'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $sector->set_NombreSector( strtoupper($_POST['nombre_sector']) );
    $sector->set_StatusSector( '1' );
    $sector->set_IdParroquia($_POST['id_parroquia']);
    $sector->ModificarSector();
}
else if( isset( $_POST['eliminar_sector'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $sector = new Sector();//instancio la clase
    
    $sector->set_IdSector( $_POST['id_sector'] );
    $sector->EliminarSector();
}
else if( isset( $_POST['listar_sector'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $sector = new Sector();//instancio la clase
    $sector->ListarSectores();
}



