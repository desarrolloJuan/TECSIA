<?php

include_once("../modelo/Interrogante.php"); //incluyo la clase

if( isset( $_POST['autocompletar'] ) ) //para cuando se llame el controlador para buscar sugerencias
{
    $interrogante = new Interrogante(); //instancio la clase
    
    //verifico sobre que campo se buscaran las sugerencias
   
    $descripcion = $_POST['descripcion'];
    $interrogante->SugerenciasDeInterrogante($descripcion);

}
else if( isset( $_POST['buscar_interrogante'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $interrogante = new Interrogante();//instancio la clase
    
    $interrogante->set_IdInterrogante( $_POST['id_interrogante'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $interrogante->BuscarDatosInterrogante();//mando ejecutar la funcion que devolvera el array con los datos
}
else if( isset( $_POST['registrar_interrogante'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $interrogante = new Interrogante();//instancio la clase
    
    //$interrogante->set_CodigoCneEstado( $_POST['codigo_cne_estado'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $interrogante->set_Descripcion( strtoupper($_POST['nombre_interrogante']) );
    $interrogante->RegistrarInterrogante();
}
else if( isset( $_POST['modificar_interrogante'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $interrogante = new Interrogante();//instancio la clase
    
    //echo $_POST['id_estado']." ".$_POST['codigo_cne_estado']." ".$_POST['nombre_estado'];
    
    $interrogante->set_IdInterrogante( $_POST['id_interrogante'] );
    $interrogante->set_Descripcion( strtoupper($_POST['descripcion']) );
    $interrogante->set_StatusInterrogante( '1' );
    $interrogante->ModificarInterrogante();
}
else if( isset( $_POST['eliminar_interrogante'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $interrogante = new Interrogante();//instancio la clase
    
    $interrogante->set_IdInterrogante( $_POST['id_interrogante'] );
    $interrogante->EliminarInterrogante();
}
else if( isset( $_POST['cargar_interrogante'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $interrogante = new Interrogante();//instancio la clase
    $interrogante->CargarInterrogante();
}

else if( isset( $_POST['listar_interrogante'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $interrogante = new Interrogante();//instancio la clase
    $interrogante->ListarInterrogante();
}
