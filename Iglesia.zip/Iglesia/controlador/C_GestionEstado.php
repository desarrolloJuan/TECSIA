<?php

include_once("../modelo/Estado.php"); //incluyo la clase

if( isset( $_POST['autocompletar'] ) ) //para cuando se llame el controlador para buscar sugerencias
{
    $estado = new Estado(); //instancio la clase
    
    //verifico sobre que campo se buscaran las sugerencias
    if( $_POST['campo'] == 'CODIGO' ) 
    {
        $codigo = $_POST['codigo_cne'];
        $estado->SugerenciasDeEstados($codigo, "");
    }
    else if( $_POST['campo'] == 'NOMBRE' )
    {
        $nombre = $_POST['nombre_estado'];
        $estado->SugerenciasDeEstados("", $nombre);
    }
}
else if( isset( $_POST['buscar_estado'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $estado = new Estado();//instancio la clase
    
    $estado->set_IdEstado( $_POST['id_estado'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $estado->BuscarDatosEstado();//mando ejecutar la funcion que devolvera el array con los datos
}
else if( isset( $_POST['registrar_estado'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $estado = new Estado();//instancio la clase
    
    $estado->set_CodigoCneEstado( $_POST['codigo_cne_estado'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $estado->set_NombreEstado( strtoupper($_POST['nombre_estado']) );
    $estado->RegistrarEstado();
}
else if( isset( $_POST['modificar_estado'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $estado = new Estado();//instancio la clase
    
    //echo $_POST['id_estado']." ".$_POST['codigo_cne_estado']." ".$_POST['nombre_estado'];
    
    $estado->set_IdEstado( $_POST['id_estado'] );
    $estado->set_CodigoCneEstado( $_POST['codigo_cne_estado'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $estado->set_NombreEstado( strtoupper($_POST['nombre_estado']) );
    $estado->set_StatusEstado( '1' );
    $estado->ModificarEstado();
}
else if( isset( $_POST['eliminar_estado'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $estado = new Estado();//instancio la clase
    
    $estado->set_IdEstado( $_POST['id_estado'] );
    $estado->EliminarEstado();
}
else if( isset( $_POST['cargar_estados'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $estado = new Estado();//instancio la clase
    $estado->CargarEstados();
}

else if( isset( $_POST['listar_estados'] ) ) //para buscar los datos de un estado ya seleccionado de las sugerencias
{
    $estado = new Estado();//instancio la clase
    $estado->ListarEstados();
}
