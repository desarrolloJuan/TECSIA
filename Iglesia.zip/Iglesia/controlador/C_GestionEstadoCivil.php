<?php

include_once("../modelo/EstadoCivil.php"); //incluyo la clase

$estado_civil = new EstadoCivil(); //instancio la clase

if( isset( $_POST['autocompletar'] ) ) //para cuando se llame el controlador para buscar sugerencias
{    
    //verifico sobre que campo se buscaran las sugerencias
    if( $_POST['campo'] == 'DESCRIPCION_ESTADO_CIVIL' )
    {
        $descripcion_estado_civil = $_POST['descripcion_estado_civil'];
        $estado_civil->SugerenciasDeEstadoCivil($descripcion_estado_civil);
    }
}
else if( isset( $_POST['buscar_estado_civil'] ) ) //para buscar los datos de un departamento ya seleccionado de las sugerencias
{    
    $estado_civil->set_Id_Estado_Civil( $_POST['id_estado_civil'] ); //paso el id, previamente capturado en un campo hidden de la vista
    $estado_civil->BuscarDatosEstadoCivil();//mando ejecutar la funcion que devolvera el array con los datos
}
else if( isset( $_POST['registrar_estado_civil'] ) ) //para buscar los datos de un departamento ya seleccionado de las sugerencias
{    
    $estado_civil->set_Descripcion_Estado_Civil( strtoupper($_POST['descripcion_estado_civil']) );
    $estado_civil->RegistrarEstadoCivil();
}
else if( isset( $_POST['modificar_estado_civil'] ) ) //para buscar los datos de un departamento ya seleccionado de las sugerencias
{        
    $estado_civil->set_Id_Estado_Civil( $_POST['id_estado_civil'] );
    $estado_civil->set_Descripcion_Estado_Civil( strtoupper($_POST['descripcion_estado_civil']) );
    $estado_civil->set_Status_Estado_Civil( '1' );
    $estado_civil->ModificarEstadoCivil();
}
else if( isset( $_POST['eliminar_estado_civil'] ) ) //para buscar los datos de un departamento ya seleccionado de las sugerencias
{    
    $estado_civil->set_Id_Estado_Civil( $_POST['id_estado_civil'] );
    $estado_civil->EliminarEstadoCivil();
}
else if( isset( $_POST['cargar_estado_civil'] ) ) //para buscar los datos de un departamento ya seleccionado de las sugerencias
{
    $estado_civil->CargarEstadoCivil();
}

else if( isset( $_POST['listar_estado_civil'] ) ) //para buscar los datos de un departamento ya seleccionado de las sugerencias
{
    $estado_civil->ListarEstadoCivil();
}

