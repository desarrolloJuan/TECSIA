
    

        function Buscar( id_persona )
        {
            //alert(id_persona);
            $.ajax({
                async:false, 
                cache:false,
                dataType:"html", 
                type: 'POST',   
                url: "../controlador/C_GestionUsuario.php",
                data: {
                        id_persona: id_persona,
                        buscar_usuario: "JDHSJUHDWJDHSJHSJDS" 
                },
                success:  function(respuesta){

                    //alert( respuesta );
                    contenido = $.trim(respuesta); 

                    if(contenido !== "[]")
                    { 
                        // json vacio....
                        var json_usuario = $.parseJSON(contenido);
                        //alert(json_usuario);
                        $("#id_usuario").val( json_usuario.id_usuario );
                        $("#cedula").val( json_usuario.cedula );
                        $("#nombre_usuario").val( json_usuario.nombre_usuario );
                        $("#nombre_usuario").attr("disabled", "disabled");
                        $("#clave").val( json_usuario.clave );
                        $("#clave").attr("disabled", "disabled");
                        $("#btn_ver_clave").attr("disabled", "disabled");
                        $("#clave").val( json_usuario.clave );
                        document.getElementById("foto_cargada").innerHTML = ['<img style="width: 170px; height: 200px;" src="../assets/img/', json_usuario.ruta,'" "/>'].join('');
                        $("#id_pregunta").val( json_usuario.id_pregunta );
                        $("#respuesta").val( json_usuario.respuesta_seguridad );
                        $("#status_usuario").val( json_usuario.status_usuario );
                        
                        $("#btn_registrar").attr("disabled","disabled");
                        $("#btn_modificar").removeAttr("disabled");
                        $("#btn_eliminar").removeAttr("disabled");
                        $("#btn_cancelar").removeAttr("disabled");
                        
                        $("#sugerencias-cedulas").fadeOut(10);
                        $("#ocultar-tabla-usuarios").click();
                    }
                    else
                    {
                        $("#sugerencias-cedulas").fadeOut(10);
                    }

                },
                beforeSend:function(){
                    //alert('envie la data');
                },
                error:function(objXMLHttpRequest){}
            });
        }
        
        function Notificacion( tipo, msj )
        {
            //alert( tipo+ ' '+msj );
            if( tipo == 0 )
            {
                $("#texto-error").text(msj);
                $("#mensaje-error").fadeIn(20);
                $("#mensaje-success").fadeOut(10);
                $("#mensaje-info").fadeOut(10);
                $('body, html').animate({
                    scrollTop: '0px'
                }, 5000);
            }
            else if( tipo == 1 )
            {
                $("#texto-success").text(msj);
                $("#mensaje-success").fadeIn(20);
                $("#mensaje-error").fadeOut(10);
                $("#mensaje-info").fadeOut(10);
                $('body, html').animate({
                    scrollTop: '0px'
                }, 5000);
            }
            else if( tipo == 2 )
            {
                $("#texto-info").text(msj);
                $("#mensaje-info").fadeIn(20);
                $("#mensaje-success").fadeOut(10);
                $("#mensaje-error").fadeOut(10);
                $('body, html').animate({
                    scrollTop: '0px'
                }, 300);
            }
        }
        
        /*para verificar si existe la cedula ingresada*/
        function ConsultarDatosPersonales()
        {
            var resp = 0;
            $.ajax({
                    async:false, 
                    cache:false,
                    dataType:"html", 
                    type: 'POST',   
                    url: "../controlador/C_GestionPersona.php",
                    data: {
                            cedula: $("#cedula").val(),
                            verificar_cedula: "verificar_cedula" 
                    },
                    success:  function(respuesta){

                        //alert( respuesta );
                        if(respuesta > 1)
                        { 
                            resp = 1;
                        }
                        else
                        {
                            resp = 0;
                        }
                    },
                    beforeSend:function(){},
                    error:function(objXMLHttpRequest){}
                }); //cierra el ajax
                
            return resp;
        }
        
        function ValidarCampos()
        {
            var resp = 0;
            
            if( $("#cedula").val() == "" )
            {
                Notificacion( 0, "Completa el campo Cédula." );
                $("#cedula").focus();
                resp = 0;
                
            }
            else if( $("#cedula").val().lengh < 6 )
            {
                Notificacion(0, "Ingresa una Cédula válida");
                $("#cedula").focus();
                resp = 0;
            }
            else if( $("#nombre_usuario").val() == "" )
            {
                Notificacion(0, "Completa el campo Nombre Usuario");
                $("#nombre_usuario").focus();
                resp = 0;
            }
            else if( $("#nombre_usuario").val().length < 8 || $("#nombre_usuario").val().length > 16 )
            {
                Notificacion(0, "Ingresa un Nombre Usuario válido. (entre 8 y 16 caracteres)");
                $("#nombre_usuario").focus();
                resp = 0;
            }
            else if( $("#clave").val() == "" )
            {
                Notificacion(0, "Completa el campo Clave");
                $("#clave").focus();
                resp = 0;
            }
            else if( $("#clave").val().length < 8 || $("#clave").val().length > 16 )
            {
                Notificacion(0, "Ingresa una Clave válida. (entre 8 y 16 caracteres)");
                $("#clave").focus();
                resp = 0;
            }
            else if( $("#id_pregunta").val() == 0 )
            {
                Notificacion(0, "Selecciona una Pregunta de Seguridad");
                $("#id_pregunta").focus();
                resp = 0;
            }
            else if( $("#respuesta").val() == "" )
            {
                Notificacion(0, "Completa el campo Respuesta de Seguridad");
                $("#respuesta").focus();
                resp = 0;
            }
            else if( $("#status_usuario").val() == "" )
            {
                Notificacion(0, "Seleccione el Estado del Usuario");
                $("#nombre_usuario").focus();
                resp = 0;
            }
            else
            {
                resp = 1;
            }
            
            return resp;
        }
        
        
        /*FUNCION PARA ACTUALIZAR DATOS DE UN ESTADO*/
        function RegistrarUsuario()
        {
            
            var validar = ValidarCampos();

            if( validar === 1 )
            {
                var resp = ConsultarDatosPersonales();
            
                if( resp === 1 )
                {
                    $.ajax({
                        async:false, 
                        cache:false,
                        dataType:"html", 
                        type: 'POST',   
                        url: "../controlador/C_GestionUsuario.php",
                        data: {
                                cedula: $("#cedula").val(),
                                nombre_usuario: $("#nombre_usuario").val(),
                                clave: $("#clave").val(),
                                id_pregunta: $("#id_pregunta").val(),
                                respuesta: $("#respuesta").val(),
                                status_usuario: $("#status_usuario").val(),
                                //foto_perfil: valueOf($("#foto_perfil")),
                                registrar_usuario: "registrar" 
                        },
                        success:  function(respuesta){

                            alert( respuesta );
                            if(respuesta == 1)
                            { 
                                /*var msj = "Estado "+ nombre +" fue registrado.";

                                $("#id_estado").val("");
                                $("#codigo_cne_estado").val("");
                                $("#nombre_estado").val("");

                                $("#btn_modificar").attr("disabled","disabled");
                                $("#btn_eliminar").attr("disabled","disabled");
                                $("#btn_cancelar").attr("disabled","disabled");

                                $("#sugerencias-codigos").fadeOut(10);
                                $("#sugerencias-nombres").fadeOut(10);
                                Notificacion(1, msj);*/

                            }
                            else
                            {
                                //var msj = respuesta;
                                //Notificacion(0, msj); 
                            }


                        },
                        beforeSend:function(){},
                        error:function(objXMLHttpRequest){}
                    }); //cierra el ajax
                }
            }
                        
        }
        
        
        /*FUNCION PARA ACTUALIZAR DATOS DE UN ESTADO*/
        function ModificarEstado( )
        {
            if( $("#codigo_cne_estado").val() == "" )
            {
                Notificacion(0, "Debe ingresar el Codigo del Estado.");
            }
            else if( $("#nombre_estado").val() == "" )
            {
                Notificacion(0, "Debe ingresar el Nombre del Estado.");
            }
            else
            {
                $.ajax({
                    async:false, 
                    cache:false,
                    dataType:"html", 
                    type: 'POST',   
                    url: "../controlador/C_GestionEstado.php",
                    data: {
                            id_estado: $("#id_estado").val(),
                            codigo_cne_estado: $("#codigo_cne_estado").val(),
                            nombre_estado: $("#nombre_estado").val(),
                            modificar_estado: "modificar_estado" 
                    },
                    success:  function(respuesta){

                        if(respuesta == 1)
                        { 
                            Notificacion(2, "Los datos del estado han sido actualizados.");
                            $("#id_estado").val( "" );
                            $("#codigo_cne_estado").val( "" );
                            $("#nombre_estado").val( "" );

                            $("#btn_registrar").removeAttr("disabled");
                            $("#btn_modificar").attr("disabled","disabled");
                            $("#btn_eliminar").attr("disabled","disabled");
                            $("#btn_cancelar").attr("disabled","disabled");
                            
                            $("#sugerencias-codigos").fadeOut(10);
                            $("#sugerencias-nombres").fadeOut(10);
                        }
                        else
                        {
                            var msj = respuesta;
                            Notificacion(0, msj);
                        }

                    },
                    beforeSend:function(){},
                    error:function(objXMLHttpRequest){}
                });
            }
        }
        
        /*FUNCION PARA ELIMINAR O INHABILITAR UN ESTADO*/
        function EliminarEstado( )
        {
            $.ajax({
                async:false, 
                cache:false,
                dataType:"html", 
                type: 'POST',   
                url: "../controlador/C_GestionEstado.php",
                data: {
                        id_estado: $("#id_estado").val(),
                        eliminar_estado: "eliminar_estado" 
                },
                success:  function(respuesta){
                    
                    if(respuesta == 1)
                    { 
                        Notificacion(2, "El estado ha sido eliminado");
                        $("#id_estado").val( "" );
                        $("#codigo_cne_estado").val( "" );
                        $("#nombre_estado").val( "" );
                        
                        $("#btn_registrar").removeAttr("disabled");
                        $("#btn_modificar").attr("disabled","disabled");
                        $("#btn_eliminar").attr("disabled","disabled");
                        $("#btn_cancelar").attr("disabled","disabled");
                        
                        $("#sugerencias-codigos").fadeOut(10);
                        $("#sugerencias-nombres").fadeOut(10);
                    }
                    else
                    {
                        
                        Notificacion(0, "Problemas con la base de datos");
                        $("#sugerencias-codigos").fadeOut(10);
                        $("#sugerencias-nombres").fadeOut(10);
                    }

                },
                beforeSend:function(){},
                error:function(objXMLHttpRequest){}
            });
        }
        
        /*FUNCION PARA BUSCAR SUGERENCIAS MIENTRAS SE ESCRIBE EN LOS CAMPOS*/
        function BuscarSugerencias()
        {
            if( $("#cedula").val().length > 2 )
            {
                $.ajax({
                    async:false, 
                    cache:false,
                    dataType:"html", 
                    type: 'POST',   
                    url: "../controlador/C_GestionPersona.php",
                    data: {
                           cedula: $("#cedula").val(),
                            autocompletar: "autocompletar" 
                    },
                    success:  function(respuesta){

                        if(respuesta != "")
                        { 
                            $("#sugerencias-cedulas").empty();
                            $("#sugerencias-cedulas").html( respuesta );
                            $("#sugerencias-cedulas").css("display","block");

                        }
                        else
                        {
                            $("#sugerencias-cedulas").empty();
                            $("#sugerencias-cedulas").html('<li onclick="">NO HAY RESULTADOS ENCONTRADOS</li>');
                            $("#sugerencias-cedulas").css("display","block");
                        }

                    },
                    beforeSend:function(){},
                    error:function(objXMLHttpRequest){}
                });
            }
            else
            {
                $("#sugerencias-cedulas").empty();
                $("#sugerencias-cedulas").css("display","none");
            }
        }
        
        function Cancelar()
        {
            $("#nombre_usuario").removeAttr("disabled");
            $("#clave").removeAttr("disabled");
            $("#btn_ver_clave").removeAttr("disabled");
            $("#btn_registrar").removeAttr("disabled");
            $("#btn_modificar").attr("disabled","disabled");
            $("#btn_eliminar").attr("disabled","disabled");
            $("#btn_cancelar").attr("disabled","disabled");
            
            
            $("#sugerencias-cedulas").fadeOut(10);
            
            $("#mensaje-error").fadeOut(10);
            $("#mensaje-success").fadeOut(10);
            $("#mensaje-info").fadeOut(10);
            setTimeout(function() {
                MostrarIconoFoto();
            }, 3000);
        }
    
        function MostrarIconoFoto()
        {
            setTimeout(function() {
                    document.getElementById("foto_cargada").html('<img style="width: 170px; height: 200px;" src="../assets/img/find_user.png" "/>');
                },3000);
            
        }

        function ListarUsuario( )
        {
            $.ajax({
                async:false, 
                cache:false,
                dataType:"html", 
                type: 'POST',   
                url: "../controlador/C_GestionUsuario.php",
                data: {
                        
                        listar_usuarios: "listar" 
                },
                success:  function(respuesta){
                    
                    if(respuesta !== "")
                    { 
                        $("#div-tabla-usuarios").html( respuesta );
                    }
                    else
                    {
                        $("#div-tabla-usuarios").html( respuesta );
                    }

                },
                beforeSend:function(){},
                error:function(objXMLHttpRequest){}
            });
        }


        function BuscarDisponibilidad( )
        {
            if( $("#nombre_usuario").val().length >= 8)
            {
                $.ajax({
                    async:false, 
                    cache:false,
                    dataType:"html", 
                    type: 'POST',   
                    url: "../controlador/C_GestionUsuario.php",
                    data: {
                            nombre_usuario: $("#nombre_usuario").val(),
                            buscar_disponibilidad: "buscar" 
                    },
                    success:  function(respuesta){

                        if( respuesta > 0 )
                        {
                            $("#mensaje-disponibilidad").removeClass('disponible');
                            $("#mensaje-disponibilidad").addClass('no-disponible');
                            $("#mensaje-disponibilidad").text("El nombre de usuario "+$("#nombre_usuario").val()+" ya está en uso, ingrese uno diferente.");
                            $("#mensaje-disponibilidad").fadeIn(100);
                        }
                        else
                        {
                            $("#mensaje-disponibilidad").removeClass('no-disponible');
                            $("#mensaje-disponibilidad").addClass('disponible');
                            $("#mensaje-disponibilidad").text("El nombre de usuario "+$("#nombre_usuario").val()+" está disponible.");
                            $("#mensaje-disponibilidad").fadeIn(100);

                            /*setTimeout(function() {
                                $("#mensaje-disponibilidad").fadeOut(100);
                            },4000);*/
                        }

                    },
                    beforeSend:function(){},
                    error:function(objXMLHttpRequest){}
                });
            }
            else
            {
                $("#mensaje-disponibilidad").removeClass('disponible');
                $("#mensaje-disponibilidad").addClass('no-disponible');
                $("#mensaje-disponibilidad").text("Ingresa un nombre de usuario válido. (entre 8 y 16 caracteres)");
                $("#mensaje-disponibilidad").fadeIn(100);
            }
        }
        
        function VerClave()
        {
            $("#clave").attr("type","text");
        }
        
        function OcultarClave()
        {
            $("#clave").attr("type","password");
        }
        